#!/bin/bash
set -euo pipefail

HOST="${1:-}"
if [ -z "$HOST" ]; then
    echo "Usage: $0 root@IPHONE_IP_OR_HOST [PORT]"
    exit 2
fi
PORT="${2:-22}"

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
AGENT="$ROOT_DIR/HIDProbeApp/Resources/Agent/hidprobe_agent"
PLIST="$ROOT_DIR/HIDProbeApp/Resources/Agent/com.hidprobe.agent.plist"

if [ ! -f "$AGENT" ] || [ ! -f "$PLIST" ]; then
    echo "Missing agent/plist. Run: bash HIDProbeApp/Sources/Agent/helper/build_hidprobe_agent.sh"
    exit 1
fi

SSH=(ssh -p "$PORT" "$HOST")
SCP=(scp -P "$PORT")

REMOTE_LAYOUT="$("${SSH[@]}" 'if [ -d /var/jb ]; then echo rootless; else echo rootful; fi')"
if [ "$REMOTE_LAYOUT" = "rootless" ]; then
    REMOTE_BIN="/var/jb/usr/local/bin/hidprobe_agent"
    REMOTE_PLIST="/var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist"
    DOMAIN="system"
else
    REMOTE_BIN="/usr/local/bin/hidprobe_agent"
    REMOTE_PLIST="/Library/LaunchDaemons/com.hidprobe.agent.plist"
    DOMAIN="system"
fi

echo "[install] layout=$REMOTE_LAYOUT bin=$REMOTE_BIN plist=$REMOTE_PLIST"
"${SSH[@]}" "mkdir -p \"$(dirname "$REMOTE_BIN")\" \"$(dirname "$REMOTE_PLIST")\" /var/mobile/Library/Logs"
"${SCP[@]}" "$AGENT" "$HOST:/tmp/hidprobe_agent"
"${SCP[@]}" "$PLIST" "$HOST:/tmp/com.hidprobe.agent.plist"

"${SSH[@]}" "python3 - <<'PY' 2>/dev/null || /usr/bin/plutil -replace ProgramArguments.0 -string '$REMOTE_BIN' /tmp/com.hidprobe.agent.plist
import plistlib
p='/tmp/com.hidprobe.agent.plist'
d=plistlib.load(open(p,'rb'))
d['ProgramArguments'][0]='$REMOTE_BIN'
plistlib.dump(d, open(p,'wb'), sort_keys=False)
PY
cp /tmp/hidprobe_agent '$REMOTE_BIN'
cp /tmp/com.hidprobe.agent.plist '$REMOTE_PLIST'
chmod 755 '$REMOTE_BIN'
chmod 644 '$REMOTE_PLIST'
chown root:wheel '$REMOTE_BIN' '$REMOTE_PLIST' 2>/dev/null || chown root:root '$REMOTE_BIN' '$REMOTE_PLIST'
launchctl bootout '$DOMAIN' '$REMOTE_PLIST' 2>/dev/null || true
launchctl bootstrap '$DOMAIN' '$REMOTE_PLIST' 2>/dev/null || launchctl load -w '$REMOTE_PLIST'
sleep 1
launchctl list | grep hidprobe || true
tail -n 40 /var/mobile/Library/Logs/hidprobe-agent.log 2>/dev/null || true"
