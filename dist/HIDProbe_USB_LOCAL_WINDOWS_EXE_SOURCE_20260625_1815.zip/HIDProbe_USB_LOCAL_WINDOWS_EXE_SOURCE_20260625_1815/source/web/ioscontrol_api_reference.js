"use strict";

(function attachIosControlApiReference(global) {
  const ReferenceData = {
  "generated_at": "2026-05-06T14:50:22.817Z",
  "source": "https://ioscontrol.com/docs.html",
  "counts": {
    "total": 96,
    "ready": 57,
    "stub": 26,
    "partial": 4,
    "route": 9
  },
  "sections": [
    {
      "id": "touch",
      "title_vi": "Mô phỏng cảm ứng",
      "title_en": "Touch Simulation",
      "items": [
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "tap(x, y)",
          "base": "tap",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chạm tại toạ độ",
          "desc_en": "Tap at coordinates",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X (điểm WDA)",
              "desc_en": "X coordinate (WDA points)"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y (điểm WDA)",
              "desc_en": "Y coordinate (WDA points)"
            }
          ],
          "returns": "void",
          "example": "-- Tap a button then wait for UI response\ntap(195, 400)\nsleep(0.3)\nlocal c = getColor(195, 400)\nif c ~= 0xFFFFFF then\n  log(\"Button pressed successfully\")\nend"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "touchDown(id, x, y)",
          "base": "touchDown",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Nhấn ngón tay xuống (đa chạm)",
          "desc_en": "Press finger down (multi-touch)",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "id",
              "type": "number",
              "required": true,
              "desc_vi": "ID ngón tay (0-9)",
              "desc_en": "Finger ID (0-9)"
            },
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X",
              "desc_en": "X coordinate"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y",
              "desc_en": "Y coordinate"
            }
          ],
          "returns": "void",
          "example": "-- Pinch-to-zoom with two fingers\ntouchDown(0, 150, 400)\ntouchDown(1, 250, 400)\nsleep(0.1)\nfor i = 1, 10 do\n  touchMove(0, 150 - i*5, 400)\n  touchMove(1, 250 + i*5, 400)\n  usleep(30000)\nend\ntouchUp(0, 100, 400)\ntouchUp(1, 300, 400)"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "touchMove(id, x, y)",
          "base": "touchMove",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Di chuyển ngón tay đến vị trí mới",
          "desc_en": "Move finger to new position",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "id",
              "type": "number",
              "required": true,
              "desc_vi": "ID ngón tay",
              "desc_en": "Finger ID"
            },
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "X mới",
              "desc_en": "New X"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Y mới",
              "desc_en": "New Y"
            }
          ],
          "returns": "void",
          "example": "-- Draw a circle gesture\ntouchDown(0, 200, 300)\nfor angle = 0, 360, 10 do\n  local rad = math.rad(angle)\n  local x = 200 + 50 * math.cos(rad)\n  local y = 300 + 50 * math.sin(rad)\n  touchMove(0, x, y)\n  usleep(20000)\nend\ntouchUp(0, 200, 300)"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "touchUp(id, x, y)",
          "base": "touchUp",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Nhả ngón tay",
          "desc_en": "Release finger",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "id",
              "type": "number",
              "required": true,
              "desc_vi": "ID ngón tay",
              "desc_en": "Finger ID"
            },
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X",
              "desc_en": "X coordinate"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y",
              "desc_en": "Y coordinate"
            }
          ],
          "returns": "void",
          "example": "touchUp(0, 150, 300)"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "swipe(x1, y1, x2, y2, duration)",
          "base": "swipe",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Vuốt từ điểm A đến B",
          "desc_en": "Swipe gesture from point A to B",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x1",
              "type": "number",
              "required": true,
              "desc_vi": "X bắt đầu",
              "desc_en": "Start X"
            },
            {
              "name": "y1",
              "type": "number",
              "required": true,
              "desc_vi": "Y bắt đầu",
              "desc_en": "Start Y"
            },
            {
              "name": "x2",
              "type": "number",
              "required": true,
              "desc_vi": "X kết thúc",
              "desc_en": "End X"
            },
            {
              "name": "y2",
              "type": "number",
              "required": true,
              "desc_vi": "Y kết thúc",
              "desc_en": "End Y"
            },
            {
              "name": "duration",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian (giây, mặc định: 0.5)",
              "desc_en": "Duration in seconds (default: 0.5)"
            }
          ],
          "returns": "void",
          "example": "-- Scroll through a feed 5 times\nfor i = 1, 5 do\n  swipe(200, 600, 200, 200, 0.3)\n  sleep(1.5)\n  log(\"Scrolled page \" .. i)\nend"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "longPress(x, y, duration)",
          "base": "longPress",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Nhấn giữ tại toạ độ",
          "desc_en": "Long press at coordinates",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X",
              "desc_en": "X coordinate"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y",
              "desc_en": "Y coordinate"
            },
            {
              "name": "duration",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian giữ (giây)",
              "desc_en": "Hold duration in seconds"
            }
          ],
          "returns": "void",
          "example": "-- Long press to open context menu\nlongPress(200, 400, 1.5)\nsleep(0.5)\n-- Tap \"Copy\" option in context menu\ntap(200, 350)"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "pinch(x, y, scale, duration)",
          "base": "pinch",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Phóng to/thu nhỏ bằng 2 ngón",
          "desc_en": "Pinch zoom in/out gesture",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Tâm X",
              "desc_en": "Center X"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Tâm Y",
              "desc_en": "Center Y"
            },
            {
              "name": "scale",
              "type": "number",
              "required": true,
              "desc_vi": "Hệ số (>1 = phóng to, <1 = thu nhỏ)",
              "desc_en": "Scale factor (>1 = zoom in, <1 = zoom out)"
            },
            {
              "name": "duration",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian (giây)",
              "desc_en": "Duration in seconds"
            }
          ],
          "returns": "void",
          "example": "pinch(200, 400, 2.0, 0.5)  -- Zoom in 2x"
        },
        {
          "category_id": "touch",
          "category_vi": "Mô phỏng cảm ứng",
          "category_en": "Touch Simulation",
          "kind": "function",
          "name": "rotate(x, y, angle, duration)",
          "base": "rotate",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Xoay quanh điểm trung tâm",
          "desc_en": "Rotate gesture around center point",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Tâm X",
              "desc_en": "Center X"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Tâm Y",
              "desc_en": "Center Y"
            },
            {
              "name": "angle",
              "type": "number",
              "required": true,
              "desc_vi": "Góc xoay (độ)",
              "desc_en": "Rotation angle in degrees"
            },
            {
              "name": "duration",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian (giây)",
              "desc_en": "Duration in seconds"
            }
          ],
          "returns": "void",
          "example": "rotate(200, 400, 90, 0.5)  -- Rotate 90°"
        }
      ]
    },
    {
      "id": "color",
      "title_vi": "Màu sắc & Pixel",
      "title_en": "Color & Pixel",
      "items": [
        {
          "category_id": "color",
          "category_vi": "Màu sắc & Pixel",
          "category_en": "Color & Pixel",
          "kind": "function",
          "name": "getColor(x, y)",
          "base": "getColor",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy màu pixel tại toạ độ",
          "desc_en": "Get pixel color at coordinates",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X",
              "desc_en": "X coordinate"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y",
              "desc_en": "Y coordinate"
            }
          ],
          "returns": "number — hex color (0xRRGGBB)",
          "example": "-- Wait for loading screen to finish\nwhile true do\n  local c = getColor(200, 400)\n  if c ~= 0x000000 then\n    log(\"Loading complete! Color: \" .. string.format(\"0x%06X\", c))\n    break\n  end\n  sleep(0.5)\nend\ntap(200, 400)"
        },
        {
          "category_id": "color",
          "category_vi": "Màu sắc & Pixel",
          "category_en": "Color & Pixel",
          "kind": "function",
          "name": "getColors(locations)",
          "base": "getColors",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy nhiều màu pixel cùng lúc",
          "desc_en": "Get multiple pixel colors at once",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "locations",
              "type": "table",
              "required": true,
              "desc_vi": "Mảng các cặp {x, y}",
              "desc_en": "Array of {x, y} pairs"
            }
          ],
          "returns": "table — array of hex colors",
          "example": "local colors = getColors({{100,200}, {200,300}, {300,400}})\nfor i, c in ipairs(colors) do\n    log(\"Point \" .. i .. \": \" .. string.format(\"0x%06X\", c))\nend"
        },
        {
          "category_id": "color",
          "category_vi": "Màu sắc & Pixel",
          "category_en": "Color & Pixel",
          "kind": "function",
          "name": "findColor(color, count, region)",
          "base": "findColor",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm pixel khớp với màu chỉ định",
          "desc_en": "Find pixels matching a specific color",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "color",
              "type": "number",
              "required": true,
              "desc_vi": "Màu đích (hex)",
              "desc_en": "Target color (hex)"
            },
            {
              "name": "count",
              "type": "number",
              "required": false,
              "desc_vi": "Số kết quả tối đa",
              "desc_en": "Max results"
            },
            {
              "name": "region",
              "type": "table",
              "required": false,
              "desc_vi": "Vùng tìm {x, y, w, h}",
              "desc_en": "{x, y, w, h} search area"
            }
          ],
          "returns": "table — array of {x, y} matches",
          "example": "-- Find and tap all red buttons on screen\nlocal pts = findColor(0xFF0000, 10, {0, 0, 428, 926})\nlog(\"Found \" .. #pts .. \" red pixels\")\nfor _, p in ipairs(pts) do\n  tap(p.x, p.y)\n  sleep(0.3)\nend"
        },
        {
          "category_id": "color",
          "category_vi": "Màu sắc & Pixel",
          "category_en": "Color & Pixel",
          "kind": "function",
          "name": "findColors(params)",
          "base": "findColors",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm mẫu nhiều màu trên màn hình",
          "desc_en": "Find multi-color pattern on screen",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "params",
              "type": "table",
              "required": true,
              "desc_vi": "Mẫu với điểm neo + offset",
              "desc_en": "Pattern definition with anchor + offsets"
            }
          ],
          "returns": "table — match locations",
          "example": "-- Find pattern: red + green 10px apart\nlocal x, y = findColors({\n    {0, 0, 0xFF0000},\n    {10, 0, 0x00FF00}\n})\nif x then\n    log(\"Pattern found at \" .. x .. \",\" .. y)\n    tap(x, y)\nend"
        },
        {
          "category_id": "color",
          "category_vi": "Màu sắc & Pixel",
          "category_en": "Color & Pixel",
          "kind": "function",
          "name": "waitForColor(x, y, color, timeout)",
          "base": "waitForColor",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chờ cho đến khi pixel khớp màu",
          "desc_en": "Wait until pixel matches target color",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ X",
              "desc_en": "X coordinate"
            },
            {
              "name": "y",
              "type": "number",
              "required": true,
              "desc_vi": "Toạ độ Y",
              "desc_en": "Y coordinate"
            },
            {
              "name": "color",
              "type": "number",
              "required": true,
              "desc_vi": "Màu mong đợi",
              "desc_en": "Expected color"
            },
            {
              "name": "timeout",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian chờ (giây)",
              "desc_en": "Timeout in seconds"
            }
          ],
          "returns": "boolean — true if matched",
          "example": "-- Wait for green \"Ready\" indicator\nlocal ok = waitForColor(200, 300, 0x00FF00, 10)\nif ok then\n  log(\"Ready! Starting automation...\")\n  tap(200, 500)\nelse\n  log(\"Timeout waiting for ready state\")\nend"
        }
      ]
    },
    {
      "id": "image",
      "title_vi": "Nhận dạng hình ảnh",
      "title_en": "Image Recognition",
      "items": [
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "findImage(path, count, threshold, region)",
          "base": "findImage",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm hình ảnh mẫu trên màn hình",
          "desc_en": "Find template image on device screen",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Đường dẫn ảnh mẫu",
              "desc_en": "Path to template image"
            },
            {
              "name": "count",
              "type": "number",
              "required": false,
              "desc_vi": "Số kết quả tối đa",
              "desc_en": "Max matches"
            },
            {
              "name": "threshold",
              "type": "number",
              "required": false,
              "desc_vi": "Ngưỡng khớp 0-1 (mặc định: 0.8)",
              "desc_en": "Match threshold 0-1 (default: 0.8)"
            },
            {
              "name": "region",
              "type": "table",
              "required": false,
              "desc_vi": "Vùng tìm {x, y, w, h}",
              "desc_en": "{x, y, w, h} search region"
            }
          ],
          "returns": "table — {x, y, score} matches",
          "example": "-- Find and tap the play button\nlocal matches = findImage(\"/var/mobile/Library/IOSControl/images/play_btn.png\", 1, 0.9)\nif #matches > 0 then\n  local btn = matches[1]\n  log(\"Found button at \" .. btn.x .. \",\" .. btn.y .. \" score=\" .. btn.score)\n  tap(btn.x, btn.y)\nelse\n  log(\"Play button not found\")\nend"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "waitForImage(path, timeout)",
          "base": "waitForImage",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chờ hình ảnh xuất hiện trên màn hình",
          "desc_en": "Wait for image to appear on screen",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Đường dẫn ảnh mẫu",
              "desc_en": "Template image path"
            },
            {
              "name": "timeout",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian chờ (giây)",
              "desc_en": "Timeout in seconds"
            }
          ],
          "returns": "table|false — match location or false",
          "example": "-- Wait 30s, match 90%\nlocal m = waitForImage(\"dialog.png\", 30, 0.9)\nif m then\n    tap(m.x, m.y)\n    log(\"Found dialog!\")\nelse\n    log(\"Timeout — dialog not appeared\")\nend"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "screenshot(name, region)",
          "base": "screenshot",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chụp màn hình — lưu JPEG vào thư mục images/",
          "desc_en": "Take screenshot — saves as JPEG in images/ directory",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": false,
              "desc_vi": "Tên file (lưu vào thư mục images/)",
              "desc_en": "Filename (saved to images/ dir)"
            },
            {
              "name": "region",
              "type": "table",
              "required": false,
              "desc_vi": "Vùng chụp {x, y, w, h}",
              "desc_en": "{x, y, w, h} capture region"
            }
          ],
          "returns": "string — saved file path",
          "example": "-- Full screen\nscreenshot(\"myscreen\")\n\n-- Region crop\nscreenshot(\"crop\", {200, 200, 400, 400})\n\n-- Auto timestamp name\nscreenshot()"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "deleteScreenshot(name)",
          "base": "deleteScreenshot",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Xoá screenshot từ thư mục images/",
          "desc_en": "Delete screenshot from images/ directory",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file cần xoá",
              "desc_en": "Filename to delete"
            }
          ],
          "returns": "boolean — success",
          "example": "deleteScreenshot(\"old_screenshot.jpg\")"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "convertBase64(path)",
          "base": "convertBase64",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Chuyển file sang chuỗi base64 (images/, scripts/)",
          "desc_en": "Convert file to base64 string (images/, scripts/)",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file hoặc đường dẫn tuyệt đối",
              "desc_en": "Filename or absolute path"
            }
          ],
          "returns": "string — base64 encoded data",
          "example": "-- Screenshot then send via HTTP\nscreenshot(\"capture.jpg\")\nlocal b64 = convertBase64(\"capture.jpg\")\nhttpPost(\"https://api.example.com/upload\", {image = b64})"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "ocrText(x, y, w, h)",
          "base": "ocrText",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đọc chữ từ vùng màn hình bằng OCR",
          "desc_en": "Read text from screen region via OCR",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "x",
              "type": "number",
              "required": false,
              "desc_vi": "X vùng",
              "desc_en": "Region X"
            },
            {
              "name": "y",
              "type": "number",
              "required": false,
              "desc_vi": "Y vùng",
              "desc_en": "Region Y"
            },
            {
              "name": "w",
              "type": "number",
              "required": false,
              "desc_vi": "Chiều rộng (0 = toàn màn hình)",
              "desc_en": "Region width (0 = full screen)"
            },
            {
              "name": "h",
              "type": "number",
              "required": false,
              "desc_vi": "Chiều cao vùng",
              "desc_en": "Region height"
            }
          ],
          "returns": "string — detected text",
          "example": "-- Read coin count from game UI\nlocal text = ocrText(50, 10, 150, 40)\nlocal coins = tonumber(text:match(\"%d+\"))\nif coins then\n  log(\"Current coins: \" .. coins)\n  if coins >= 1000 then\n    log(\"Enough coins! Buying upgrade...\")\n    tap(300, 500)\n  end\nend"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "ocrFind(text)",
          "base": "ocrFind",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm vị trí chữ trên màn hình bằng OCR",
          "desc_en": "Find text location on screen using OCR",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Chữ cần tìm",
              "desc_en": "Text to search for"
            }
          ],
          "returns": "table — {x, y, w, h} or nil",
          "example": "-- Auto-login: find and tap the Login button\nlocal pos = ocrFind(\"Login\")\nif pos then\n  tap(pos.x + pos.w/2, pos.y + pos.h/2)\n  sleep(1)\n  log(\"Login button tapped\")\nelse\n  log(\"Login button not found on screen\")\nend"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "waitForText(text, timeout)",
          "base": "waitForText",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chờ chữ xuất hiện trên màn hình (OCR)",
          "desc_en": "Wait for text to appear on screen (OCR)",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Chữ cần chờ",
              "desc_en": "Text to wait for"
            },
            {
              "name": "timeout",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian chờ (giây)",
              "desc_en": "Timeout in seconds"
            }
          ],
          "returns": "table|false",
          "example": "local pos = waitForText(\"Welcome\", 15)\nif pos then\n    tap(pos.x, pos.y)\n    log(\"Found Welcome!\")\nelse\n    log(\"Text not found after 15s\")\nend"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "tapImage(path, timeout, threshold)",
          "base": "tapImage",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm hình trên màn hình và chạm vào giữa",
          "desc_en": "Find image on screen and tap its center",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file ảnh",
              "desc_en": "Image filename"
            },
            {
              "name": "timeout",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian chờ (mặc định 5)",
              "desc_en": "Timeout seconds (default 5)"
            },
            {
              "name": "threshold",
              "type": "number",
              "required": false,
              "desc_vi": "Ngưỡng khớp 0-1 (mặc định 0.8)",
              "desc_en": "Match threshold 0-1 (default 0.8)"
            }
          ],
          "returns": "boolean, x, y",
          "example": "-- Find and tap with all params\ntapImage(\"btn_ok.png\", 10, 0.85)\n-- timeout 10s, match 85%\n\n-- Default: timeout=5s, threshold=0.8\ntapImage(\"next_btn.png\")"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "tapText(text, timeout)",
          "base": "tapText",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tìm chữ trên màn hình (OCR) và chạm vào",
          "desc_en": "Find text on screen (OCR) and tap it",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Chữ cần tìm và chạm",
              "desc_en": "Text to find and tap"
            },
            {
              "name": "timeout",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian chờ (mặc định 5)",
              "desc_en": "Timeout seconds (default 5)"
            }
          ],
          "returns": "boolean, x, y",
          "example": "-- Login flow with timeout\ntapText(\"Login\", 10)  -- Wait 10s\nsleep(1)\ntapText(\"Continue\", 5)"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "swipeUntilImage(path, direction, maxSwipes)",
          "base": "swipeUntilImage",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Vuốt cho đến khi tìm thấy hình",
          "desc_en": "Swipe screen until image is found",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Hình cần tìm",
              "desc_en": "Image to search for"
            },
            {
              "name": "direction",
              "type": "string",
              "required": false,
              "desc_vi": "\"up\", \"down\", \"left\", \"right\"",
              "desc_en": "\"up\", \"down\", \"left\", \"right\""
            },
            {
              "name": "maxSwipes",
              "type": "number",
              "required": false,
              "desc_vi": "Số lần vuốt tối đa (mặc định 10)",
              "desc_en": "Maximum swipe attempts (default 10)"
            }
          ],
          "returns": "boolean, swipes, x, y",
          "example": "-- Scroll down until we see the target\nlocal ok, n = swipeUntilImage(\"target.png\", \"up\", 15)\nif ok then log(\"Found after \" .. n .. \" swipes\") end"
        },
        {
          "category_id": "image",
          "category_vi": "Nhận dạng hình ảnh",
          "category_en": "Image Recognition",
          "kind": "function",
          "name": "swipeUntilText(text, direction, maxSwipes)",
          "base": "swipeUntilText",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Vuốt cho đến khi tìm thấy chữ (OCR)",
          "desc_en": "Swipe screen until text is found (OCR)",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Chữ cần tìm",
              "desc_en": "Text to search for"
            },
            {
              "name": "direction",
              "type": "string",
              "required": false,
              "desc_vi": "\"up\", \"down\", \"left\", \"right\"",
              "desc_en": "\"up\", \"down\", \"left\", \"right\""
            },
            {
              "name": "maxSwipes",
              "type": "number",
              "required": false,
              "desc_vi": "Số lần vuốt tối đa",
              "desc_en": "Maximum swipe attempts"
            }
          ],
          "returns": "boolean, swipes, x, y",
          "example": "-- Scroll Settings to find Wi-Fi\nlocal ok, n, x, y = swipeUntilText(\"Wi-Fi\", \"up\")\nif ok then tap(x, y) end"
        }
      ]
    },
    {
      "id": "interact",
      "title_vi": "Tương tác",
      "title_en": "User Interaction",
      "items": [
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "dialogInput(title, message, default)",
          "base": "dialogInput",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Hiện hộp thoại nhập text và chờ phản hồi",
          "desc_en": "Show text input dialog and wait for user response",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "title",
              "type": "string",
              "required": false,
              "desc_vi": "Tiêu đề",
              "desc_en": "Dialog title"
            },
            {
              "name": "message",
              "type": "string",
              "required": false,
              "desc_vi": "Mô tả",
              "desc_en": "Description text"
            },
            {
              "name": "default",
              "type": "string",
              "required": false,
              "desc_vi": "Text mặc định",
              "desc_en": "Default input text"
            }
          ],
          "returns": "string|nil — user input or nil if cancelled",
          "example": "-- Ask for login credentials at runtime\nlocal user = dialogInput(\"Username\", \"Enter your username\")\nif not user then stop() end\nlocal pass = dialogInput(\"Password\", \"Enter password\")\nlog(\"Login as: \" .. user)"
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "dialogChoice(title, ...options)",
          "base": "dialogChoice",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Hiện hộp thoại chọn nhiều lựa chọn",
          "desc_en": "Show choice dialog with multiple options",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "title",
              "type": "string",
              "required": true,
              "desc_vi": "Tiêu đề",
              "desc_en": "Dialog title"
            },
            {
              "name": "options",
              "type": "string...",
              "required": true,
              "desc_vi": "Các lựa chọn (varargs)",
              "desc_en": "Option strings (variable args)"
            }
          ],
          "returns": "string|nil — selected option or nil",
          "example": "-- Let user pick script mode\nlocal mode = dialogChoice(\"Speed\", \"Fast\", \"Normal\", \"Safe\")\nif mode == \"Fast\" then\n  log(\"Running in fast mode!\")\nend"
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "timestamp()",
          "base": "timestamp",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy timestamp unix hiện tại (mili giây)",
          "desc_en": "Get current unix timestamp in milliseconds",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [],
          "returns": "number — milliseconds since epoch",
          "example": "-- Measure execution time\nlocal t1 = timestamp()\ntap(200, 400)\nsleep(1)\nlocal elapsed = timestamp() - t1\nlog(\"Took \" .. elapsed .. \"ms\")"
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "md5(string)",
          "base": "md5",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Tính mã băm MD5 của chuỗi",
          "desc_en": "Calculate MD5 hash of a string",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "string",
              "type": "string",
              "required": true,
              "desc_vi": "Chuỗi đầu vào",
              "desc_en": "Input string"
            }
          ],
          "returns": "string — 32-char hex hash",
          "example": "local hash = md5(\"hello\")\nlog(hash)  -- \"5d41402abc4b2a76b9719d911017c592\""
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "showOverlay(data)",
          "base": "showOverlay",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Hiện bảng thống kê mờ trên màn hình (chạm xuyên qua)",
          "desc_en": "Show transparent stats overlay on screen (touch passes through)",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "data",
              "type": "table",
              "required": true,
              "desc_vi": "Bảng key-value hiển thị",
              "desc_en": "Key-value pairs to display"
            }
          ],
          "returns": "void",
          "example": "-- Show stats overlay\nshowOverlay({\n  [\"Runs\"] = \"0\",\n  [\"Success\"] = \"0\",\n  [\"Fails\"] = \"0\"\n})\n\n-- Update during automation loop\nfor i = 1, 100 do\n  updateOverlay(\"Runs\", i)\n  -- do automation...\n  updateOverlay(\"Success\", success)\nend\n\nhideOverlay()"
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "updateOverlay(key, value)",
          "base": "updateOverlay",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Cập nhật 1 dòng trong overlay",
          "desc_en": "Update a single entry in the overlay",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "key",
              "type": "string",
              "required": true,
              "desc_vi": "Tên thống kê",
              "desc_en": "Stat name"
            },
            {
              "name": "value",
              "type": "string|number",
              "required": true,
              "desc_vi": "Giá trị mới",
              "desc_en": "New value"
            }
          ],
          "returns": "void",
          "example": "updateOverlay(\"Runs\", 42)\nupdateOverlay(\"Status\", \"Running...\")"
        },
        {
          "category_id": "interact",
          "category_vi": "Tương tác",
          "category_en": "User Interaction",
          "kind": "function",
          "name": "hideOverlay()",
          "base": "hideOverlay",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Ẩn bảng thống kê",
          "desc_en": "Remove the stats overlay from screen",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "void",
          "example": "hideOverlay()"
        }
      ]
    },
    {
      "id": "app",
      "title_vi": "Quản lý ứng dụng",
      "title_en": "App Management",
      "items": [
        {
          "category_id": "app",
          "category_vi": "Quản lý ứng dụng",
          "category_en": "App Management",
          "kind": "function",
          "name": "appRun(bundleId)",
          "base": "appRun",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Mở ứng dụng bằng bundle ID",
          "desc_en": "Launch an app by bundle ID",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "bundleId",
              "type": "string",
              "required": true,
              "desc_vi": "Bundle ID ứng dụng",
              "desc_en": "App bundle identifier"
            }
          ],
          "returns": "void",
          "example": "-- Open Safari and navigate to a URL\nappRun(\"com.apple.safari\")\nsleep(2)\n-- Tap the address bar\ntap(214, 52)\nsleep(0.5)\ninputText(\"https://google.com\")\nsleep(0.3)\nkeyDown(\"return\")"
        },
        {
          "category_id": "app",
          "category_vi": "Quản lý ứng dụng",
          "category_en": "App Management",
          "kind": "function",
          "name": "appKill(bundleId)",
          "base": "appKill",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đóng/tắt ứng dụng đang chạy",
          "desc_en": "Close/kill a running app",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "bundleId",
              "type": "string",
              "required": true,
              "desc_vi": "Bundle ID ứng dụng",
              "desc_en": "App bundle identifier"
            }
          ],
          "returns": "void",
          "example": "appKill(\"com.apple.mobilesafari\")\nsleep(1)\nlog(\"Safari killed\")"
        },
        {
          "category_id": "app",
          "category_vi": "Quản lý ứng dụng",
          "category_en": "App Management",
          "kind": "function",
          "name": "appState(bundleId)",
          "base": "appState",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Kiểm tra ứng dụng có đang chạy",
          "desc_en": "Check if an app is running",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "bundleId",
              "type": "string",
              "required": true,
              "desc_vi": "Bundle ID ứng dụng",
              "desc_en": "App bundle identifier"
            }
          ],
          "returns": {
            "en": "number — 0=not running, 1=background, 4=foreground",
            "vi": "number — 0=không chạy, 1=nền, 4=đang hoạt động"
          },
          "example": "-- Restart game if it crashed\nlocal state = appState(\"com.game.myapp\")\nif state == 0 then\n  log(\"Game not running, restarting...\")\n  appRun(\"com.game.myapp\")\n  sleep(3)\nelseif state == 1 then\n  log(\"Game in background, bringing to front\")\n  appRun(\"com.game.myapp\")\nelse\n  log(\"Game is active, continuing script\")\nend"
        },
        {
          "category_id": "app",
          "category_vi": "Quản lý ứng dụng",
          "category_en": "App Management",
          "kind": "function",
          "name": "openURL(url)",
          "base": "openURL",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Mở URL hoặc URL scheme",
          "desc_en": "Open a URL or URL scheme",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "url",
              "type": "string",
              "required": true,
              "desc_vi": "URL cần mở (http/https hoặc scheme ứng dụng)",
              "desc_en": "URL to open (http/https or app scheme)"
            }
          ],
          "returns": "void",
          "example": "-- Open website\nopenURL(\"https://google.com\")\n\n-- Deep link to Instagram\nopenURL(\"instagram://user?username=abc\")"
        }
      ]
    },
    {
      "id": "input",
      "title_vi": "Nhập liệu & Bàn phím",
      "title_en": "Text & Input",
      "items": [
        {
          "category_id": "input",
          "category_vi": "Nhập liệu & Bàn phím",
          "category_en": "Text & Input",
          "kind": "function",
          "name": "inputText(text)",
          "base": "inputText",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Nhập chuỗi văn bản trên thiết bị",
          "desc_en": "Type text string on device",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Văn bản cần nhập",
              "desc_en": "Text to type"
            }
          ],
          "returns": "void",
          "example": "-- Fill a login form\ntap(200, 300)  -- Tap email field\nsleep(0.3)\ninputText(\"user@email.com\")\nsleep(0.2)\ntap(200, 400)  -- Tap password field\nsleep(0.3)\ninputText(\"mypassword123\")\ntap(200, 500)  -- Tap login button"
        },
        {
          "category_id": "input",
          "category_vi": "Nhập liệu & Bàn phím",
          "category_en": "Text & Input",
          "kind": "function",
          "name": "keyDown(keyType)",
          "base": "keyDown",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Nhấn phím cứng",
          "desc_en": "Press a hardware key",
          "note_vi": "HIDProbe dùng kiểu nhấn phím/alias; không phải lúc nào cũng giữ phím liên tục như IOSControl gốc.",
          "params": [
            {
              "name": "keyType",
              "type": "string",
              "required": true,
              "desc_vi": "Tên phím: home, volumeUp, volumeDown, power",
              "desc_en": "Key name: home, volumeUp, volumeDown, power"
            }
          ],
          "returns": "void",
          "example": "-- Press Home button\nkeyDown(\"home\")\nsleep(0.1)\nkeyUp(\"home\")"
        },
        {
          "category_id": "input",
          "category_vi": "Nhập liệu & Bàn phím",
          "category_en": "Text & Input",
          "kind": "function",
          "name": "keyUp(keyType)",
          "base": "keyUp",
          "status": "partial",
          "compatibility": {
            "label": "PARTIAL",
            "vi": "Có hàm nhưng cần lưu ý/kiểm chứng thực tế",
            "className": "warn"
          },
          "desc_vi": "Nhả phím cứng",
          "desc_en": "Release a hardware key",
          "note_vi": "Hiện là no-op/compat cho nhiều phím; chỉ dùng nếu test thật chứng minh cần.",
          "params": [
            {
              "name": "keyType",
              "type": "string",
              "required": true,
              "desc_vi": "Tên phím",
              "desc_en": "Key name"
            }
          ],
          "returns": "void",
          "example": "keyUp(\"home\")"
        },
        {
          "category_id": "input",
          "category_vi": "Nhập liệu & Bàn phím",
          "category_en": "Text & Input",
          "kind": "function",
          "name": "getClipboard()",
          "base": "getClipboard",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy nội dung clipboard",
          "desc_en": "Get clipboard text content",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [],
          "returns": "string",
          "example": "-- Copy text from app and log it\nlongPress(200, 300, 1.0)\nsleep(0.5)\ntap(250, 260)  -- Tap \"Copy\" in menu\nsleep(0.3)\nlocal text = getClipboard()\nlog(\"Copied: \" .. text)"
        },
        {
          "category_id": "input",
          "category_vi": "Nhập liệu & Bàn phím",
          "category_en": "Text & Input",
          "kind": "function",
          "name": "setClipboard(text)",
          "base": "setClipboard",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đặt nội dung clipboard",
          "desc_en": "Set clipboard text content",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "text",
              "type": "string",
              "required": true,
              "desc_vi": "Văn bản cần đặt",
              "desc_en": "Text to set"
            }
          ],
          "returns": "void",
          "example": "-- Paste a promo code into input field\nsetClipboard(\"PROMO2024\")\ntap(200, 300)  -- Focus input\nsleep(0.3)\nlongPress(200, 300, 1.0)\nsleep(0.5)\ntap(200, 260)  -- Tap \"Paste\""
        }
      ]
    },
    {
      "id": "ui",
      "title_vi": "Giao diện & Phản hồi",
      "title_en": "UI & Feedback",
      "items": [
        {
          "category_id": "ui",
          "category_vi": "Giao diện & Phản hồi",
          "category_en": "UI & Feedback",
          "kind": "function",
          "name": "toast(message, delay)",
          "base": "toast",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Hiện thông báo tạm thời trên thiết bị",
          "desc_en": "Show temporary notification on device",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "message",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung thông báo",
              "desc_en": "Message text"
            },
            {
              "name": "delay",
              "type": "number",
              "required": false,
              "desc_vi": "Thời gian hiển thị (giây, mặc định: 2)",
              "desc_en": "Display duration in seconds (default: 2)"
            }
          ],
          "returns": "void",
          "example": "toast(\"Bước 1 hoàn thành!\", 3)\nsleep(2)\ntoast(\"Đang xử lý bước 2...\", 2)"
        },
        {
          "category_id": "ui",
          "category_vi": "Giao diện & Phản hồi",
          "category_en": "UI & Feedback",
          "kind": "function",
          "name": "alert(message)",
          "base": "alert",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Hiện hộp thoại cảnh báo",
          "desc_en": "Show alert dialog popup",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "message",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung cảnh báo",
              "desc_en": "Alert message"
            }
          ],
          "returns": "void",
          "example": "alert(\"Nhấn OK để tiếp tục!\")"
        },
        {
          "category_id": "ui",
          "category_vi": "Giao diện & Phản hồi",
          "category_en": "UI & Feedback",
          "kind": "function",
          "name": "vibrate()",
          "base": "vibrate",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Rung thiết bị",
          "desc_en": "Vibrate the device",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [],
          "returns": "void",
          "example": "-- Rung khi hoàn thành\nvibrate()\nlog(\"Done!\")"
        },
        {
          "category_id": "ui",
          "category_vi": "Giao diện & Phản hồi",
          "category_en": "UI & Feedback",
          "kind": "function",
          "name": "log(message)",
          "base": "log",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Ghi log ra console",
          "desc_en": "Log message to console",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "message",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung log",
              "desc_en": "Log message"
            }
          ],
          "returns": "void",
          "example": "log(\"Hello!\")\nlog(\"Count: \" .. 42)\nlog(\"Table: \" .. jsonEncode({a = 1}))"
        }
      ]
    },
    {
      "id": "timing",
      "title_vi": "Thời gian & Chờ",
      "title_en": "Timing & Sleep",
      "items": [
        {
          "category_id": "timing",
          "category_vi": "Thời gian & Chờ",
          "category_en": "Timing & Sleep",
          "kind": "function",
          "name": "sleep(seconds)",
          "base": "sleep",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tạm dừng thực thi trong khoảng thời gian",
          "desc_en": "Pause execution for specified seconds",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "seconds",
              "type": "number",
              "required": true,
              "desc_vi": "Thời gian chờ (hỗ trợ số thập phân)",
              "desc_en": "Wait duration (supports decimals)"
            }
          ],
          "returns": "void",
          "example": "sleep(1.5)  -- Wait 1.5 seconds"
        },
        {
          "category_id": "timing",
          "category_vi": "Thời gian & Chờ",
          "category_en": "Timing & Sleep",
          "kind": "function",
          "name": "usleep(microseconds)",
          "base": "usleep",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Tạm dừng theo microsecond (độ chính xác cao)",
          "desc_en": "Pause for microseconds (high precision)",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "microseconds",
              "type": "number",
              "required": true,
              "desc_vi": "Thời gian chờ (microsecond)",
              "desc_en": "Wait in microseconds"
            }
          ],
          "returns": "void",
          "example": "usleep(500000)  -- Wait 0.5s"
        },
        {
          "category_id": "timing",
          "category_vi": "Thời gian & Chờ",
          "category_en": "Timing & Sleep",
          "kind": "function",
          "name": "randomSleep(min, max)",
          "base": "randomSleep",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Ngủ ngẫu nhiên trong khoảng min đến max",
          "desc_en": "Sleep random duration between min and max",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "min",
              "type": "number",
              "required": true,
              "desc_vi": "Tối thiểu (giây)",
              "desc_en": "Minimum seconds"
            },
            {
              "name": "max",
              "type": "number",
              "required": true,
              "desc_vi": "Tối đa (giây)",
              "desc_en": "Maximum seconds"
            }
          ],
          "returns": "void",
          "example": "-- Anti-detection random delay\nrandomSleep(1.0, 3.0)\nlog(\"Done waiting\")"
        }
      ]
    },
    {
      "id": "screen",
      "title_vi": "Thông tin màn hình",
      "title_en": "Screen Info",
      "items": [
        {
          "category_id": "screen",
          "category_vi": "Thông tin màn hình",
          "category_en": "Screen Info",
          "kind": "function",
          "name": "screenSize()",
          "base": "screenSize",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy kích thước màn hình",
          "desc_en": "Get screen dimensions",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [],
          "returns": "table — {width, height}",
          "example": "local s = screenSize()\nlog(\"Screen: \" .. s.width .. \"x\" .. s.height)\n-- iPhone 8 Plus: 414x736"
        },
        {
          "category_id": "screen",
          "category_vi": "Thông tin màn hình",
          "category_en": "Screen Info",
          "kind": "function",
          "name": "deviceInfo()",
          "base": "deviceInfo",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Lấy thông tin thiết bị, iOS, pin",
          "desc_en": "Get device model, iOS version, battery",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [],
          "returns": "table — device details",
          "example": "local d = deviceInfo()\nlog(\"Model: \" .. d.model)\nlog(\"iOS: \" .. d.version)\nlog(\"Name: \" .. d.name)"
        }
      ]
    },
    {
      "id": "http",
      "title_vi": "HTTP Client",
      "title_en": "HTTP Client",
      "items": [
        {
          "category_id": "http",
          "category_vi": "HTTP Client",
          "category_en": "HTTP Client",
          "kind": "function",
          "name": "httpGet(url, params, headers)",
          "base": "httpGet",
          "status": "partial",
          "compatibility": {
            "label": "PARTIAL",
            "vi": "Có hàm nhưng cần lưu ý/kiểm chứng thực tế",
            "className": "warn"
          },
          "desc_vi": "Gửi yêu cầu HTTP GET",
          "desc_en": "HTTP GET request",
          "note_vi": "Bản EXTOK_HTTP_LUA gọi native URLSession trực tiếp. Không log API key; job vẫn cần bằng chứng màn hình + response server để gọi PASS.",
          "params": [
            {
              "name": "url",
              "type": "string",
              "required": true,
              "desc_vi": "URL yêu cầu",
              "desc_en": "Request URL"
            },
            {
              "name": "params",
              "type": "table",
              "required": false,
              "desc_vi": "Dict tham số query (sẽ nối thành ?key=val&...)",
              "desc_en": "Query parameters dict (will be appended as ?key=val&...)"
            },
            {
              "name": "headers",
              "type": "table",
              "required": false,
              "desc_vi": "Headers tuỳ chọn",
              "desc_en": "Optional headers"
            }
          ],
          "returns": "table — {ok, status, body, headers, error, url}",
          "example": "-- Fetch game server config\nlocal r = httpGet(\"https://api.example.com/config\", {\n  version = \"1.2.0\",\n  platform = \"ios\"\n})\nif r.status == 200 then\n  local config = jsonDecode(r.body)\n  log(\"Server version: \" .. config.version)\n  log(\"Maintenance: \" .. tostring(config.maintenance))\nelse\n  log(\"Error: HTTP \" .. r.status)\nend"
        },
        {
          "category_id": "http",
          "category_vi": "HTTP Client",
          "category_en": "HTTP Client",
          "kind": "function",
          "name": "httpPost(url, body, headers)",
          "base": "httpPost",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Gửi yêu cầu HTTP POST",
          "desc_en": "HTTP POST request",
          "note_vi": "Bản EXTOK_HTTP_LUA gọi native URLSession trực tiếp. Không log API key; job vẫn cần bằng chứng màn hình + response server để gọi PASS.",
          "params": [
            {
              "name": "url",
              "type": "string",
              "required": true,
              "desc_vi": "URL yêu cầu",
              "desc_en": "Request URL"
            },
            {
              "name": "body",
              "type": "table|string",
              "required": true,
              "desc_vi": "Nội dung yêu cầu",
              "desc_en": "Request body"
            },
            {
              "name": "headers",
              "type": "table",
              "required": false,
              "desc_vi": "Headers tuỳ chọn",
              "desc_en": "Optional headers"
            }
          ],
          "returns": "table — {ok, status, body, headers, error, url}",
          "example": "-- POST JSON with headers\nlocal body = jsonEncode({\n    username = \"admin\",\n    password = \"123456\"\n})\nlocal r = httpPost(\n    \"https://api.example.com/login\",\n    body,\n    {[\"Content-Type\"] = \"application/json\"}\n)\nlocal result = jsonDecode(r.body)\nlog(\"Token: \" .. result.token)"
        }
      ]
    },
    {
      "id": "proxy",
      "title_vi": "Proxy",
      "title_en": "Proxy",
      "items": [
        {
          "category_id": "proxy",
          "category_vi": "Proxy",
          "category_en": "Proxy",
          "kind": "function",
          "name": "setProxySystem(host, port)",
          "base": "setProxySystem",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Đặt proxy toàn thiết bị qua Wi-Fi. Hiện tại chỉ hỗ trợ IP:Port.",
          "desc_en": "Set device-wide Wi-Fi proxy. Only IP:Port supported currently.",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "host",
              "type": "string",
              "required": true,
              "desc_vi": "IP Proxy",
              "desc_en": "Proxy IP"
            },
            {
              "name": "port",
              "type": "number",
              "required": true,
              "desc_vi": "Cổng Proxy",
              "desc_en": "Proxy Port"
            }
          ],
          "returns": "void",
          "example": "-- Set system proxy and reset connections\nsetProxySystem(\"160.25.77.31\", 8770)\nsetAirplaneMode(true)\nsleep(1)\nsetAirplaneMode(false)"
        },
        {
          "category_id": "proxy",
          "category_vi": "Proxy",
          "category_en": "Proxy",
          "kind": "function",
          "name": "clearProxySystem()",
          "base": "clearProxySystem",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Tắt proxy hệ thống Wi-Fi. Khôi phục kết nối trực tiếp.",
          "desc_en": "Disable device-wide Wi-Fi proxy. Restores direct connection.",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "void",
          "example": "clearProxySystem()\nlog(\"Proxy removed\")"
        }
      ]
    },
    {
      "id": "file",
      "title_vi": "Tệp & JSON",
      "title_en": "File & JSON",
      "items": [
        {
          "category_id": "file",
          "category_vi": "Tệp & JSON",
          "category_en": "File & JSON",
          "kind": "function",
          "name": "readFile(path)",
          "base": "readFile",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đọc nội dung tệp văn bản",
          "desc_en": "Read text file contents",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Đường dẫn tệp",
              "desc_en": "File path"
            }
          ],
          "returns": "string",
          "example": "-- Load saved settings\nlocal raw = readFile(\"/var/mobile/Library/IOSControl/config.json\")\nlocal config = jsonDecode(raw)\nlog(\"Loops: \" .. config.loops)\nlog(\"Delay: \" .. config.delay .. \"s\")"
        },
        {
          "category_id": "file",
          "category_vi": "Tệp & JSON",
          "category_en": "File & JSON",
          "kind": "function",
          "name": "writeFile(path, content)",
          "base": "writeFile",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Ghi chuỗi vào tệp",
          "desc_en": "Write string to file",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Đường dẫn tệp",
              "desc_en": "File path"
            },
            {
              "name": "content",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung tệp",
              "desc_en": "File content"
            }
          ],
          "returns": "void",
          "example": "-- Save automation results to log\nlocal results = {\n  coins = 1500,\n  runs = 10,\n  time = os.date(\"%Y-%m-%d %H:%M:%S\")\n}\nwriteFile(\"results.json\", jsonEncode(results))\nlog(\"Results saved!\")"
        },
        {
          "category_id": "file",
          "category_vi": "Tệp & JSON",
          "category_en": "File & JSON",
          "kind": "function",
          "name": "appendFile(path, content)",
          "base": "appendFile",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Ghi thêm vào cuối file (tạo nếu chưa có)",
          "desc_en": "Append text to file (creates if not exists)",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "path",
              "type": "string",
              "required": true,
              "desc_vi": "Đường dẫn tệp",
              "desc_en": "File path"
            },
            {
              "name": "content",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung ghi thêm",
              "desc_en": "Text to append"
            }
          ],
          "returns": "boolean",
          "example": "-- Log results to file\nfor i = 1, 10 do\n  tap(200, 400)\n  sleep(1)\n  appendFile(\"log.txt\", \"Run \" .. i .. \" done\\n\")\nend"
        },
        {
          "category_id": "file",
          "category_vi": "Tệp & JSON",
          "category_en": "File & JSON",
          "kind": "function",
          "name": "jsonDecode(str)",
          "base": "jsonDecode",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Phân tích chuỗi JSON sang bảng",
          "desc_en": "Parse JSON string to table",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "str",
              "type": "string",
              "required": true,
              "desc_vi": "Chuỗi JSON",
              "desc_en": "JSON string"
            }
          ],
          "returns": "table",
          "example": "local json = '{\"name\":\"Trieu\",\"age\":25,\"items\":[1,2,3]}'\nlocal t = jsonDecode(json)\nlog(t.name)     -- \"Trieu\"\nlog(t.age)      -- 25\nlog(t.items[1]) -- 1"
        },
        {
          "category_id": "file",
          "category_vi": "Tệp & JSON",
          "category_en": "File & JSON",
          "kind": "function",
          "name": "jsonEncode(table)",
          "base": "jsonEncode",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chuyển bảng thành chuỗi JSON",
          "desc_en": "Convert table to JSON string",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "table",
              "type": "table",
              "required": true,
              "desc_vi": "Bảng Lua",
              "desc_en": "Lua table"
            }
          ],
          "returns": "string",
          "example": "local t = {\n    name = \"Trieu\",\n    age = 25,\n    items = {1, 2, 3},\n    nested = {key = \"value\"}\n}\nlocal json = jsonEncode(t)\nlog(json)"
        }
      ]
    },
    {
      "id": "util",
      "title_vi": "Tiện ích",
      "title_en": "Utilities",
      "items": [
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "randomInt(min, max)",
          "base": "randomInt",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Số nguyên ngẫu nhiên trong khoảng",
          "desc_en": "Random integer in range",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "min",
              "type": "number",
              "required": true,
              "desc_vi": "Tối thiểu",
              "desc_en": "Minimum"
            },
            {
              "name": "max",
              "type": "number",
              "required": true,
              "desc_vi": "Tối đa",
              "desc_en": "Maximum"
            }
          ],
          "returns": "number",
          "example": "-- Random tap offset (anti-detection)\nlocal dx = randomInt(-5, 5)\nlocal dy = randomInt(-5, 5)\ntap(207 + dx, 400 + dy)"
        },
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "randomFloat(min, max)",
          "base": "randomFloat",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Số thực ngẫu nhiên trong khoảng",
          "desc_en": "Random float in range",
          "note_vi": "Có wrapper trong HIDProbe ioscontrol-v1.",
          "params": [
            {
              "name": "min",
              "type": "number",
              "required": true,
              "desc_vi": "Tối thiểu",
              "desc_en": "Minimum"
            },
            {
              "name": "max",
              "type": "number",
              "required": true,
              "desc_vi": "Tối đa",
              "desc_en": "Maximum"
            }
          ],
          "returns": "number",
          "example": "local d = randomFloat(0.1, 0.5)"
        },
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "wifiInfo()",
          "base": "wifiInfo",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy SSID WiFi và địa chỉ IP",
          "desc_en": "Get WiFi SSID and IP address",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "table — {ssid, ip}",
          "example": "local w = wifiInfo()\nlog(w.ip)"
        },
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "setCellularData(enabled, delay)",
          "base": "setCellularData",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Bật/tắt dữ liệu di động 4G",
          "desc_en": "Toggle 4G/cellular data on or off",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "enabled",
              "type": "boolean",
              "required": true,
              "desc_vi": "true = bật, false = tắt",
              "desc_en": "true = on, false = off"
            },
            {
              "name": "delay",
              "type": "number",
              "required": false,
              "desc_vi": "Tự phục hồi sau N giây (tuỳ chọn)",
              "desc_en": "Auto-restore after N seconds (optional)"
            }
          ],
          "returns": "void",
          "example": "-- Turn off cellular for 5 seconds then back on\nsetCellularData(false, 5)\n\n-- Permanently turn off\nsetCellularData(false)\n\n-- Turn back on\nsetCellularData(true)"
        },
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "setAirplaneMode(enabled, delay)",
          "base": "setAirplaneMode",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Bật/tắt chế độ máy bay",
          "desc_en": "Toggle airplane mode on or off",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "enabled",
              "type": "boolean",
              "required": true,
              "desc_vi": "true = bật, false = tắt",
              "desc_en": "true = on, false = off"
            },
            {
              "name": "delay",
              "type": "number",
              "required": false,
              "desc_vi": "Tự phục hồi sau N giây (tuỳ chọn)",
              "desc_en": "Auto-restore after N seconds (optional)"
            }
          ],
          "returns": "void",
          "example": "-- Reset network: airplane on 3s then off\nsetAirplaneMode(true, 3)\nsleep(4)\nlog(\"Network reset complete\")"
        },
        {
          "category_id": "util",
          "category_vi": "Tiện ích",
          "category_en": "Utilities",
          "kind": "function",
          "name": "getIP()",
          "base": "getIP",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy IP công cộng (qua api.ipify.org)",
          "desc_en": "Get public IP address (via api.ipify.org)",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string — public IP address",
          "example": "-- Check IP before and after airplane mode\nlocal ip1 = getIP()\nlog(\"Before: \" .. ip1)\nsetAirplaneMode(true, 3)\nsleep(5)\nlocal ip2 = getIP()\nlog(\"After: \" .. ip2)"
        }
      ]
    },
    {
      "id": "record",
      "title_vi": "Ghi & Phát lại",
      "title_en": "Record & Playback",
      "items": [
        {
          "category_id": "record",
          "category_vi": "Ghi & Phát lại",
          "category_en": "Record & Playback",
          "kind": "function",
          "name": "recordStart()",
          "base": "recordStart",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Bắt đầu ghi sự kiện chạm",
          "desc_en": "Start recording touch events",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "void",
          "example": "-- Record a login flow and save it\nlog(\"Recording started... perform actions on device\")\nrecordStart()\nsleep(10)  -- Wait for user to perform actions\nlocal events = recordStop()\nlog(\"Recorded \" .. #events .. \" events\")\nrecordSave(\"login_flow\")\nlog(\"Saved as login_flow\")"
        },
        {
          "category_id": "record",
          "category_vi": "Ghi & Phát lại",
          "category_en": "Record & Playback",
          "kind": "function",
          "name": "recordStop()",
          "base": "recordStop",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Dừng ghi và lưu sự kiện",
          "desc_en": "Stop recording and save events",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "table — recorded events",
          "example": "local events = recordStop()"
        },
        {
          "category_id": "record",
          "category_vi": "Ghi & Phát lại",
          "category_en": "Record & Playback",
          "kind": "function",
          "name": "recordPlay(events)",
          "base": "recordPlay",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Phát lại sự kiện đã ghi",
          "desc_en": "Replay recorded events",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "events",
              "type": "table",
              "required": true,
              "desc_vi": "Sự kiện từ recordStop()",
              "desc_en": "Events from recordStop()"
            }
          ],
          "returns": "void",
          "example": "recordPlay(events)"
        },
        {
          "category_id": "record",
          "category_vi": "Ghi & Phát lại",
          "category_en": "Record & Playback",
          "kind": "function",
          "name": "recordSave(name)",
          "base": "recordSave",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lưu bản ghi vào tệp",
          "desc_en": "Save recording to file",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên bản ghi",
              "desc_en": "Recording name"
            }
          ],
          "returns": "void",
          "example": "recordSave(\"login_flow\")"
        },
        {
          "category_id": "record",
          "category_vi": "Ghi & Phát lại",
          "category_en": "Record & Playback",
          "kind": "function",
          "name": "recordLoad(name)",
          "base": "recordLoad",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Tải bản ghi từ tệp",
          "desc_en": "Load recording from file",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên bản ghi",
              "desc_en": "Recording name"
            }
          ],
          "returns": "table — events",
          "example": "local e = recordLoad(\"login_flow\")\nrecordPlay(e)"
        }
      ]
    },
    {
      "id": "schedule",
      "title_vi": "Lập lịch",
      "title_en": "Scheduler",
      "items": [
        {
          "category_id": "schedule",
          "category_vi": "Lập lịch",
          "category_en": "Scheduler",
          "kind": "function",
          "name": "schedule(cron, script)",
          "base": "schedule",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lập lịch script bằng biểu thức cron",
          "desc_en": "Schedule script with cron expression",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "cron",
              "type": "string",
              "required": true,
              "desc_vi": "Biểu thức cron (VD: \"0 8 * * *\")",
              "desc_en": "Cron expression (e.g. \"0 8 * * *\")"
            },
            {
              "name": "script",
              "type": "string",
              "required": true,
              "desc_vi": "Tên tệp script",
              "desc_en": "Script filename"
            }
          ],
          "returns": "string — schedule ID",
          "example": "-- Run daily farm at 8 AM\nlocal id = schedule(\"0 8 * * *\", \"daily_farm.lua\")\nlog(\"Scheduled daily farm, ID: \" .. id)\n\n-- Run every 30 minutes\nschedule(\"*/30 * * * *\", \"check_energy.lua\")"
        },
        {
          "category_id": "schedule",
          "category_vi": "Lập lịch",
          "category_en": "Scheduler",
          "kind": "function",
          "name": "scheduleAfter(seconds, script)",
          "base": "scheduleAfter",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Chạy script sau khoảng thời gian",
          "desc_en": "Run script after delay",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "seconds",
              "type": "number",
              "required": true,
              "desc_vi": "Thời gian trì hoãn (giây)",
              "desc_en": "Delay in seconds"
            },
            {
              "name": "script",
              "type": "string",
              "required": true,
              "desc_vi": "Tên tệp script",
              "desc_en": "Script filename"
            }
          ],
          "returns": "string — schedule ID",
          "example": "scheduleAfter(3600, \"hourly.lua\")"
        },
        {
          "category_id": "schedule",
          "category_vi": "Lập lịch",
          "category_en": "Scheduler",
          "kind": "function",
          "name": "onNotification(app, action)",
          "base": "onNotification",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Kích hoạt hành động khi có thông báo đẩy",
          "desc_en": "Trigger action on push notification",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [
            {
              "name": "app",
              "type": "string",
              "required": true,
              "desc_vi": "Bundle ID ứng dụng",
              "desc_en": "App bundle ID"
            },
            {
              "name": "action",
              "type": "function",
              "required": true,
              "desc_vi": "Hàm callback",
              "desc_en": "Callback function"
            }
          ],
          "returns": "void",
          "example": "-- Auto-reply when WhatsApp notification arrives\nonNotification(\"net.whatsapp.WhatsApp\", function(info)\n  log(\"New message from: \" .. info.title)\n  appRun(\"net.whatsapp.WhatsApp\")\n  sleep(2)\n  -- Tap the notification chat\n  tap(200, 100)\n  sleep(1)\n  inputText(\"Auto-reply: I'm busy right now\")\n  tap(380, 800)  -- Send button\nend)"
        }
      ]
    },
    {
      "id": "rest",
      "title_vi": "HTTP APIs",
      "title_en": "HTTP APIs",
      "items": [
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "POST /api/scripts/run",
          "base": "POST /api/scripts/run",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Chạy script — thực thi code Lua trên thiết bị",
          "desc_en": "Play a script — execute Lua code on the device",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [
            {
              "name": "code",
              "type": "string",
              "required": true,
              "desc_vi": "Code Lua cần thực thi",
              "desc_en": "Lua code to execute"
            },
            {
              "name": "scriptName",
              "type": "string",
              "required": false,
              "desc_vi": "Tên file script (để theo dõi)",
              "desc_en": "Script filename (for tracking)"
            }
          ],
          "returns": "JSON {success, taskId}",
          "example": "curl -X POST http://{device-ip}:9999/api/scripts/run \\\\\n  -H \"Content-Type: application/json\" \\\\\n  -d '{\"code\":\"tap(100,200)\\nsleep(1)\\nlog(\\\"done\\\")\", \"scriptName\":\"test.lua\"}'"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "POST /api/scripts/stop",
          "base": "POST /api/scripts/stop",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Dừng script đang chạy — gửi tín hiệu dừng",
          "desc_en": "Stop playing a script — sends stop signal to running script",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [],
          "returns": "JSON {success, message}",
          "example": "curl -X POST http://{device-ip}:9999/api/scripts/stop"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "GET /api/scripts/running",
          "base": "GET /api/scripts/running",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Kiểm tra script có đang chạy không",
          "desc_en": "Check if a script is currently running",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [],
          "returns": "JSON {running, taskId, scriptName}",
          "example": "curl http://{device-ip}:9999/api/scripts/running\n\n# Response: {\"running\":true,\"taskId\":\"ABC-123\",\"scriptName\":\"bot.lua\"}"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "GET /api/scripts/{taskId}/status",
          "base": "GET /api/scripts/{taskId}/status",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Lấy trạng thái thực thi và log của script",
          "desc_en": "Get script execution status and logs",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [
            {
              "name": "taskId",
              "type": "string",
              "required": true,
              "desc_vi": "Task ID trả về từ /run",
              "desc_en": "Task ID returned from /run"
            }
          ],
          "returns": "JSON {success, status, logs, error}",
          "example": "curl http://{device-ip}:9999/api/scripts/ABC-123/status\n\n# Response: {\"success\":true,\"status\":\"done\",\"logs\":[{\"message\":\"done\"}]}"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "GET /api/scripts/files",
          "base": "GET /api/scripts/files",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Liệt kê file trong thư mục scripts",
          "desc_en": "List files in scripts directory",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [],
          "returns": "JSON {success, files: [{name, size, modified}]}",
          "example": "curl http://{device-ip}:9999/api/scripts/files"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "GET /api/scripts/load",
          "base": "GET /api/scripts/load",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Đọc nội dung file script",
          "desc_en": "Load a script file content",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file script",
              "desc_en": "Script filename"
            }
          ],
          "returns": "JSON {success, name, code}",
          "example": "curl \"http://{device-ip}:9999/api/scripts/load?name=bot.lua\""
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "POST /api/scripts/save",
          "base": "POST /api/scripts/save",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Tạo hoặc cập nhật file script",
          "desc_en": "Create or update a script file",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file script",
              "desc_en": "Script filename"
            },
            {
              "name": "code",
              "type": "string",
              "required": true,
              "desc_vi": "Nội dung script",
              "desc_en": "Script content"
            }
          ],
          "returns": "JSON {success, name}",
          "example": "curl -X POST http://{device-ip}:9999/api/scripts/save \\\\\n  -H \"Content-Type: application/json\" \\\\\n  -d '{\"name\":\"bot.lua\",\"code\":\"tap(100,200)\"}'"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "POST /api/scripts/delete",
          "base": "POST /api/scripts/delete",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Xóa file script",
          "desc_en": "Delete a script file",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [
            {
              "name": "name",
              "type": "string",
              "required": true,
              "desc_vi": "Tên file script cần xóa",
              "desc_en": "Script filename to delete"
            }
          ],
          "returns": "JSON {success}",
          "example": "curl -X POST http://{device-ip}:9999/api/scripts/delete \\\\\n  -H \"Content-Type: application/json\" \\\\\n  -d '{\"name\":\"old_script.lua\"}'"
        },
        {
          "category_id": "rest",
          "category_vi": "HTTP APIs",
          "category_en": "HTTP APIs",
          "kind": "route",
          "name": "GET /ping",
          "base": "GET /ping",
          "status": "route",
          "compatibility": {
            "label": "HTTP",
            "vi": "Route HTTP của IOSControl gốc; HIDProbe dùng self-host route riêng",
            "className": "route"
          },
          "desc_vi": "Kiểm tra daemon đang chạy",
          "desc_en": "Health check — verify daemon is running",
          "note_vi": "Route IOSControl gốc để tham khảo; HIDProbe hiện dùng self-host API riêng.",
          "params": [],
          "returns": "JSON {status, version, name, ip}",
          "example": "curl http://{device-ip}:9999/ping\n\n# Response: {\"status\":\"ok\",\"version\":\"1.0.0\",\"name\":\"IOSControl\",\"ip\":\"192.168.1.x\"}"
        }
      ]
    },
    {
      "id": "spoof",
      "title_vi": "Giả lập thiết bị",
      "title_en": "Device Spoofing",
      "items": [
        {
          "category_id": "spoof",
          "category_vi": "Giả lập thiết bị",
          "category_en": "Device Spoofing",
          "kind": "function",
          "name": "ic.spoof.name()",
          "base": "ic.spoof.name",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy tên thiết bị đang fake",
          "desc_en": "Get current spoofed device name",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string",
          "example": "local name = ic.spoof.name()\nlog(\"Spoofed as: \" .. name)"
        },
        {
          "category_id": "spoof",
          "category_vi": "Giả lập thiết bị",
          "category_en": "Device Spoofing",
          "kind": "function",
          "name": "ic.spoof.model()",
          "base": "ic.spoof.model",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy mã model đang fake",
          "desc_en": "Get current spoofed model identifier",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string (e.g. \"iPhone15,3\")",
          "example": "local m = ic.spoof.model()\nlog(\"Model: \" .. m)  -- iPhone15,3"
        },
        {
          "category_id": "spoof",
          "category_vi": "Giả lập thiết bị",
          "category_en": "Device Spoofing",
          "kind": "function",
          "name": "ic.spoof.ios()",
          "base": "ic.spoof.ios",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy phiên bản iOS đang fake",
          "desc_en": "Get current spoofed iOS version",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string (e.g. \"16.5.1\")",
          "example": "log(\"iOS: \" .. ic.spoof.ios())"
        },
        {
          "category_id": "spoof",
          "category_vi": "Giả lập thiết bị",
          "category_en": "Device Spoofing",
          "kind": "function",
          "name": "ic.spoof.serial()",
          "base": "ic.spoof.serial",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy số serial đang fake",
          "desc_en": "Get current spoofed serial number",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string",
          "example": "log(\"Serial: \" .. ic.spoof.serial())"
        },
        {
          "category_id": "spoof",
          "category_vi": "Giả lập thiết bị",
          "category_en": "Device Spoofing",
          "kind": "function",
          "name": "ic.spoof.carrier()",
          "base": "ic.spoof.carrier",
          "status": "stub",
          "compatibility": {
            "label": "STUB",
            "vi": "Có tên hàm để AI không nhầm, nhưng hiện trả unsupported",
            "className": "bad"
          },
          "desc_vi": "Lấy tên nhà mạng đang fake",
          "desc_en": "Get current spoofed carrier name",
          "note_vi": "Có tên hàm trong profile để AI biết, nhưng hiện trả unsupported hoặc chưa có runtime thật.",
          "params": [],
          "returns": "string",
          "example": "log(\"Carrier: \" .. ic.spoof.carrier())"
        }
      ]
    },
    {
      "id": "hidprobe-extra",
      "title_vi": "HIDProbe thêm",
      "title_en": "HIDProbe extras",
      "items": [
        {
          "category_id": "hidprobe-extra",
          "category_vi": "HIDProbe thêm",
          "category_en": "HIDProbe extras",
          "kind": "function",
          "name": "runBatch(config)",
          "base": "runBatch",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Chạy lặp theo lô: ví dụ chạy 10 lần rồi nghỉ 20 phút, có giới hạn lỗi và jitter.",
          "desc_en": "Run repeat/rest batches with failure limit and jitter.",
          "params": [],
          "returns": "boolean",
          "example": "runBatch({\n  name = \"cycle\",\n  runs_per_cycle = 10,\n  rest_minutes = 20,\n  max_failures = 3,\n  step = function(i, cycle)\n    reportStep(\"cycle=\" .. cycle .. \" run=\" .. i)\n    return true\n  end\n})"
        },
        {
          "category_id": "hidprobe-extra",
          "category_vi": "HIDProbe thêm",
          "category_en": "HIDProbe extras",
          "kind": "function",
          "name": "reportStep(message)",
          "base": "reportStep",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Gửi log bước đang chạy về web/script-events.",
          "desc_en": "Report current step to web script-events.",
          "params": [],
          "returns": "void",
          "example": "reportStep(\"open_appstore:start\")"
        },
        {
          "category_id": "hidprobe-extra",
          "category_vi": "HIDProbe thêm",
          "category_en": "HIDProbe extras",
          "kind": "function",
          "name": "reportState(table)",
          "base": "reportState",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Gửi trạng thái có cấu trúc để web/AI đọc lại bằng chứng.",
          "desc_en": "Report structured state as execution evidence.",
          "params": [],
          "returns": "void",
          "example": "reportState({ stage = \"login\", screen = visibleText() })"
        },
        {
          "category_id": "hidprobe-extra",
          "category_vi": "HIDProbe thêm",
          "category_en": "HIDProbe extras",
          "kind": "function",
          "name": "reportResult(table)",
          "base": "reportResult",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Kết luận PASS/FAIL có lý do rõ ràng.",
          "desc_en": "Report final result with explicit reason.",
          "params": [],
          "returns": "void",
          "example": "reportResult({ ok = true, reason = \"app_opened\" })"
        },
        {
          "category_id": "hidprobe-extra",
          "category_vi": "HIDProbe thêm",
          "category_en": "HIDProbe extras",
          "kind": "function",
          "name": "fail(reason)",
          "base": "fail",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Dừng script và báo lỗi thật. Không dùng PASS giả.",
          "desc_en": "Stop script with a real failure reason.",
          "params": [],
          "returns": "never",
          "example": "if not ok then fail(\"appstore_open_failed\") end"
        }
      ]
    },
    {
      "id": "hidprobe-routes",
      "title_vi": "HIDProbe self-host route",
      "title_en": "HIDProbe self-host routes",
      "items": [
        {
          "category_id": "hidprobe-routes",
          "category_vi": "HIDProbe self-host route",
          "category_en": "HIDProbe self-host routes",
          "kind": "route",
          "name": "POST /api/v1/devices/{deviceId}/scripts",
          "base": "POST /api/v1/devices/{deviceId}/scripts",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đẩy Lua package + assets vào iPhone qua self-host signal.",
          "desc_en": "Đẩy Lua package + assets vào iPhone qua self-host signal.",
          "params": [],
          "returns": "json",
          "example": ""
        },
        {
          "category_id": "hidprobe-routes",
          "category_vi": "HIDProbe self-host route",
          "category_en": "HIDProbe self-host routes",
          "kind": "route",
          "name": "POST /api/v1/devices/{deviceId}/scripts/{scriptId}/run",
          "base": "POST /api/v1/devices/{deviceId}/scripts/{scriptId}/run",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Bắt đầu chạy script đã đẩy.",
          "desc_en": "Bắt đầu chạy script đã đẩy.",
          "params": [],
          "returns": "json",
          "example": ""
        },
        {
          "category_id": "hidprobe-routes",
          "category_vi": "HIDProbe self-host route",
          "category_en": "HIDProbe self-host routes",
          "kind": "route",
          "name": "POST /api/v1/devices/{deviceId}/scripts/{scriptId}/stop",
          "base": "POST /api/v1/devices/{deviceId}/scripts/{scriptId}/stop",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Dừng script đang chạy.",
          "desc_en": "Dừng script đang chạy.",
          "params": [],
          "returns": "json",
          "example": ""
        },
        {
          "category_id": "hidprobe-routes",
          "category_vi": "HIDProbe self-host route",
          "category_en": "HIDProbe self-host routes",
          "kind": "route",
          "name": "GET /api/v1/devices/{deviceId}/script-events?limit=120",
          "base": "GET /api/v1/devices/{deviceId}/script-events?limit=120",
          "status": "ready",
          "compatibility": {
            "label": "READY",
            "vi": "Dùng được trên HIDProbe ioscontrol-v1",
            "className": "ok"
          },
          "desc_vi": "Đọc log/bằng chứng PASS/FAIL từ iPhone.",
          "desc_en": "Đọc log/bằng chứng PASS/FAIL từ iPhone.",
          "params": [],
          "returns": "json",
          "example": ""
        }
      ]
    }
  ]
};
  const SkillPrompt = "Bạn là AI viết Lua cho HIDProbe. Dùng api_profile=ioscontrol-v1. Đọc IOSCONTROL_API_FULL.md hoặc panel Kho API Lua. Viết từng stage nhỏ, mỗi stage có PASS/FAIL rõ ràng. Ưu tiên appRun/appState, tapImage/waitForImage, ocrFind/waitForText, getColor/waitForColor. Không coi HTTP 200, push ACK hoặc script_done là PASS nếu chưa có bằng chứng màn hình/app/log. Không dùng STUB làm tiêu chí hoàn thành.";

  let modal = null;
  let activeStatus = "all";

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  function statusClass(status) {
    if (status === "ready") return "ok";
    if (status === "partial") return "warn";
    if (status === "route") return "route";
    return "bad";
  }

  function copyText(text, successMessage) {
    const value = String(text || "");
    if (!value) return;
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(value).then(() => {
        if (successMessage) global.HidToast?.(successMessage, "success");
      }).catch(() => {});
      return;
    }
    const area = document.createElement("textarea");
    area.value = value;
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
    if (successMessage) global.HidToast?.(successMessage, "success");
  }

  function exampleFor(item) {
    if (item.example) return item.example;
    if (item.kind === "route") return item.name;
    return item.name.replace(/\b([a-zA-Z_][\w.]*)\((.*)\)/, "$1($2)");
  }

  function filteredSections(filter = "") {
    const q = String(filter || "").trim().toLowerCase();
    return ReferenceData.sections.map((section) => {
      const items = section.items.filter((item) => {
        const haystack = [item.name, item.base, item.status, item.desc_vi, item.desc_en, item.note_vi, section.title_vi, section.title_en].join(" ").toLowerCase();
        if (activeStatus !== "all" && item.status !== activeStatus) return false;
        return !q || haystack.includes(q);
      });
      return { ...section, items };
    }).filter((section) => section.items.length);
  }

  function render(filter = "") {
    const body = modal.querySelector("#ioscontrol-api-body");
    const sections = filteredSections(filter);
    body.innerHTML = sections.map((section) => {
      return `<section class="api-ref-section">
        <h4>${escapeHtml(section.title_vi)} <small>${section.items.length}</small></h4>
        ${section.items.map((item) => `<article class="api-ref-row" data-api-name="${escapeHtml(item.name)}">
          <div class="api-ref-row-head">
            <button class="api-ref-copy" data-copy-api="${escapeHtml(item.name)}" type="button"><code>${escapeHtml(item.name)}</code></button>
            <span class="api-ref-status ${statusClass(item.status)}">${escapeHtml(item.compatibility.label)}</span>
          </div>
          <p>${escapeHtml(item.desc_vi || item.desc_en || item.compatibility.vi)}</p>
          <small>${escapeHtml(item.note_vi || item.compatibility.vi)}</small>
        </article>`).join("")}
      </section>`;
    }).join("") || "<p class=\"workflow-status\">Không thấy API.</p>";

    body.querySelectorAll("[data-copy-api]").forEach((button) => {
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        copyText(button.dataset.copyApi || "", "Đã copy tên API");
      });
    });
    body.querySelectorAll(".api-ref-row").forEach((row) => {
      row.addEventListener("click", () => {
        const item = ReferenceData.sections.flatMap((section) => section.items).find((entry) => entry.name === row.dataset.apiName);
        copyText(exampleFor(item || {}), "Đã copy ví dụ API");
      });
    });
  }

  function ensureModal() {
    if (modal) return modal;
    modal = document.createElement("div");
    modal.className = "workflow-modal hidden";
    modal.innerHTML = `
      <div class="workflow-backdrop" data-api-close="1"></div>
      <section class="workflow-panel api-ref-panel" role="dialog" aria-modal="true">
        <header class="workflow-panel-head">
          <strong>IOSControl Lua API cho HIDProbe</strong>
          <button class="hbtn" data-api-close="1" type="button">Đóng</button>
        </header>
        <div class="api-ref-toolbar">
          <input id="ioscontrol-api-search" type="search" placeholder="Tìm API: tapImage, ocrFind, appRun...">
          <button class="hbtn" data-status-filter="all" type="button">Tất cả</button>
          <button class="hbtn" data-status-filter="ready" type="button">READY</button>
          <button class="hbtn" data-status-filter="partial" type="button">PARTIAL</button>
          <button class="hbtn" data-status-filter="stub" type="button">STUB</button>
          <button class="hbtn" id="ioscontrol-copy-skill" type="button">Copy prompt cho AI</button>
          <button class="hbtn" id="ioscontrol-copy-list" type="button">Copy list API</button>
        </div>
        <p class="workflow-status">READY = dùng được; PARTIAL = phải kiểm chứng kỹ; STUB = chỉ có tên, chưa dùng làm PASS; HTTP = route tham khảo. Click dòng để copy ví dụ.</p>
        <div id="ioscontrol-api-body" class="api-ref-body"></div>
      </section>`;
    document.body.appendChild(modal);
    modal.addEventListener("click", (event) => {
      if (event.target instanceof HTMLElement && event.target.dataset.apiClose) close();
    });
    modal.querySelector("#ioscontrol-api-search").addEventListener("input", (event) => render(event.target.value));
    modal.querySelectorAll("[data-status-filter]").forEach((button) => {
      button.addEventListener("click", () => {
        activeStatus = button.dataset.statusFilter || "all";
        modal.querySelectorAll("[data-status-filter]").forEach((other) => other.classList.toggle("primary", other === button));
        render(modal.querySelector("#ioscontrol-api-search").value);
      });
    });
    modal.querySelector("#ioscontrol-copy-skill").addEventListener("click", () => copyText(SkillPrompt, "Đã copy prompt cho AI"));
    modal.querySelector("#ioscontrol-copy-list").addEventListener("click", () => {
      const text = ReferenceData.sections.map((section) => {
        return [section.title_vi, ...section.items.map((item) => `- ${item.name} [${item.compatibility.label}] ${item.desc_vi || item.desc_en}`)].join("\n");
      }).join("\n\n");
      copyText(text, "Đã copy list API");
    });
    render();
    return modal;
  }

  function open() {
    ensureModal().classList.remove("hidden");
    modal.querySelector("#ioscontrol-api-search")?.focus();
  }

  function close() {
    modal?.classList.add("hidden");
  }

  global.HidApiReference = {
    open,
    close,
    data: ReferenceData,
    skillPrompt: SkillPrompt,
  };
})(window);
