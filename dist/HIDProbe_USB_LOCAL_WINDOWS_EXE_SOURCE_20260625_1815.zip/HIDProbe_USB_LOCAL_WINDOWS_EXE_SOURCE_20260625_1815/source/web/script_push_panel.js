"use strict";

(function attachScriptPush(global) {
  function deviceIdOf(target) {
    return target?.device?.id || target?.device_id || target?.id || "";
  }

  function defaultApiPath(path) {
    if (typeof global.apiUrl === "function") return global.apiUrl(path);
    return path;
  }

  async function postJson(path, body, options = {}) {
    const url = (options.apiPath || defaultApiPath)(path);
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      body: JSON.stringify(body || {}),
    });
    const text = await response.text();
    let json = {};
    try { json = text ? JSON.parse(text) : {}; } catch (_error) { json = { raw: text }; }
    if (!response.ok || json.ok === false) {
      const message = json.error || json.message || `HTTP ${response.status}`;
      throw new Error(`${message} · cần PC signaling route Phase 4.3 nếu endpoint chưa có`);
    }
    return json;
  }

  async function getJson(path, options = {}) {
    const url = (options.apiPath || defaultApiPath)(path);
    const response = await fetch(url, { method: "GET", cache: "no-store" });
    const text = await response.text();
    let json = {};
    try { json = text ? JSON.parse(text) : {}; } catch (_error) { json = { raw: text }; }
    if (!response.ok || json.ok === false) {
      const message = json.error || json.message || `HTTP ${response.status}`;
      throw new Error(`${message} · không lấy được script-events`);
    }
    return json;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function eventText(event) {
    return String(event?.message || event?.event || event?.status || "").trim();
  }

  function isFailedEvent(event) {
    const status = String(event?.status || "").toLowerCase();
    const name = String(event?.event || "").toLowerCase();
    return status === "failed" || name === "script_failed" || eventText(event).includes("lua_script_failed");
  }

  function isDoneEvent(event) {
    const status = String(event?.status || "").toLowerCase();
    const name = String(event?.event || "").toLowerCase();
    return status === "done" || name === "script_done";
  }

  function isStartedEvent(event) {
    const status = String(event?.status || "").toLowerCase();
    const name = String(event?.event || "").toLowerCase();
    return status === "started" || name === "script_started" || eventText(event).includes("script_started");
  }

  function inferRunWaitMs(packagePayload) {
    const content = String(packagePayload?.content || "");
    const loopMatch = content.match(/for\s+\w+\s*=\s*1,\s*(\d+)\s+do[\s\S]*?sleep\((\d+)\)/);
    if (loopMatch) {
      const attempts = Number(loopMatch[1]);
      const interval = Number(loopMatch[2]);
      if (Number.isFinite(attempts) && Number.isFinite(interval)) {
        return Math.min(Math.max((attempts * interval) + 10000, 15000), 420000);
      }
    }
    return 120000;
  }

  function scriptRunEvents(allEvents, scriptId, runId) {
    return (allEvents || []).filter((event) => {
      if (String(event?.script_id || "") !== String(scriptId || "")) return false;
      if (runId && String(event?.run_id || "") !== String(runId)) return false;
      return true;
    });
  }

  function eventKey(event) {
    return [
      event?.ts || "",
      event?.event || "",
      event?.script_id || "",
      event?.run_id || "",
      event?.status || "",
      event?.message || "",
    ].join("|");
  }

  async function fetchScriptEvents(deviceId, options = {}) {
    const limit = Number(options.limit || 120);
    const json = await getJson(`/api/v1/devices/${encodeURIComponent(deviceId)}/script-events?limit=${encodeURIComponent(limit)}`, options);
    return Array.isArray(json.events) ? json.events : [];
  }

  async function waitForScriptRunOnDevice(packagePayload, target, runResult, options = {}) {
    const deviceId = deviceIdOf(target);
    const runId = options.runId || "";
    const waitMs = Number(options.waitTimeoutMs || inferRunWaitMs(packagePayload));
    const deadline = Date.now() + waitMs;
    const startWaitMs = Math.max(0, Number(options.startTimeoutMs || 0));
    const startDeadline = startWaitMs ? Date.now() + startWaitMs : 0;
    let lastEvents = [];
    let sawStart = false;
    const emitted = new Set();

    while (Date.now() <= deadline) {
      const events = await fetchScriptEvents(deviceId, options);
      lastEvents = scriptRunEvents(events, packagePayload.script_id, runId);
      if (!sawStart && lastEvents.some(isStartedEvent)) sawStart = true;
      for (const event of lastEvents) {
        const key = eventKey(event);
        if (emitted.has(key)) continue;
        emitted.add(key);
        options.onScriptEvent?.({ device_id: deviceId, event });
      }
      const failed = lastEvents.find(isFailedEvent);
      if (failed) {
        throw new Error(`${deviceId}: ${eventText(failed) || "script_failed"}`);
      }
      const done = lastEvents.find(isDoneEvent);
      if (done) {
        return {
          device_id: deviceId,
          result: runResult,
          run_id: runId,
          final_status: "done",
          final_event: done,
          events: lastEvents,
        };
      }
      if (!sawStart && startDeadline && Date.now() > startDeadline) {
        const last = lastEvents.slice(-1)[0];
        throw new Error(`${deviceId}: iphone_command_not_started run_id=${runId || "-"} last=${eventText(last) || "no_event"} · iPhone chưa nhận lệnh run_script/crop; nếu web vẫn báo script đang chạy, bấm Dừng script hoặc restart HIDProbe Agent rồi crop lại`);
      }
      await sleep(Number(options.pollIntervalMs || 1000));
    }

    const last = lastEvents.slice(-1)[0];
    throw new Error(`${deviceId}: script_run_timeout run_id=${runId || "-"} last=${eventText(last) || "no_event"}`);
  }

  async function pushPackageToDevices(packagePayload, targets, options = {}) {
    const results = [];
    for (const target of targets || []) {
      const deviceId = deviceIdOf(target);
      if (!deviceId) continue;
      const body = {
        package: {
          ...packagePayload,
          target_device_id: deviceId,
          target_device_ids: [deviceId],
        },
        script_id: packagePayload.script_id,
        version: packagePayload.version,
      };
      const result = await postJson(`/api/v1/devices/${encodeURIComponent(deviceId)}/scripts`, body, options);
      results.push({ device_id: deviceId, result });
    }
    return results;
  }

  async function runScriptOnDevices(packagePayload, targets, options = {}) {
    const results = [];
    for (const target of targets || []) {
      const deviceId = deviceIdOf(target);
      if (!deviceId) continue;
      const runId = options.runId || `run-${Date.now()}`;
      const body = {
        script_id: packagePayload.script_id,
        version: packagePayload.version,
        run_id: runId,
        debug_requested_by_web: options.debugRequestedByWeb !== false,
      };
      const result = await postJson(`/api/v1/devices/${encodeURIComponent(deviceId)}/scripts/${encodeURIComponent(packagePayload.script_id)}/run`, body, options);
      results.push(await waitForScriptRunOnDevice(packagePayload, target, result, { ...options, runId }));
    }
    return results;
  }

  async function stopScriptOnDevices(packagePayload, targets, options = {}) {
    const results = [];
    for (const target of targets || []) {
      const deviceId = deviceIdOf(target);
      if (!deviceId) continue;
      const body = {
        script_id: packagePayload.script_id,
        version: packagePayload.version,
        reason: options.reason || "web_stop_script",
      };
      const result = await postJson(`/api/v1/devices/${encodeURIComponent(deviceId)}/scripts/${encodeURIComponent(packagePayload.script_id)}/stop`, body, options);
      results.push({ device_id: deviceId, result });
    }
    return results;
  }

  global.HidScriptPush = {
    pushPackageToDevices,
    runScriptOnDevices,
    stopScriptOnDevices,
    fetchScriptEvents,
  };
})(window);
