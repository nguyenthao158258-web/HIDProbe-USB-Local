"use strict";

(function attachFilters(global) {
  function normalizeQuery(value) {
    return String(value || "").trim().toLowerCase();
  }
  function deviceRuntimeStatus(device, controller) {
    if (controller?.isConnected?.()) return "online";
    if (controller?.isConnecting?.()) return "preparing";
    if (String(device.state || "").toLowerCase() === "offline") return "offline";
    return String(device.state || "standby").toLowerCase();
  }
  function filterDevices(devices, filters, controllerGetter) {
    const query = normalizeQuery(filters.query);
    return devices.filter((device) => {
      const controller = controllerGetter?.(device.id);
      if (query) {
        const id = String(device.id || "").toLowerCase();
        const name = String(device.name || "").toLowerCase();
        const note = String(device.note || "").toLowerCase();
        const tagsText = (device.tags || []).join(" ").toLowerCase();
        if (!id.startsWith(query) && !name.includes(query) && !note.includes(query) && !tagsText.includes(query)) return false;
      }
      if (filters.status && filters.status !== "all") {
        const status = deviceRuntimeStatus(device, controller);
        if (filters.status === "online" && status !== "online") return false;
        if (filters.status === "offline" && status !== "offline") return false;
        if (!["online", "offline"].includes(filters.status) && status !== filters.status) return false;
      }
      if (filters.groupId === "__ungrouped__" && device.group_id) return false;
      if (filters.groupId && filters.groupId !== "__ungrouped__" && device.group_id !== filters.groupId) return false;
      if (Array.isArray(filters.tags) && filters.tags.length) {
        const deviceTags = new Set((device.tags || []).map((tag) => String(tag).toLowerCase()));
        if (!filters.tags.every((tag) => deviceTags.has(String(tag).toLowerCase()))) return false;
      }
      return true;
    });
  }
  function sortDevices(devices, sortBy, controllerGetter) {
    const sorted = [...devices];
    sorted.sort((a, b) => {
      if (sortBy === "status") return deviceRuntimeStatus(a, controllerGetter?.(a.id)).localeCompare(deviceRuntimeStatus(b, controllerGetter?.(b.id)));
      if (sortBy === "last_seen") return String(b.last_seen || "").localeCompare(String(a.last_seen || ""));
      if (sortBy === "group") return String(a.group_id || "").localeCompare(String(b.group_id || ""), "vi") || String(a.name || a.id).localeCompare(String(b.name || b.id), "vi");
      return String(a.name || a.id).localeCompare(String(b.name || b.id), "vi");
    });
    return sorted;
  }
  global.HidFilters = { filterDevices, sortDevices, deviceRuntimeStatus };
})(window);
