"use strict";

(function attachWorkflowEditor(global) {
  let modal = null;
  let integration = null;
  let currentWorkflow = null;
  let selectedBlockId = "";
  let runner = null;
  let lastAiWorkflow = null;
  let recordReplaceBlockId = "";
  let primaryTarget = null;
  let previewVideo = null;
  let lastFrameCanvas = null;
  let previewCanvas = null;
  let previewResizeObserver = null;
  let targetRefreshTimer = null;
  let lastPrimaryTargetId = "";
  let lastTargetReady = false;
  let reconnectInProgress = false;
  let recorderState = null;
  let isRecording = false;
  let hasRecordedOnce = false;
  let lastPreviewPoint = { x: 0.5, y: 0.5 };
  let lastSuccessfulTestHash = "";
  let lastTestMetadata = null;
  let coordinatePickState = null;
  let assetTargetBlockId = "";
  let assetTargetParamKey = "image";
  let imageCropState = null;
  let selectedSavedWorkflowIds = new Set();
  let luaEditorSourceMode = "generated";
  let lastRunningScriptPackage = null;
  let lastRunningScriptTargets = [];

  const LiveMoveThresholdPx = 6;
  const LiveLongPressMs = 650;
  const LiveMoveThrottleMs = 16;
  const ImageAnchorDefaultRadius = 0.16;
  const NativeCropMaxBytes = 512000;
  const ParamLabels = {
    app_name: "Tên ứng dụng",
    bundle_id: "Bundle ID",
    url: "URL",
    api_key: "Extok API key",
    unique_username: "TikTok username/URL",
    job_type: "Loại job",
    skip_type: "Bỏ qua loại job",
    lang: "Ngôn ngữ API",
    action_timeout_ms: "Chờ thao tác TikTok (ms)",
    complete_after_action: "Báo hoàn thành sau thao tác",
    skip_unsupported: "Skip nếu chưa hỗ trợ",
    follow_texts: "Chữ nút Follow",
    url_scheme: "URL scheme",
    x: "X",
    y: "Y",
    hold_ms: "Thời gian giữ (ms)",
    ms: "Thời gian chờ (ms)",
    save_as: "Tên ảnh chụp",
    input_text: "Chữ/URL cần nhập",
    submit_after: "Bấm Go/Return sau nhập",
    delay_ms: "Chờ trước Go (ms)",
    text: "Chữ cần thấy",
    image: "Tên file ảnh",
    condition_image: "Ảnh điều kiện A",
    condition_images: "Ảnh điều kiện A dự phòng",
    action_mode: "Kiểu nhấn",
    target_image: "Ảnh cần nhấn B",
    target_timeout_ms: "Chờ ảnh B tối đa (ms)",
    target_threshold: "Độ giống ảnh B",
    first_image: "Ảnh trạng thái 1",
    first_action_mode: "Khi thấy trạng thái 1",
    first_target_image: "Ảnh cần nhấn của trạng thái 1",
    first_x: "X trạng thái 1",
    first_y: "Y trạng thái 1",
    first_target_timeout_ms: "Chờ ảnh nhấn trạng thái 1 (ms)",
    first_target_threshold: "Độ giống ảnh nhấn trạng thái 1",
    second_image: "Ảnh trạng thái 2",
    second_action_mode: "Khi thấy trạng thái 2",
    second_target_image: "Ảnh cần nhấn của trạng thái 2",
    second_x: "X trạng thái 2",
    second_y: "Y trạng thái 2",
    second_threshold: "Độ giống trạng thái 2",
    check_second_after_first: "Sau trạng thái 1, xử lý trạng thái 2",
    after_first_wait_ms: "Chờ sau trạng thái 1 (ms)",
    after_first_second_timeout_ms: "Chờ trạng thái 2 sau trạng thái 1 (ms)",
    second_target_timeout_ms: "Chờ ảnh nhấn trạng thái 2 (ms)",
    second_target_threshold: "Độ giống ảnh nhấn trạng thái 2",
    timeout_ms: "Chờ tối đa (ms)",
    interval_ms: "Quét lại mỗi (ms)",
    threshold: "Độ giống ảnh (0..1)",
    on_timeout: "Khi quá thời gian",
    image_search_mode: "Phạm vi tìm ảnh",
    image_search_regions: "Điểm/ROI tìm ảnh",
    condition_image_search_mode: "Phạm vi tìm ảnh A",
    condition_image_search_regions: "Điểm/ROI tìm ảnh A",
    target_image_search_mode: "Phạm vi tìm ảnh B",
    target_image_search_regions: "Điểm/ROI tìm ảnh B",
    telegram_message: "Tin nhắn Telegram",
    telegram_chat_id: "Telegram chat_id",
    telegram_bot_token: "Telegram bot token",
    reason: "Ghi chú",
    iterations: "Số lần lặp",
    repeat_from_step: "Lặp từ bước",
    repeat_to_step: "Đến bước (0 = trước Loop)",
    condition_type: "Loại điều kiện",
    variable: "Biến",
    value: "Giá trị",
    name: "Tên biến",
    message: "Nội dung",
    level: "Mức báo",
    on_error: "Khi block lỗi",
  };

  function byId(id) {
    return modal.querySelector(`#${id}`);
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  function nowIso() {
    return new Date().toISOString();
  }

  function formatPoint(point) {
    if (!point) return "—";
    return `${Number(point.x).toFixed(4)}, ${Number(point.y).toFixed(4)}`;
  }

  function paramLabel(key) {
    return ParamLabels[key] || key;
  }

  function paramPlaceholder(key) {
    const placeholders = {
      bundle_id: "Ví dụ: com.apple.shortcuts",
      url: "Ví dụ: thuypp.fun hoặc app-scheme://...",
      api_key: "Dán API key Extok khi chạy; không hardcode vào source chung",
      unique_username: "Ví dụ: @ten_tiktok hoặc URL profile",
      job_type: "follow, like hoặc comment",
      skip_type: "Tuỳ chọn: follow, like hoặc comment",
      lang: "vi hoặc en",
      follow_texts: "Follow|Theo dõi|Follow back",
      input_text: "Ví dụ: tài khoản, mật khẩu, nội dung cần nhập...",
      text: "Ví dụ: OK / Đăng nhập / Treo 180p TikTok",
      image: "Ví dụ: button.png",
      condition_image: "Ảnh A để kiểm tra điều kiện",
      condition_images: "Nhiều ảnh A dự phòng, mỗi dòng một file",
      action_mode: "coordinate hoặc image",
      target_image: "Ảnh B cần nhấn khi thấy A",
      first_image: "Ví dụ: ảnh nút Follow",
      first_action_mode: "self, coordinate hoặc image",
      first_target_image: "Nếu không muốn bấm chính ảnh trạng thái 1",
      second_image: "Ví dụ: ảnh nút Tin nhắn",
      second_action_mode: "coordinate hoặc image",
      second_target_image: "Ví dụ: ảnh Back Safari",
      repeat_from_step: "Ví dụ: 3 để bắt đầu lặp từ bước 3",
      repeat_to_step: "0 = tới block ngay trước Loop; hoặc nhập số bước cụ thể",
      on_timeout: "fail hoặc telegram_fail",
      image_search_mode: "full_screen, prefer_regions_then_full hoặc regions_only",
      image_search_regions: "JSON array: [{\"type\":\"point\",\"x\":0.5,\"y\":0.5,\"radius\":0.16}]",
      condition_image_search_mode: "full_screen, prefer_regions_then_full hoặc regions_only",
      condition_image_search_regions: "JSON array điểm/ROI cho ảnh điều kiện A",
      target_image_search_mode: "full_screen, prefer_regions_then_full hoặc regions_only",
      target_image_search_regions: "JSON array điểm/ROI cho ảnh B",
      telegram_chat_id: "Chat ID nhận cảnh báo",
      telegram_bot_token: "Token bot Telegram",
      on_error: "fail = dừng; continue = bỏ lỗi chạy bước tiếp",
    };
    return placeholders[key] || "";
  }

  function safeAssetPath(name) {
    const raw = String(name || "template.png").trim().split(/[\\/]/).pop() || "template.png";
    const cleaned = raw
      .normalize("NFKD")
      .replace(/[^\w.-]+/g, "_")
      .replace(/^_+|_+$/g, "");
    const withExt = /\.[a-z0-9]{2,5}$/i.test(cleaned) ? cleaned : `${cleaned || "template"}.png`;
    return withExt || `template_${Date.now()}.png`;
  }

  function ensureAssets() {
    if (!Array.isArray(currentWorkflow.assets)) currentWorkflow.assets = [];
    return currentWorkflow.assets;
  }

  function assetForPath(path) {
    const wanted = String(path || "").trim();
    if (!wanted) return null;
    return ensureAssets().find((asset) => String(asset.path || "").trim() === wanted) || null;
  }

  function imageListFromValue(value) {
    if (Array.isArray(value)) {
      return value.map((item) => String(item || "").trim()).filter(Boolean);
    }
    return String(value || "")
      .split(/[\n,|]+/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  function uniqueImageList(list) {
    const seen = new Set();
    const out = [];
    for (const item of list || []) {
      const path = String(item || "").trim();
      if (!path || seen.has(path)) continue;
      seen.add(path);
      out.push(path);
    }
    return out;
  }

  function serializeImageList(list) {
    return uniqueImageList(list).join("\n");
  }

  function imagePathsForBlock(block, paths = new Set()) {
    if (!block) return paths;
    if (block.type === "wait_image" || block.type === "tap_image" || block.type === "tap_image_optional") {
      const image = String(block.params?.image || "").trim();
      if (image) paths.add(image);
    }
    if (block.type === "tap_if_image") {
      const condition = String(block.params?.condition_image || "").trim();
      if (condition) paths.add(condition);
      for (const extra of imageListFromValue(block.params?.condition_images)) paths.add(extra);
      const mode = String(block.params?.action_mode || "coordinate").trim().toLowerCase();
      const target = String(block.params?.target_image || "").trim();
      if (mode === "image" && target) paths.add(target);
    }
    if (block.type === "tap_image_state_pair") {
      const first = String(block.params?.first_image || "").trim();
      const second = String(block.params?.second_image || "").trim();
      const firstMode = String(block.params?.first_action_mode || "self").trim().toLowerCase();
      const firstTarget = String(block.params?.first_target_image || "").trim();
      const mode = String(block.params?.second_action_mode || "coordinate").trim().toLowerCase();
      const target = String(block.params?.second_target_image || "").trim();
      if (first) paths.add(first);
      if (firstMode === "image" && firstTarget) paths.add(firstTarget);
      if (second) paths.add(second);
      if (mode === "image" && target) paths.add(target);
    }
    for (const child of block.body || []) imagePathsForBlock(child, paths);
    return paths;
  }

  function assetsForBlocks(blocks) {
    const paths = new Set();
    for (const block of blocks || []) imagePathsForBlock(block, paths);
    if (!paths.size) return [];
    return ensureAssets().filter((asset) => paths.has(String(asset.path || "").trim()));
  }

  function dataUrlForAsset(asset) {
    if (!asset) return "";
    if (asset.preview_data_url && String(asset.preview_data_url).startsWith("data:image/")) return asset.preview_data_url;
    if (asset.data_base64) return `data:${asset.mime || "image/png"};base64,${asset.data_base64}`;
    return "";
  }

  function base64FromArrayBuffer(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
    return btoa(binary);
  }

  async function sha256HexFromArrayBuffer(buffer) {
    if (global.crypto?.subtle) {
      const digest = await global.crypto.subtle.digest("SHA-256", buffer);
      return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
    }
    let hash = 2166136261;
    const bytes = new Uint8Array(buffer);
    for (const byte of bytes) {
      hash ^= byte;
      hash = Math.imul(hash, 16777619);
    }
    return `fnv1a-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  function imageDimensionsFromDataUrl(dataUrl) {
    return new Promise((resolve) => {
      const image = new Image();
      image.onload = () => resolve({ width: image.naturalWidth || image.width || 0, height: image.naturalHeight || image.height || 0 });
      image.onerror = () => resolve({ width: 0, height: 0 });
      image.src = dataUrl;
    });
  }

  function imageAssetMetaPrefix(paramKey = "image") {
    return paramKey === "image" ? "" : `${paramKey}_`;
  }

  function smartAnchorRadiusForAsset(asset = {}) {
    const width = Number(asset.width || 0) || 0;
    const height = Number(asset.height || 0) || 0;
    const maxPx = Math.max(width, height);
    if (maxPx > 0 && maxPx < 100) return 0.05;
    if (maxPx > 0 && maxPx < 200) return 0.08;

    const crop = asset.crop_norm || {};
    const cropMax = Math.max(Number(crop.width || 0) || 0, Number(crop.height || 0) || 0);
    if (cropMax > 0 && cropMax < 0.08) return 0.05;
    if (cropMax > 0 && cropMax < 0.16) return 0.08;
    return ImageAnchorDefaultRadius;
  }

  function assignAssetToBlock(block, asset, paramKey = "image") {
    if (!block || !asset?.path) return;
    const assets = ensureAssets();
    const existingIndex = assets.findIndex((item) => item.path === asset.path);
    if (existingIndex >= 0) assets[existingIndex] = asset;
    else assets.push(asset);
    if (paramKey === "condition_images") {
      const current = imageListFromValue(block.params.condition_images);
      block.params.condition_images = serializeImageList([...current, asset.path]);
      markDirty();
      renderCanvas();
      integration.toast?.(`Đã thêm ảnh A dự phòng ${asset.path}`, "success");
      return;
    }
    const prefix = imageAssetMetaPrefix(paramKey);
    block.params[paramKey] = asset.path;
    block.params[`${prefix}asset_sha256`] = asset.sha256;
    block.params[`${prefix}asset_size`] = asset.size;
    block.params[`${prefix}asset_source`] = asset.source || "web";
    if (Number.isFinite(Number(asset.width))) block.params[`${prefix}asset_width`] = Number(asset.width);
    if (Number.isFinite(Number(asset.height))) block.params[`${prefix}asset_height`] = Number(asset.height);
    if (Number.isFinite(Number(asset.source_width))) block.params[`${prefix}asset_source_width`] = Number(asset.source_width);
    if (Number.isFinite(Number(asset.source_height))) block.params[`${prefix}asset_source_height`] = Number(asset.source_height);
    if (asset.crop_norm) {
      const crop = asset.crop_norm;
      const centerX = Number(crop.center_x ?? (Number(crop.x || 0) + Number(crop.width || 0) / 2));
      const centerY = Number(crop.center_y ?? (Number(crop.y || 0) + Number(crop.height || 0) / 2));
      const radius = smartAnchorRadiusForAsset(asset);
      block.params[`${paramKey}_anchor_x`] = Number(centerX.toFixed(6));
      block.params[`${paramKey}_anchor_y`] = Number(centerY.toFixed(6));
      block.params[`${paramKey}_anchor_radius`] = Number(radius.toFixed(6));
    } else {
      delete block.params[`${paramKey}_anchor_x`];
      delete block.params[`${paramKey}_anchor_y`];
      delete block.params[`${paramKey}_anchor_radius`];
    }
    markDirty();
    renderCanvas();
    integration.toast?.(`Đã gắn ảnh mẫu ${asset.path}`, "success");
  }

  function removeSelectedImageAsset(block, paramKey = "image", selectedPath = "") {
    const path = paramKey === "condition_images"
      ? String(selectedPath || "").trim()
      : String(block?.params?.[paramKey] || "").trim();
    if (!path) return;
    if (paramKey === "condition_images") {
      block.params.condition_images = serializeImageList(imageListFromValue(block.params.condition_images).filter((item) => item !== path));
      const stillReferenced = new Set();
      for (const rootBlock of currentWorkflow?.blocks || []) imagePathsForBlock(rootBlock, stillReferenced);
      if (!stillReferenced.has(path)) currentWorkflow.assets = ensureAssets().filter((asset) => asset.path !== path);
      markDirty();
      renderCanvas();
      integration.toast?.(`Đã xoá ảnh A dự phòng ${path}`, "info");
      return;
    }
    currentWorkflow.assets = ensureAssets().filter((asset) => asset.path !== path);
    const prefix = imageAssetMetaPrefix(paramKey);
    delete block.params[paramKey];
    delete block.params[`${prefix}asset_sha256`];
    delete block.params[`${prefix}asset_size`];
    delete block.params[`${prefix}asset_source`];
    delete block.params[`${prefix}asset_width`];
    delete block.params[`${prefix}asset_height`];
    delete block.params[`${prefix}asset_source_width`];
    delete block.params[`${prefix}asset_source_height`];
    delete block.params[`${paramKey}_anchor_x`];
    delete block.params[`${paramKey}_anchor_y`];
    delete block.params[`${paramKey}_anchor_radius`];
    markDirty();
    renderCanvas();
    integration.toast?.(`Đã xoá ảnh mẫu ${path}`, "info");
  }

  function normalizePoint(point) {
    const x = Number(point?.x);
    const y = Number(point?.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return {
      x: Math.min(Math.max(x, 0), 1),
      y: Math.min(Math.max(y, 0), 1),
    };
  }

  function imageSearchPrefixForParam(paramKey = "image") {
    if (paramKey === "condition_image") return "condition_image";
    if (paramKey === "target_image") return "target_image";
    return "image";
  }

  function normalizeImageSearchMode(value) {
    const mode = String(value || "full_screen").trim().toLowerCase();
    return ["full_screen", "prefer_regions_then_full", "regions_only"].includes(mode) ? mode : "full_screen";
  }

  function imageSearchRegionsFromValue(value) {
    if (Array.isArray(value)) return value;
    if (typeof value === "string" && value.trim()) {
      try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_error) {
        return [];
      }
    }
    return [];
  }

  function normalizeSearchRegion(region) {
    const type = String(region?.type || "point").trim().toLowerCase() === "roi" ? "roi" : "point";
    const point = normalizePoint(region);
    if (!point) return null;
    if (type === "roi") {
      const width = Math.min(Math.max(Number(region?.width) || 0, 0), 1);
      const height = Math.min(Math.max(Number(region?.height) || 0, 0), 1);
      if (!width || !height) return null;
      return {
        type: "roi",
        x: Number(point.x.toFixed(6)),
        y: Number(point.y.toFixed(6)),
        width: Number(width.toFixed(6)),
        height: Number(height.toFixed(6)),
        label: String(region?.label || "").trim(),
      };
    }
    const radius = Math.min(Math.max(Number(region?.radius ?? ImageAnchorDefaultRadius) || ImageAnchorDefaultRadius, 0.001), 1);
    return {
      type: "point",
      x: Number(point.x.toFixed(6)),
      y: Number(point.y.toFixed(6)),
      radius: Number(radius.toFixed(6)),
      label: String(region?.label || "").trim(),
    };
  }

  function normalizedSearchRegions(value) {
    return imageSearchRegionsFromValue(value).map(normalizeSearchRegion).filter(Boolean);
  }

  function imageSearchModeSuffix(params, prefix) {
    const mode = normalizeImageSearchMode(params?.[`${prefix}_search_mode`]);
    if (mode === "full_screen") return "";
    const count = normalizedSearchRegions(params?.[`${prefix}_search_regions`]).length;
    return mode === "regions_only" ? ` · ROI-only ${count}` : ` · ROI→full ${count}`;
  }

  function addImageSearchPoint(block, prefix, point) {
    if (!block || !prefix || !point) return;
    const regionsKey = `${prefix}_search_regions`;
    const regions = normalizedSearchRegions(block.params?.[regionsKey]);
    regions.push(normalizeSearchRegion({
      type: "point",
      x: point.x,
      y: point.y,
      radius: ImageAnchorDefaultRadius,
      label: `manual-${regions.length + 1}`,
    }));
    block.params[regionsKey] = regions.filter(Boolean);
    if (normalizeImageSearchMode(block.params[`${prefix}_search_mode`]) === "full_screen") {
      block.params[`${prefix}_search_mode`] = "prefer_regions_then_full";
    }
    markDirty();
    renderCanvas();
    renderProperties();
    integration.toast?.(`Đã thêm điểm gợi ý tìm ảnh ${Number(point.x).toFixed(3)},${Number(point.y).toFixed(3)}`, "success");
  }

  function selectedBlock() {
    return currentWorkflow?.blocks?.find((item) => item.id === selectedBlockId) || null;
  }

  function currentHash() {
    if (!currentWorkflow) return "";
    return global.HidWorkflowBlocks.workflowStableHash(currentWorkflow);
  }

  function markDirty() {
    if (!currentWorkflow) return;
    currentWorkflow.updated_at = nowIso();
    if (lastSuccessfulTestHash !== currentHash()) {
      currentWorkflow.test_metadata = null;
    }
    updateSaveGate();
  }

  function workflowTested() {
    return !!currentWorkflow?.blocks?.length && !!lastSuccessfulTestHash && lastSuccessfulTestHash === currentHash();
  }

  function isRawLuaWorkflow(workflow = currentWorkflow) {
    return !!String(workflow?.raw_lua || "").trim();
  }

  function rawLuaLineCount(workflow = currentWorkflow) {
    const text = String(workflow?.raw_lua || "");
    if (!text.trim()) return 0;
    return text.replace(/\r\n/g, "\n").split("\n").length;
  }

  function ensureModal() {
    if (modal) return modal;
    modal = document.createElement("div");
    modal.className = "workflow-modal hidden";
    modal.innerHTML = `
      <div class="workflow-backdrop" data-workflow-close="1"></div>
      <section class="workflow-panel" role="dialog" aria-modal="true">
        <header class="workflow-panel-head">
          <strong>🧩 Kho Lua / Tạo kịch bản</strong>
          <div class="workflow-toolbar">
            <input id="workflow-name" class="workflow-name-input" placeholder="Tên workflow">
            <button class="hbtn" id="workflow-save" type="button">Lưu</button>
            <button class="hbtn" id="workflow-new" type="button">Mới</button>
            <button class="hbtn" id="workflow-new-lua" type="button">Lua mới</button>
            <button class="hbtn" id="workflow-import" type="button">Nhập</button>
            <button class="hbtn" id="workflow-export" type="button">Xuất</button>
            <button class="hbtn" id="workflow-view-lua" type="button">Sửa/Chạy Lua</button>
            <button class="hbtn" id="workflow-api-reference" type="button">Kho API Lua</button>
            <button class="hbtn" id="workflow-push-script" type="button">Gửi vào iPhone</button>
            <button class="hbtn primary" id="workflow-run-device-script" type="button">Chạy trên iPhone</button>
            <button class="hbtn" id="workflow-stop-device-script" type="button">Dừng script</button>
            <button class="hbtn" id="workflow-ai-open" type="button">✨ AI tạo</button>
            <button class="hbtn" id="workflow-settings" type="button">Cài đặt</button>
            <button class="hbtn" data-workflow-close="1" type="button">Đóng</button>
          </div>
        </header>
        <div class="workflow-layout">
          <aside class="workflow-palette">
            <h3>Kho Lua</h3>
            <div id="workflow-palette-list"></div>
            <h3>Kịch bản đã lưu</h3>
            <div class="workflow-list-tools">
              <label class="workflow-select-all"><input id="workflow-select-all" type="checkbox"> Chọn</label>
              <button class="hbtn danger" id="workflow-delete-selected" type="button" disabled>Xoá kịch bản đã chọn</button>
            </div>
            <div id="workflow-list"></div>
          </aside>
          <main class="workflow-canvas-wrap">
            <div class="workflow-runbar">
              <button class="hbtn primary" id="workflow-record-toggle" type="button">Bắt đầu ghi</button>
              <button class="hbtn" id="workflow-undo-last" type="button">Xoá bước cuối</button>
              <button class="hbtn" id="workflow-preview-only" type="button">Xem trước</button>
              <button class="hbtn" id="workflow-test-block" type="button">Test bước đang chọn</button>
              <button class="hbtn" id="workflow-test-run" type="button">Test kịch bản</button>
              <button class="hbtn" id="workflow-run" type="button">Chạy thử</button>
              <button class="hbtn" id="workflow-pause" type="button">Tạm dừng</button>
              <button class="hbtn" id="workflow-resume" type="button">Tiếp tục</button>
              <button class="hbtn" id="workflow-cancel" type="button">Huỷ</button>
              <span id="workflow-status" class="workflow-status">idle</span>
            </div>
            <div class="workflow-main-grid">
              <section class="workflow-live-preview" id="workflow-live-preview">
                <div class="workflow-live-head">
                  <div>
                    <strong id="workflow-primary-device">Chưa chọn máy</strong>
                    <span id="workflow-target-summary" class="workflow-status">Chọn máy đang connected trước khi mở editor</span>
                  </div>
                  <div id="workflow-recording-state" class="workflow-recording-state">Đang dừng ghi</div>
                </div>
                <div class="workflow-preview-stage" id="workflow-preview-stage">
                  <canvas id="workflow-last-frame" class="workflow-last-frame"></canvas>
                  <video id="workflow-preview-video" autoplay playsinline muted></video>
                  <canvas id="workflow-preview-overlay" class="workflow-recorder-overlay"></canvas>
                  <div id="workflow-preview-blocker" class="workflow-preview-blocker">
                    <div class="workflow-blocker-card">
                      <strong id="workflow-blocker-title">Chọn máy live</strong>
                      <span id="workflow-blocker-detail">Chọn 1 máy đang connected để ghi kịch bản bằng màn hình live.</span>
                      <button class="hbtn primary hidden" id="workflow-reconnect-target" type="button">Kết nối lại</button>
                    </div>
                  </div>
                </div>
                <div class="workflow-quick-actions" id="workflow-quick-actions">
                  <button class="quick-btn" data-workflow-quick="home" type="button">Về Home</button>
                  <button class="quick-btn" data-workflow-quick="swipe_up" type="button">↑</button>
                  <button class="quick-btn" data-workflow-quick="swipe_down" type="button">↓</button>
                  <button class="quick-btn" data-workflow-quick="tap" type="button">Nhấn</button>
                  <button class="quick-btn" data-workflow-quick="swipe_left" type="button">←</button>
                  <button class="quick-btn" data-workflow-quick="swipe_right" type="button">→</button>
                  <button class="quick-btn" data-workflow-quick="long" type="button">Giữ</button>
                  <button class="quick-btn" data-workflow-quick="screenshot" type="button">Chụp</button>
                </div>
                <div class="workflow-live-foot">
                  <span id="workflow-coordinate-readout">point: —</span>
                  <span id="workflow-save-gate">Cần test trước khi lưu</span>
                </div>
                <div id="workflow-target-list" class="workflow-target-list"></div>
              </section>
              <aside class="workflow-blocks-column">
                <div class="workflow-blocks-head">
                  <strong>Block đang chạy</strong>
                  <span id="workflow-blocks-status" class="workflow-status">0 block</span>
                </div>
                <div id="workflow-canvas" class="workflow-canvas"></div>
              </aside>
            </div>
          </main>
          <aside class="workflow-properties">
            <h3>Thuộc tính</h3>
            <div id="workflow-properties"></div>
            <h3>Log debug</h3>
            <div class="workflow-prop-actions">
              <button class="hbtn" id="workflow-copy-run-log" type="button">Copy log</button>
              <button class="hbtn" id="workflow-clear-run-log" type="button">Xoá log</button>
            </div>
            <div id="workflow-run-log" class="workflow-run-log"></div>
          </aside>
        </div>
      </section>
      <section class="workflow-ai-modal hidden" id="workflow-ai-modal">
        <div class="workflow-backdrop" data-ai-close="1"></div>
        <div class="workflow-ai-box">
          <header class="workflow-panel-head">
            <strong>✨ AI Generate Workflow</strong>
            <button class="hbtn" data-ai-close="1" type="button">Close</button>
          </header>
          <textarea id="ai-prompt" rows="6" placeholder="Ví dụ: Mở Facebook, vuốt xuống 5 lần, screenshot cuối"></textarea>
          <div id="ai-examples" class="ai-examples"></div>
          <div class="workflow-toolbar">
            <button class="hbtn" id="ai-generate" type="button">✨ Tạo workflow</button>
            <button class="hbtn" id="ai-insert" type="button">Insert vào Editor</button>
            <button class="hbtn" id="ai-refine" type="button">Refine prompt</button>
            <span id="ai-status" class="workflow-status">—</span>
          </div>
          <pre id="ai-preview" class="ai-preview"></pre>
        </div>
      </section>
      <section class="workflow-lua-modal hidden" id="workflow-lua-modal">
        <div class="workflow-backdrop" data-lua-close="1"></div>
        <div class="workflow-lua-box">
          <header class="workflow-panel-head">
            <strong id="workflow-lua-title">Lua editor</strong>
            <button class="hbtn" data-lua-close="1" type="button">Đóng</button>
          </header>
          <p id="workflow-lua-summary" class="workflow-status">—</p>
          <label class="workflow-lua-profile">API profile<input id="workflow-lua-api-profile" type="text" value="ioscontrol-v1"></label>
          <textarea id="workflow-lua-output" spellcheck="false"></textarea>
          <div class="workflow-toolbar">
            <button class="hbtn" id="workflow-copy-lua" type="button">Copy Lua</button>
            <button class="hbtn" id="workflow-download-lua" type="button">Tải .lua</button>
            <button class="hbtn" id="workflow-apply-lua" type="button">Dùng Lua này làm kịch bản</button>
            <button class="hbtn" id="workflow-save-lua" type="button">Lưu Lua</button>
            <button class="hbtn primary" id="workflow-run-lua-editor" type="button">Chạy Lua trong ô</button>
          </div>
        </div>
      </section>
      <input id="workflow-import-file" type="file" accept=".json,.lua,.txt,application/json,text/x-lua,text/plain" hidden>
      <input id="workflow-asset-file" type="file" accept="image/png,image/jpeg,image/jpg" hidden>`;
    document.body.appendChild(modal);
    previewVideo = byId("workflow-preview-video");
    lastFrameCanvas = byId("workflow-last-frame");
    previewCanvas = byId("workflow-preview-overlay");
    bindModal();
    return modal;
  }

  function bindModal() {
    modal.addEventListener("click", (event) => {
      if (!(event.target instanceof HTMLElement)) return;
      if (event.target.dataset.workflowClose) close();
      if (event.target.dataset.aiClose) closeAi();
      if (event.target.dataset.luaClose) closeLua();
    });
    byId("workflow-save").addEventListener("click", saveCurrent);
    byId("workflow-new").addEventListener("click", () => setWorkflow(global.HidWorkflowBlocks.createWorkflow("Workflow mới"), { resetTest: true }));
    byId("workflow-new-lua").addEventListener("click", newRawLuaWorkflow);
    byId("workflow-import").addEventListener("click", () => byId("workflow-import-file").click());
    byId("workflow-export").addEventListener("click", exportCurrent);
    byId("workflow-view-lua").addEventListener("click", viewGeneratedLua);
    byId("workflow-api-reference").addEventListener("click", () => global.HidApiReference?.open?.());
    byId("workflow-push-script").addEventListener("click", pushCurrentScript);
    byId("workflow-run-device-script").addEventListener("click", runCurrentOnDevice);
    byId("workflow-stop-device-script").addEventListener("click", stopCurrentOnDevice);
    byId("workflow-delete-selected").addEventListener("click", deleteSelectedSavedWorkflows);
    byId("workflow-select-all").addEventListener("change", toggleSelectAllSavedWorkflows);
    byId("workflow-record-toggle").addEventListener("click", toggleRecording);
    byId("workflow-undo-last").addEventListener("click", undoLastStep);
    byId("workflow-preview-only").addEventListener("click", previewOnly);
    byId("workflow-test-block").addEventListener("click", testSelectedBlock);
    byId("workflow-test-run").addEventListener("click", testWorkflow);
    byId("workflow-run").addEventListener("click", testWorkflow);
    byId("workflow-pause").addEventListener("click", () => runner?.pause());
    byId("workflow-resume").addEventListener("click", () => runner?.resume());
    byId("workflow-cancel").addEventListener("click", () => runner?.cancel());
    byId("workflow-copy-run-log").addEventListener("click", copyRunLog);
    byId("workflow-clear-run-log").addEventListener("click", () => renderRunLog({ log: [] }));
    byId("workflow-reconnect-target").addEventListener("click", reconnectPrimaryTarget);
    byId("workflow-ai-open").addEventListener("click", openAi);
    byId("workflow-settings").addEventListener("click", () => global.HidSettings?.open?.());
    byId("workflow-name").addEventListener("input", (event) => {
      currentWorkflow.name = event.target.value || "Workflow chưa đặt tên";
      currentWorkflow.updated_at = nowIso();
    });
    byId("workflow-import-file").addEventListener("change", importWorkflowFile);
    byId("workflow-asset-file").addEventListener("change", importImageAssetFile);
    byId("ai-generate").addEventListener("click", generateAiWorkflow);
    byId("ai-insert").addEventListener("click", insertAiWorkflow);
    byId("ai-refine").addEventListener("click", () => byId("ai-prompt").focus());
    byId("workflow-copy-lua").addEventListener("click", copyGeneratedLua);
    byId("workflow-download-lua").addEventListener("click", downloadGeneratedLua);
    byId("workflow-apply-lua").addEventListener("click", () => {
      try {
        applyLuaEditorToCurrent({ closeAfterApply: false });
      } catch (error) {
        integration.toast?.(`Áp dụng Lua lỗi: ${error.message || error}`, "error");
      }
    });
    byId("workflow-save-lua").addEventListener("click", saveLuaEditorAsWorkflow);
    byId("workflow-run-lua-editor").addEventListener("click", runLuaEditorOnDevice);
    byId("workflow-lua-output").addEventListener("input", onLuaEditorInput);
    byId("workflow-lua-api-profile").addEventListener("input", onLuaProfileInput);
    byId("workflow-quick-actions").querySelectorAll("[data-workflow-quick]").forEach((button) => {
      button.addEventListener("click", () => runQuickAction(button.dataset.workflowQuick || "", button));
    });
    previewCanvas.addEventListener("pointerdown", onPreviewPointerDown);
    previewCanvas.addEventListener("pointermove", onPreviewPointerMove);
    previewCanvas.addEventListener("pointerup", onPreviewPointerUp);
    previewCanvas.addEventListener("pointercancel", cancelRecorderPointer);
    previewCanvas.addEventListener("lostpointercapture", cancelRecorderPointer);
    previewCanvas.addEventListener("mousemove", (event) => {
      const point = pointFromPreviewEvent(event, true);
      if (point) lastPreviewPoint = point;
      byId("workflow-coordinate-readout").textContent = `point: ${formatPoint(point)}`;
    });
    previewResizeObserver = new ResizeObserver(() => drawOverlay());
    previewResizeObserver.observe(byId("workflow-preview-stage"));
    previewVideo.addEventListener("loadedmetadata", () => {
      snapshotLastFrame();
      drawOverlay();
    });
    previewVideo.addEventListener("timeupdate", snapshotLastFrame);
  }

  function install(options) {
    integration = options || {};
    ensureModal();
    renderPalette();
    renderExamples();
    setWorkflow(global.HidWorkflowBlocks.createWorkflow("Workflow mới"), { resetTest: true });
    renderWorkflowList();
    renderHistory();
  }

  function open() {
    ensureModal();
    renderWorkflowList();
    renderHistory();
    refreshTargets();
    updateRecordingUi();
    modal.classList.remove("hidden");
    startTargetRefreshLoop();
    requestAnimationFrame(() => {
      refreshTargets();
      drawOverlay();
    });
  }

  function close() {
    modal?.classList.add("hidden");
    recorderState = null;
    isRecording = false;
    stopTargetRefreshLoop();
    updateRecordingUi();
  }

  function startTargetRefreshLoop() {
    stopTargetRefreshLoop();
    targetRefreshTimer = setInterval(() => {
      if (!modal || modal.classList.contains("hidden")) return;
      refreshTargets();
    }, 1000);
  }

  function stopTargetRefreshLoop() {
    if (targetRefreshTimer) clearInterval(targetRefreshTimer);
    targetRefreshTimer = null;
  }

  function updateRecordingUi() {
    if (!modal) return;
    const button = byId("workflow-record-toggle");
    const state = byId("workflow-recording-state");
    if (button) {
      button.textContent = isRecording ? "Dừng ghi" : (hasRecordedOnce ? "Tiếp tục ghi" : "Bắt đầu ghi");
      button.classList.toggle("active", isRecording);
    }
    if (state) {
      state.textContent = isRecording ? "● ĐANG GHI: thao tác sẽ chạy thật + lưu vào kịch bản" : "ĐANG DỪNG GHI: vẫn điều khiển live, không lưu bước";
      state.classList.toggle("recording", isRecording);
    }
  }

  function toggleRecording() {
    refreshTargets();
    if (!primaryTarget) {
      integration.toast?.("Chưa chọn máy live/connected để ghi", "error");
      return;
    }
    isRecording = !isRecording;
    if (isRecording) hasRecordedOnce = true;
    byId("workflow-status").textContent = isRecording ? "Đang ghi thao tác live" : "Đã dừng ghi; có thể đưa máy về màn hình bắt đầu rồi Test workflow";
    updateRecordingUi();
  }

  function undoLastStep() {
    const removed = currentWorkflow.blocks.pop();
    if (!removed) return;
    rebuildConnections();
    selectedBlockId = currentWorkflow.blocks[currentWorkflow.blocks.length - 1]?.id || "";
    markDirty();
    renderCanvas();
    integration.toast?.(`Đã xoá bước cuối: ${removed.type}`, "info");
  }

  function renderPalette() {
    byId("workflow-palette-list").innerHTML = global.HidWorkflowBlocks.BlockTypes.map((block) => (
      `<button class="workflow-palette-item" draggable="true" data-block-type="${block.type}" type="button">${escapeHtml(block.label)}</button>`
    )).join("");
    byId("workflow-palette-list").querySelectorAll("[data-block-type]").forEach((button) => {
      button.addEventListener("click", () => addBlock(button.dataset.blockType));
      button.addEventListener("dragstart", (event) => event.dataTransfer?.setData("text/plain", button.dataset.blockType));
    });
    const canvas = byId("workflow-canvas");
    canvas.addEventListener("dragover", (event) => event.preventDefault());
    canvas.addEventListener("drop", (event) => {
      handleCanvasDrop(event, currentWorkflow.blocks.length);
    });
  }

  function renderExamples() {
    byId("ai-examples").innerHTML = global.HidAiPrompts.Examples.map((example) => `<button class="mini-btn" data-ai-example="${escapeHtml(example.prompt)}" type="button">${escapeHtml(example.label)}</button>`).join("");
    byId("ai-examples").querySelectorAll("[data-ai-example]").forEach((button) => {
      button.addEventListener("click", () => { byId("ai-prompt").value = button.dataset.aiExample || ""; });
    });
  }

  function defaultRawLuaTemplate() {
    return [
      "-- Lua mới cho HIDProbe",
      "-- Viết từng bước ở đây, rồi bấm Chạy Lua trong ô để test thật trên iPhone.",
      'reportStep("start:Lua mới")',
      "",
      "-- Ví dụ:",
      "-- appRun(\"com.apple.mobilesafari\")",
      "-- msleep(3500)",
      "-- tap(0.50, 0.92)",
      "-- msleep(1800)",
      "-- inputText(\"thuypp.fun\")",
      "-- msleep(2500)",
      "-- tap(0.94, 0.945)",
      "",
      'reportStep("done:Lua mới")',
    ].join("\n");
  }

  function newRawLuaWorkflow() {
    const workflow = global.HidWorkflowBlocks.createWorkflow("Lua mới");
    workflow.raw_lua = defaultRawLuaTemplate();
    workflow.raw_lua_filename = `lua_moi_${Date.now()}.lua`;
    workflow.api_profile = "ioscontrol-v1";
    workflow.description = "Lua viết trực tiếp trong web";
    setWorkflow(workflow, { resetTest: true });
    byId("workflow-status").textContent = `Đã tạo Lua mới · ${rawLuaLineCount()} dòng`;
    integration.toast?.("Đã tạo kịch bản Lua mới", "success");
    viewGeneratedLua();
  }

  function syncBlockPositions() {
    currentWorkflow.blocks.forEach((block, index) => {
      block.position = { ...(block.position || {}), x: 120, y: 80 + index * 90 };
    });
  }

  function addBlock(type, insertAt = null) {
    const selectedIndex = currentWorkflow.blocks.findIndex((item) => item.id === selectedBlockId);
    const fallbackIndex = selectedIndex >= 0 ? selectedIndex + 1 : currentWorkflow.blocks.length;
    const index = Number.isInteger(insertAt) ? Math.max(0, Math.min(insertAt, currentWorkflow.blocks.length)) : fallbackIndex;
    const overrides = { position: { x: 120, y: 80 + index * 90 } };
    if (type === "loop" && index > 0) {
      overrides.params = { repeat_from_step: 1, repeat_to_step: 0 };
    }
    const block = global.HidWorkflowBlocks.createBlock(type, overrides);
    insertBlock(block, Number.isInteger(insertAt) ? index : null);
  }

  function insertBlock(block, insertAt = null) {
    if (isRawLuaWorkflow()) {
      currentWorkflow.raw_lua = "";
      currentWorkflow.raw_lua_filename = "";
      currentWorkflow.api_profile = "hidprobe-v1";
    }
    const selectedIndex = currentWorkflow.blocks.findIndex((item) => item.id === selectedBlockId);
    const fallbackIndex = selectedIndex >= 0 ? selectedIndex + 1 : currentWorkflow.blocks.length;
    const targetIndex = Number.isInteger(insertAt) ? Math.max(0, Math.min(insertAt, currentWorkflow.blocks.length)) : fallbackIndex;
    currentWorkflow.blocks.splice(targetIndex, 0, block);
    syncBlockPositions();
    rebuildConnections();
    selectedBlockId = block.id;
    markDirty();
    renderCanvas();
  }

  function moveBlock(blockId, insertAt) {
    const oldIndex = currentWorkflow.blocks.findIndex((block) => block.id === blockId);
    if (oldIndex < 0) return;
    let targetIndex = Math.max(0, Math.min(Number(insertAt), currentWorkflow.blocks.length));
    const [block] = currentWorkflow.blocks.splice(oldIndex, 1);
    if (oldIndex < targetIndex) targetIndex -= 1;
    targetIndex = Math.max(0, Math.min(targetIndex, currentWorkflow.blocks.length));
    currentWorkflow.blocks.splice(targetIndex, 0, block);
    syncBlockPositions();
    rebuildConnections();
    selectedBlockId = block.id;
    markDirty();
    renderCanvas();
  }

  function dropIndexForNode(event, node, index) {
    const rect = node.getBoundingClientRect();
    const middle = rect.top + rect.height / 2;
    return event.clientY < middle ? index : index + 1;
  }

  function handleCanvasDrop(event, insertAt) {
    event.preventDefault();
    event.stopPropagation();
    const movingId = event.dataTransfer?.getData("application/x-hid-workflow-block-id")
      || String(event.dataTransfer?.getData("text/plain") || "").replace(/^move:/, "");
    const existing = currentWorkflow.blocks.some((block) => block.id === movingId);
    if (existing) {
      moveBlock(movingId, insertAt);
      return;
    }
    const type = event.dataTransfer?.getData("text/plain");
    if (String(type || "").startsWith("move:")) return;
    if (type) addBlock(type, insertAt);
  }

  function rebuildConnections() {
    currentWorkflow.connections = currentWorkflow.blocks.slice(0, -1).map((block, index) => ({ from: block.id, to: currentWorkflow.blocks[index + 1].id, port: "next" }));
  }

  function setWorkflow(workflow, options = {}) {
    currentWorkflow = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
    if (options.resetTest) currentWorkflow.test_metadata = null;
    if (options.resetTest) {
      isRecording = false;
      hasRecordedOnce = false;
    }
    byId("workflow-name").value = currentWorkflow.name;
    selectedBlockId = currentWorkflow.blocks[0]?.id || "";
    lastSuccessfulTestHash = options.resetTest ? "" : (currentWorkflow.test_metadata?.tested_hash || "");
    lastTestMetadata = options.resetTest ? null : (currentWorkflow.test_metadata || null);
    renderCanvas();
    updateSaveGate();
    updateRecordingUi();
  }

  function renderCanvas() {
    const activeId = runner?.currentBlockId || "";
    if (isRawLuaWorkflow()) {
      const file = currentWorkflow.raw_lua_filename || safeLuaFileName();
      byId("workflow-canvas").innerHTML = `
        <article class="workflow-block selected">
          <div class="workflow-block-title">Lua nhập trực tiếp <small>${escapeHtml(currentWorkflow.api_profile || "ioscontrol-v1")}</small></div>
          <div class="workflow-block-meta">${escapeHtml(file)} · ${rawLuaLineCount()} dòng · bấm Sửa/Chạy Lua hoặc Chạy trên iPhone</div>
        </article>`;
      selectedBlockId = "";
      updateBlocksColumnStatus();
      renderProperties();
      drawOverlay();
      return;
    }
    byId("workflow-canvas").innerHTML = currentWorkflow.blocks.map((block, index) => {
      const spec = global.HidWorkflowBlocks.BlockTypeMap.get(block.type);
      const stateClass = activeId === block.id ? "running" : "";
      const detail = blockDetail(block);
      return `
        <article class="workflow-block ${stateClass} ${selectedBlockId === block.id ? "selected" : ""}" data-block-id="${escapeHtml(block.id)}" data-block-index="${index}" draggable="true">
          <div class="workflow-block-title">${escapeHtml(spec?.label || block.type)} <small>${index + 1}</small></div>
          <div class="workflow-block-meta">${escapeHtml(detail || block.id)}</div>
          <button class="workflow-delete" data-delete-block="${escapeHtml(block.id)}" type="button">×</button>
        </article>`;
    }).join("") || `<div class="workflow-empty">Bấm Bắt đầu ghi, rồi thao tác trực tiếp trên màn hình live. Khi dừng ghi, màn hình vẫn điều khiển iPhone nhưng không lưu bước.</div>`;
    byId("workflow-canvas").querySelectorAll("[data-block-id]").forEach((node) => {
      node.addEventListener("click", (event) => {
        if (event.target instanceof HTMLElement && event.target.dataset.deleteBlock) return;
        selectedBlockId = node.dataset.blockId || "";
        renderCanvas();
      });
      node.addEventListener("dragstart", (event) => {
        event.dataTransfer?.setData("application/x-hid-workflow-block-id", node.dataset.blockId || "");
        event.dataTransfer?.setData("text/plain", `move:${node.dataset.blockId || ""}`);
        event.dataTransfer?.setDragImage?.(node, 24, 18);
      });
      node.addEventListener("dragover", (event) => event.preventDefault());
      node.addEventListener("drop", (event) => {
        const index = Number(node.dataset.blockIndex || 0);
        handleCanvasDrop(event, dropIndexForNode(event, node, index));
      });
    });
    byId("workflow-canvas").querySelectorAll("[data-delete-block]").forEach((button) => {
      button.addEventListener("click", () => deleteBlock(button.dataset.deleteBlock));
    });
    updateBlocksColumnStatus();
    renderProperties();
    drawOverlay();
  }

  function blockDetail(block) {
    const params = block.params || {};
    if (block.type === "tap") {
      const label = String(params.element_label || "").trim();
      if (label) return `tap ${label} (${Number(params.x).toFixed(3)},${Number(params.y).toFixed(3)})`;
      return `tap ${Number(params.x).toFixed(3)},${Number(params.y).toFixed(3)}`;
    }
    if (block.type === "long_press") return `long ${Number(params.x).toFixed(3)},${Number(params.y).toFixed(3)} · ${params.hold_ms || 800}ms`;
    if (block.type === "swipe") {
      const points = global.HidWorkflowBlocks.swipePoints(params);
      return `swipe ${formatPoint(points.from)} → ${formatPoint(points.to)}`;
    }
    if (block.type === "hardware_home") return "home";
    if (block.type === "screenshot") return `shot ${params.save_as || "screenshot"}`;
    if (block.type === "open_app") return `mở ${params.app_name || params.bundle_id || params.url_scheme || "chưa chọn app"}`;
    if (block.type === "open_url") return `mở URL ${params.url || "chưa nhập"}`;
    if (block.type === "extok_tiktok_job") return `Extok ${params.job_type || "follow"} · ${params.unique_username || "chưa nhập user"}`;
    if (block.type === "kill_app") return `đóng ${params.app_name || params.bundle_id || "chưa nhập bundle"}`;
    if (block.type === "input_text") {
      const text = String(params.input_text ?? params.text ?? "").trim();
      return `nhập "${text || "chưa nhập"}"${params.submit_after ? " rồi Go" : ""}`;
    }
    if (block.type === "wait_text") return `chờ chữ "${params.text || "chưa nhập"}" · ${params.timeout_ms || 300000}ms`;
    if (block.type === "tap_text") return `thấy chữ "${params.text || "chưa nhập"}" rồi nhấn`;
    if (block.type === "wait_image") return `chờ ảnh ${params.image || "target.png"} · ${params.threshold || 0.9}${imageSearchModeSuffix(params, "image")}`;
    if (block.type === "tap_image") return `thấy ảnh ${params.image || "target.png"} rồi nhấn${imageSearchModeSuffix(params, "image")}`;
    if (block.type === "tap_image_optional") return `nếu thấy ảnh ${params.image || "target.png"} thì nhấn, không thấy thì bỏ qua${imageSearchModeSuffix(params, "image")}`;
    if (block.type === "tap_if_image") {
      const mode = String(params.action_mode || "coordinate").trim().toLowerCase();
      const extraCount = imageListFromValue(params.condition_images).length;
      const conditionLabel = `${params.condition_image || "A"}${extraCount ? ` +${extraCount} ảnh A` : ""}`;
      const conditionSearch = imageSearchModeSuffix(params, "condition_image");
      const targetSearch = mode === "image" ? imageSearchModeSuffix(params, "target_image") : "";
      return mode === "image"
        ? `nếu thấy ${conditionLabel}${conditionSearch} thì nhấn ảnh ${params.target_image || "B"}${targetSearch}`
        : `nếu thấy ${conditionLabel}${conditionSearch} thì nhấn ${Number(params.x).toFixed(3)},${Number(params.y).toFixed(3)}`;
    }
    if (block.type === "tap_image_state_pair") {
      const firstMode = String(params.first_action_mode || "self").trim().toLowerCase();
      const mode = String(params.second_action_mode || "coordinate").trim().toLowerCase();
      const firstAction = firstMode === "image"
        ? `nhấn ảnh ${params.first_target_image || "đích 1"}`
        : firstMode === "coordinate"
          ? `nhấn ${Number(params.first_x).toFixed(3)},${Number(params.first_y).toFixed(3)}`
          : "nhấn chính ảnh đó";
      const secondAction = mode === "image"
        ? `nhấn ảnh ${params.second_target_image || "Back"}`
        : `nhấn ${Number(params.second_x).toFixed(3)},${Number(params.second_y).toFixed(3)}`;
      return `thấy ${params.first_image || "Follow"} thì ${firstAction}; thấy ${params.second_image || "Tin nhắn"} thì ${secondAction}`;
    }
    if (block.type === "loop") {
      const from = Number(params.repeat_from_step || 0);
      const to = Number(params.repeat_to_step || 0);
      if (from > 0) return `lặp ${params.iterations || 3} lần · bước ${from} → ${to > 0 ? to : "trước Loop"}`;
      return `lặp ${params.iterations || 3} lần · body ${(block.body || []).length} bước`;
    }
    return block.id;
  }

  function blockHelp(block) {
    if (block.type === "open_app") return "Nhập Bundle ID để Lua xuất openApp(bundle_id). Khi Test, web sẽ gửi script nhỏ để mở app live trên iPhone.";
    if (block.type === "open_url") return "Nhập URL. Lua sinh kịch bản raw: mở Safari, bấm thanh địa chỉ dưới, nhập URL, bấm Go rồi kết thúc, không OCR/chờ chữ.";
    if (block.type === "extok_tiktok_job") return "Lua gọi Extok API V2 từ iPhone, lấy job TikTok, mở link, thử bấm Follow theo chữ thật/OCR, rồi gọi complete hoặc skip. API key chỉ nhập trong workflow cần chạy.";
    if (block.type === "kill_app") return "Đóng process app bằng appKill(bundle_id). Không thao tác App Switcher để tránh làm WebRTC mất kết nối.";
    if (block.type === "input_text") return "Nhập chữ vào ô đang focus. Dùng sau block Nhấn/Nhấn đúng chữ đã tap vào ô URL hoặc ô nhập; bật Go/Return để gửi/mở URL.";
    if (block.type === "wait_text") return "Lua sẽ chờ OCR thấy đúng chữ. Chưa thấy thì quét lại; hết thời gian thì fail hoặc gửi Telegram nếu bạn điền cấu hình.";
    if (block.type === "tap_text") return "Lua chỉ nhấn khi OCR thấy đúng chữ. Không thấy đúng chữ thì không tap mù.";
    if (block.type === "wait_image") return "Lua sẽ chờ thấy ảnh mẫu. Cần IPA có hàm waitForImage và file ảnh nằm trong gói script.";
    if (block.type === "tap_image") return "Lua chỉ nhấn khi thấy đúng ảnh mẫu. Ảnh crop từ live có anchor để tránh match nhầm sang icon khác.";
    if (block.type === "tap_image_optional") return "Dùng cho popup lúc hiện lúc không: Lua thử tìm ảnh trong timeout ngắn; thấy thì nhấn, không thấy thì bỏ qua và chạy tiếp.";
    if (block.type === "tap_if_image") return "Điều kiện là ảnh A. Có thể thêm nhiều ảnh A dự phòng từ các live frame khác nhau; Lua thấy bất kỳ ảnh A nào thì mới nhấn X/Y hoặc ảnh B. Không thấy A thì bỏ qua.";
    if (block.type === "tap_image_state_pair") return "Quét 2 trạng thái trong cùng một block. Mỗi trạng thái có ảnh điều kiện riêng và có thể bấm chính ảnh đó, bấm tọa độ, hoặc bấm ảnh đích khác. Nếu bật xử lý trạng thái 2 sau trạng thái 1, Lua sẽ làm trạng thái 1 rồi chờ trạng thái 2 để làm tiếp.";
    if (block.type === "loop") return "Đặt Loop sau nhóm cần lặp. Dùng Lặp từ bước/Đến bước để gom vùng phía trên vào vòng lặp; các bước trong vùng đó sẽ không chạy riêng lẻ nữa.";
    return "Toạ độ là advanced/debug. Cách đúng: ghi lại trên màn hình live.";
  }

  function deleteBlock(blockId) {
    currentWorkflow.blocks = currentWorkflow.blocks.filter((block) => block.id !== blockId);
    rebuildConnections();
    selectedBlockId = currentWorkflow.blocks[0]?.id || "";
    markDirty();
    renderCanvas();
  }

  function blockSupportsImageParam(block, paramKey = "image") {
    if (!block) return false;
    if (["wait_image", "tap_image", "tap_image_optional"].includes(block.type)) return paramKey === "image";
    if (block.type === "tap_if_image") {
      if (paramKey === "condition_image") return true;
      if (paramKey === "condition_images") return true;
      if (paramKey === "target_image") return String(block.params?.action_mode || "coordinate").trim().toLowerCase() === "image";
    }
    if (block.type === "tap_image_state_pair") {
      if (paramKey === "first_image") return true;
      if (paramKey === "first_target_image") return String(block.params?.first_action_mode || "self").trim().toLowerCase() === "image";
      if (paramKey === "second_image") return true;
      if (paramKey === "second_target_image") return String(block.params?.second_action_mode || "coordinate").trim().toLowerCase() === "image";
    }
    return false;
  }

  function imageAssetPanelForParam(block, paramKey, title) {
    const image = String(block.params?.[paramKey] || "").trim();
    const asset = assetForPath(image);
    const preview = dataUrlForAsset(asset);
    const dims = asset?.width && asset?.height ? ` · ${asset.width}x${asset.height}` : "";
    const sourceDims = asset?.source_width && asset?.source_height ? ` · frame ${asset.source_width}x${asset.source_height}` : "";
    const meta = asset
      ? `${asset.path}${dims}${sourceDims} · ${Math.round((asset.size || 0) / 1024)} KB · ${String(asset.sha256 || "").slice(0, 12)}`
      : (image ? `${image} · chưa có file ảnh trong package` : "Chưa chọn ảnh mẫu");
    return `
      <div class="workflow-prop-assets">
        <strong>${escapeHtml(title || "Ảnh mẫu thực tế")}</strong>
        ${preview ? `<img class="workflow-asset-preview" src="${escapeHtml(preview)}" alt="">` : ""}
        <p class="workflow-status">${escapeHtml(meta)}</p>
        <div class="workflow-prop-actions">
          <button class="hbtn" data-image-asset-action="import" data-image-param="${escapeHtml(paramKey)}" type="button">Nhập ảnh</button>
          <button class="hbtn" data-image-asset-action="crop-native" data-image-param="${escapeHtml(paramKey)}" type="button">Crop native iPhone</button>
          <button class="hbtn danger" data-image-asset-action="delete" data-image-param="${escapeHtml(paramKey)}" type="button" ${asset ? "" : "disabled"}>Xoá ảnh</button>
        </div>
      </div>`;
  }

  function imageSearchScopePanelForParam(block, paramKey, title) {
    const prefix = imageSearchPrefixForParam(paramKey);
    const modeKey = `${prefix}_search_mode`;
    const regionsKey = `${prefix}_search_regions`;
    const mode = normalizeImageSearchMode(block.params?.[modeKey]);
    const regions = normalizedSearchRegions(block.params?.[regionsKey]);
    const regionRows = regions.map((region, index) => {
      const regionLabel = region.type === "roi"
        ? `ROI ${index + 1}: x=${region.x}, y=${region.y}, w=${region.width}, h=${region.height}`
        : `Điểm ${index + 1}: x=${region.x}, y=${region.y}, radius=${region.radius}`;
      return `
        <div class="workflow-asset-list-item">
          <p class="workflow-status">${escapeHtml(regionLabel)}</p>
          <button class="hbtn danger" data-image-search-action="delete-region" data-image-search-prefix="${escapeHtml(prefix)}" data-image-search-index="${index}" type="button">Xoá điểm/ROI này</button>
        </div>`;
    }).join("");
    return `
      <div class="workflow-prop-assets">
        <strong>${escapeHtml(title || "Phạm vi tìm ảnh")}</strong>
        <p class="workflow-status">Mặc định full screen giữ tương thích JSON cũ. ROI-first/ROI-only sẽ được runtime dùng khi exporter/iPhone hỗ trợ các field này.</p>
        <label>Chế độ quét
          <select data-image-search-mode-prefix="${escapeHtml(prefix)}">
            <option value="full_screen" ${mode === "full_screen" ? "selected" : ""}>Full screen như cũ</option>
            <option value="prefer_regions_then_full" ${mode === "prefer_regions_then_full" ? "selected" : ""}>Ưu tiên tọa độ/ROI, miss thì fallback full</option>
            <option value="regions_only" ${mode === "regions_only" ? "selected" : ""}>Chỉ quét tọa độ/ROI, không fallback full</option>
          </select>
        </label>
        <label>Điểm/ROI thủ công JSON
          <textarea data-image-search-regions-prefix="${escapeHtml(prefix)}" rows="4" spellcheck="false" placeholder="${escapeHtml(paramPlaceholder(regionsKey))}">${escapeHtml(JSON.stringify(regions, null, 2))}</textarea>
        </label>
        ${regionRows || `<p class="workflow-status">Chưa có điểm/ROI gợi ý. Bấm "Thêm điểm live" để lấy tọa độ hiện tại trên màn hình live.</p>`}
        <div class="workflow-prop-actions">
          <button class="hbtn" data-image-search-action="add-live-point" data-image-search-prefix="${escapeHtml(prefix)}" type="button">Thêm điểm live</button>
          <button class="hbtn" data-image-search-action="pick-live-point" data-image-search-prefix="${escapeHtml(prefix)}" type="button">Chọn điểm trên live</button>
          <button class="hbtn danger" data-image-search-action="clear-regions" data-image-search-prefix="${escapeHtml(prefix)}" type="button" ${regions.length ? "" : "disabled"}>Xoá tất cả điểm/ROI</button>
        </div>
      </div>`;
  }

  function imageAssetListPanelForParam(block, paramKey, title) {
    const images = uniqueImageList(imageListFromValue(block.params?.[paramKey]));
    const items = images.map((image) => {
      const asset = assetForPath(image);
      const preview = dataUrlForAsset(asset);
      const dims = asset?.width && asset?.height ? ` · ${asset.width}x${asset.height}` : "";
      const sourceDims = asset?.source_width && asset?.source_height ? ` · frame ${asset.source_width}x${asset.source_height}` : "";
      const meta = asset
        ? `${asset.path}${dims}${sourceDims} · ${Math.round((asset.size || 0) / 1024)} KB · ${String(asset.sha256 || "").slice(0, 12)}`
        : `${image} · chưa có file ảnh trong package`;
      return `
        <div class="workflow-asset-list-item">
          ${preview ? `<img class="workflow-asset-preview" src="${escapeHtml(preview)}" alt="">` : ""}
          <p class="workflow-status">${escapeHtml(meta)}</p>
          <button class="hbtn danger" data-image-asset-action="delete-list" data-image-param="${escapeHtml(paramKey)}" data-image-path="${escapeHtml(image)}" type="button">Xoá ảnh này</button>
        </div>`;
    }).join("");
    return `
      <div class="workflow-prop-assets">
        <strong>${escapeHtml(title || "Ảnh mẫu dự phòng")}</strong>
        <p class="workflow-status">${images.length ? `Đang có ${images.length} ảnh dự phòng. Lua sẽ thử từng ảnh cho tới khi thấy một ảnh A.` : "Chưa có ảnh dự phòng. Nếu ảnh A lúc có lúc không match, hãy crop native thêm 3-5 ảnh cùng icon từ iPhone."}</p>
        ${items}
        <div class="workflow-prop-actions">
          <button class="hbtn" data-image-asset-action="import" data-image-param="${escapeHtml(paramKey)}" type="button">Thêm ảnh</button>
          <button class="hbtn" data-image-asset-action="crop-native" data-image-param="${escapeHtml(paramKey)}" type="button">Crop native iPhone</button>
        </div>
      </div>`;
  }

  function imageAssetPanel(block) {
    if (["wait_image", "tap_image", "tap_image_optional"].includes(block?.type)) {
      return [
        imageAssetPanelForParam(block, "image", "Ảnh mẫu thực tế"),
        imageSearchScopePanelForParam(block, "image", "Phạm vi tìm ảnh"),
      ].join("");
    }
    if (block?.type === "tap_if_image") {
      const mode = String(block.params?.action_mode || "coordinate").trim().toLowerCase();
      return [
        tapIfImageActionPanel(block),
        imageAssetPanelForParam(block, "condition_image", "Ảnh điều kiện A"),
        imageSearchScopePanelForParam(block, "condition_image", "Phạm vi tìm ảnh điều kiện A"),
        imageAssetListPanelForParam(block, "condition_images", "Ảnh A dự phòng (multi-image)"),
        mode === "image" ? imageAssetPanelForParam(block, "target_image", "Ảnh cần nhấn B") : "",
        mode === "image" ? imageSearchScopePanelForParam(block, "target_image", "Phạm vi tìm ảnh cần nhấn B") : "",
      ].join("");
    }
    if (block?.type === "tap_image_state_pair") {
      const firstMode = String(block.params?.first_action_mode || "self").trim().toLowerCase();
      const mode = String(block.params?.second_action_mode || "coordinate").trim().toLowerCase();
      return [
        imageAssetPanelForParam(block, "first_image", "Ảnh điều kiện trạng thái 1"),
        firstMode === "image" ? imageAssetPanelForParam(block, "first_target_image", "Ảnh cần nhấn khi thấy trạng thái 1") : "",
        imageAssetPanelForParam(block, "second_image", "Ảnh trạng thái 2: ví dụ Tin nhắn"),
        mode === "image" ? imageAssetPanelForParam(block, "second_target_image", "Ảnh cần nhấn khi thấy trạng thái 2") : "",
      ].join("");
    }
    return "";
  }

  function tapIfImageActionPanel(block) {
    const mode = String(block?.params?.action_mode || "coordinate").trim().toLowerCase() === "image" ? "image" : "coordinate";
    const x = Number(block?.params?.x ?? 0.5);
    const y = Number(block?.params?.y ?? 0.5);
    return `
      <div class="workflow-prop-assets">
        <strong>Kiểu nhấn khi thấy ảnh A</strong>
        <p class="workflow-status">${mode === "image"
          ? "Đang chọn: thấy ảnh A thì tìm ảnh B và nhấn ảnh B."
          : "Đang chọn: thấy ảnh A thì nhấn tọa độ X/Y giống block Nhấn."}</p>
        <label>Chọn cách nhấn
          <select data-param-key="action_mode">
            <option value="coordinate" ${mode === "coordinate" ? "selected" : ""}>Tap tọa độ X/Y</option>
            <option value="image" ${mode === "image" ? "selected" : ""}>Tap ảnh B</option>
          </select>
        </label>
        ${mode === "coordinate" ? `
          <p class="workflow-status">Tọa độ hiện tại: X=${Number.isFinite(x) ? x.toFixed(4) : "0.5000"}, Y=${Number.isFinite(y) ? y.toFixed(4) : "0.5000"}</p>
          <div class="workflow-prop-actions">
            <button class="hbtn primary" id="workflow-pick-conditional-point" type="button">Chọn tọa độ trên live</button>
            <button class="hbtn" id="workflow-set-conditional-point" type="button">Dùng điểm đang chọn làm tọa độ nhấn</button>
          </div>
        ` : ""}
      </div>`;
  }

  function renderProperties() {
    if (isRawLuaWorkflow()) {
      byId("workflow-properties").innerHTML = `
        <div class="workflow-prop-title">lua / ${escapeHtml(currentWorkflow.raw_lua_filename || safeLuaFileName())}</div>
        <p class="workflow-status">File Lua nhập trực tiếp. Web sẽ gửi nguyên nội dung này vào iPhone với api_profile=${escapeHtml(currentWorkflow.api_profile || "ioscontrol-v1")}.</p>
        <label>API profile<input data-raw-lua-profile="1" type="text" value="${escapeHtml(currentWorkflow.api_profile || "ioscontrol-v1")}"></label>
        <div class="workflow-prop-actions">
          <button class="hbtn" id="workflow-edit-raw-lua-side" type="button">Sửa Lua</button>
          <button class="hbtn" id="workflow-test-raw-lua-side" type="button">Chạy Lua này</button>
        </div>`;
      byId("workflow-properties").querySelector("[data-raw-lua-profile]")?.addEventListener("input", (event) => {
        currentWorkflow.api_profile = event.target.value || "ioscontrol-v1";
        markDirty();
      });
      byId("workflow-edit-raw-lua-side")?.addEventListener("click", viewGeneratedLua);
      byId("workflow-test-raw-lua-side")?.addEventListener("click", runCurrentOnDevice);
      return;
    }
    const block = selectedBlock();
    if (!block) {
      byId("workflow-properties").innerHTML = "<p class=\"workflow-status\">Chưa chọn block</p>";
      return;
    }
    const params = block.params || {};
    const hiddenParamKeys = new Set([
      "condition_images",
      "asset_sha256",
      "asset_size",
      "asset_source",
      "asset_width",
      "asset_height",
      "asset_source_width",
      "asset_source_height",
      "image_anchor_x",
      "image_anchor_y",
      "image_anchor_radius",
      "image_search_mode",
      "image_search_regions",
      "condition_image_search_mode",
      "condition_image_search_regions",
      "target_image_search_mode",
      "target_image_search_regions",
    ]);
    if (block.type === "open_url") {
      hiddenParamKeys.add("expect_text");
      hiddenParamKeys.add("expectText");
      hiddenParamKeys.add("timeout_ms");
      hiddenParamKeys.add("timeoutMs");
    }
    if (block.type === "tap_if_image") {
      const mode = String(params.action_mode || "coordinate").trim().toLowerCase() === "image" ? "image" : "coordinate";
      hiddenParamKeys.add("condition_image");
      hiddenParamKeys.add("action_mode");
      hiddenParamKeys.add("target_image");
      if (mode === "image") {
        hiddenParamKeys.add("x");
        hiddenParamKeys.add("y");
      } else {
        hiddenParamKeys.add("target_timeout_ms");
        hiddenParamKeys.add("target_threshold");
      }
    }
    const rows = Object.entries(params).filter(([key]) => (
      !hiddenParamKeys.has(key)
      && !/(^.*_)?asset_(sha256|size|source|width|height|source_width|source_height)$/.test(key)
      && !/(^.*)_anchor_(x|y|radius)$/.test(key)
    )).map(([key, value]) => {
      if (typeof value === "boolean") {
        return `<label>${escapeHtml(paramLabel(key))}<input data-param-key="${escapeHtml(key)}" type="checkbox" ${value ? "checked" : ""}></label>`;
      }
      if (key === "action_mode" || key === "first_action_mode" || key === "second_action_mode") {
        const selected = String(value || (key === "first_action_mode" ? "self" : "coordinate")).trim().toLowerCase();
        return `<label>${escapeHtml(paramLabel(key))}
          <select data-param-key="${escapeHtml(key)}">
            ${key === "first_action_mode" ? `<option value="self" ${selected === "self" ? "selected" : ""}>Tap chính ảnh trạng thái 1</option>` : ""}
            <option value="coordinate" ${selected === "coordinate" ? "selected" : ""}>Tap tọa độ X/Y</option>
            <option value="image" ${selected === "image" ? "selected" : ""}>Tap ảnh</option>
          </select>
        </label>`;
      }
      if (key === "on_error") {
        const selected = String(value || "fail").trim().toLowerCase() === "continue" ? "continue" : "fail";
        return `<label>${escapeHtml(paramLabel(key))}
          <select data-param-key="on_error">
            <option value="fail" ${selected === "fail" ? "selected" : ""}>Fail và dừng kịch bản</option>
            <option value="continue" ${selected === "continue" ? "selected" : ""}>Bỏ lỗi, chạy block tiếp theo</option>
          </select>
        </label>`;
      }
      const inputType = typeof value === "number" ? "number" : "text";
      const step = typeof value === "number" && key.includes("_ms") ? "1" : "0.0001";
      const placeholder = paramPlaceholder(key);
      return `<label>${escapeHtml(paramLabel(key))}<input data-param-key="${escapeHtml(key)}" type="${inputType}" step="${step}" value="${escapeHtml(value)}" placeholder="${escapeHtml(placeholder)}"></label>`;
    }).join("");
    const repick = ["tap", "long_press", "swipe"].includes(block.type)
      ? `<div class="workflow-prop-actions">
          <button class="hbtn" id="workflow-repick" type="button">${block.type === "swipe" ? "Re-draw swipe" : "Re-pick on screen"}</button>
          <button class="hbtn" id="workflow-test-selected-side" type="button">Test block này</button>
        </div>`
      : `<div class="workflow-prop-actions"><button class="hbtn" id="workflow-test-selected-side" type="button">Test block này</button></div>`;
    const conditionalPointAction = (
      block.type === "tap_image_state_pair" && (
        String(params.first_action_mode || "self").trim().toLowerCase() === "coordinate"
        || String(params.second_action_mode || "coordinate").trim().toLowerCase() === "coordinate"
      )
    )
      ? `<div class="workflow-prop-actions">
          ${block.type === "tap_image_state_pair" && String(params.first_action_mode || "self").trim().toLowerCase() === "coordinate" ? `<button class="hbtn" id="workflow-set-first-state-point" type="button">Dùng điểm đang chọn làm tọa độ trạng thái 1</button>` : ""}
          ${block.type === "tap_image_state_pair" && String(params.second_action_mode || "coordinate").trim().toLowerCase() === "coordinate" ? `<button class="hbtn" id="workflow-set-conditional-point" type="button">Dùng điểm đang chọn làm tọa độ trạng thái 2</button>` : ""}
        </div>`
      : "";
    byId("workflow-properties").innerHTML = `
      <div class="workflow-prop-title">${escapeHtml(block.type)} / ${escapeHtml(block.id)}</div>
	      <p class="workflow-status">${escapeHtml(blockHelp(block))}</p>
	      ${rows}
	      ${imageAssetPanel(block)}
	      ${conditionalPointAction}
	      ${repick}
	      ${block.type === "loop" ? "<p class=\"workflow-status\">Ví dụ: muốn lặp bước 3-6 thì đặt Loop sau bước 6, nhập Lặp từ bước=3, Đến bước=0 hoặc 6. Workflow sẽ chạy bước 1-2 một lần, lặp 3-6, rồi chạy tiếp bước dưới Loop.</p>" : ""}`;
    byId("workflow-properties").querySelectorAll("[data-param-key]").forEach((input) => {
      input.addEventListener("input", () => {
        const key = input.dataset.paramKey;
        const previous = block.params[key];
        if (typeof previous === "boolean") {
          block.params[key] = input.checked;
        } else {
          block.params[key] = typeof previous === "number" ? Number(input.value) : input.value;
        }
        markDirty();
        if (key === "action_mode" || key === "first_action_mode" || key === "second_action_mode") {
          renderCanvas();
          renderProperties();
          return;
        }
        drawOverlay();
      });
    });
    byId("workflow-repick")?.addEventListener("click", () => {
      recordReplaceBlockId = block.id;
      integration.toast?.("Thao tác lại trực tiếp trên màn hình live để thay block này", "info");
      byId("workflow-status").textContent = `Đang chờ ghi lại block ${block.id}`;
    });
    byId("workflow-set-first-state-point")?.addEventListener("click", () => {
      const point = lastPreviewPoint || { x: 0.5, y: 0.5 };
      block.params.first_x = Number(point.x);
      block.params.first_y = Number(point.y);
      markDirty();
      renderCanvas();
      integration.toast?.(`Đã set tọa độ trạng thái 1 ${Number(point.x).toFixed(3)},${Number(point.y).toFixed(3)}`, "success");
    });
    byId("workflow-pick-conditional-point")?.addEventListener("click", () => {
      coordinatePickState = { blockId: block.id, target: "conditional" };
      byId("workflow-status").textContent = "Đang chọn tọa độ: bấm 1 điểm trên live screen. Lần bấm này chỉ lưu X/Y, không tap iPhone.";
      integration.toast?.("Bấm 1 điểm trên live screen để lưu tọa độ cho block này", "info");
    });
    byId("workflow-set-conditional-point")?.addEventListener("click", () => {
      applyConditionalPoint(block, lastPreviewPoint || { x: 0.5, y: 0.5 });
    });
    byId("workflow-properties").querySelectorAll("[data-image-asset-action]").forEach((button) => {
      button.addEventListener("click", () => {
        const paramKey = button.dataset.imageParam || "image";
        if (button.dataset.imageAssetAction === "import") {
          assetTargetBlockId = block.id;
          assetTargetParamKey = paramKey;
          byId("workflow-asset-file").click();
        } else if (button.dataset.imageAssetAction === "crop") {
          beginImageCrop(block.id, paramKey, { native: true });
        } else if (button.dataset.imageAssetAction === "crop-native") {
          beginImageCrop(block.id, paramKey, { native: true });
        } else if (button.dataset.imageAssetAction === "delete") {
          removeSelectedImageAsset(block, paramKey);
        } else if (button.dataset.imageAssetAction === "delete-list") {
          removeSelectedImageAsset(block, paramKey, button.dataset.imagePath || "");
        }
      });
    });
    byId("workflow-properties").querySelectorAll("[data-image-search-mode-prefix]").forEach((select) => {
      select.addEventListener("change", () => {
        const prefix = select.dataset.imageSearchModePrefix || "image";
        block.params[`${prefix}_search_mode`] = normalizeImageSearchMode(select.value);
        markDirty();
        renderCanvas();
        renderProperties();
      });
    });
    byId("workflow-properties").querySelectorAll("[data-image-search-regions-prefix]").forEach((textarea) => {
      textarea.addEventListener("change", () => {
        const prefix = textarea.dataset.imageSearchRegionsPrefix || "image";
        try {
          const parsed = JSON.parse(textarea.value || "[]");
          if (!Array.isArray(parsed)) throw new Error("regions_not_array");
          block.params[`${prefix}_search_regions`] = normalizedSearchRegions(parsed);
          markDirty();
          renderCanvas();
          renderProperties();
        } catch (_error) {
          integration.toast?.("Điểm/ROI phải là JSON array hợp lệ", "error");
        }
      });
    });
    byId("workflow-properties").querySelectorAll("[data-image-search-action]").forEach((button) => {
      button.addEventListener("click", () => {
        const prefix = button.dataset.imageSearchPrefix || "image";
        const regionsKey = `${prefix}_search_regions`;
        const action = button.dataset.imageSearchAction || "";
        if (action === "add-live-point") {
          addImageSearchPoint(block, prefix, lastPreviewPoint || { x: 0.5, y: 0.5 });
          return;
        }
        if (action === "pick-live-point") {
          coordinatePickState = { blockId: block.id, target: "image_search", prefix };
          byId("workflow-status").textContent = "Đang chọn điểm tìm ảnh: bấm 1 điểm trên live screen. Lần bấm này chỉ lưu ROI hint, không tap iPhone.";
          integration.toast?.("Bấm 1 điểm trên live screen để thêm điểm tìm ảnh", "info");
          return;
        }
        if (action === "clear-regions") {
          block.params[regionsKey] = [];
          markDirty();
          renderCanvas();
          renderProperties();
          return;
        }
        if (action === "delete-region") {
          const index = Number(button.dataset.imageSearchIndex);
          const regions = normalizedSearchRegions(block.params?.[regionsKey]);
          if (Number.isInteger(index) && index >= 0) regions.splice(index, 1);
          block.params[regionsKey] = regions;
          markDirty();
          renderCanvas();
          renderProperties();
        }
      });
    });
    byId("workflow-test-selected-side")?.addEventListener("click", testSelectedBlock);
  }

  function refreshTargets() {
    const targets = integration.getWorkflowTargets?.() || [];
    const primary = integration.getPrimaryWorkflowTarget?.()
      || targets.find((target) => target?.canReceiveSync?.() && target?.video?.srcObject)
      || targets.find((target) => target?.canReceiveSync?.())
      || targets.find((target) => target?.video?.srcObject)
      || targets[0]
      || null;
    const primaryId = primary?.device?.id || "";
    if (primaryId && primaryId !== lastPrimaryTargetId) {
      clearLastFrame();
      if (previewVideo) previewVideo.srcObject = null;
      lastPrimaryTargetId = primaryId;
      lastTargetReady = false;
    }
    primaryTarget = primary || null;
    const targetReady = !!primaryTarget?.canReceiveSync?.();
    if (previewVideo && primaryTarget?.video?.srcObject) {
      if (previewVideo.srcObject !== primaryTarget.video.srcObject) previewVideo.srcObject = primaryTarget.video.srcObject;
      if (targetReady) snapshotLastFrame();
    } else if (previewVideo && !primaryTarget) {
      previewVideo.srcObject = null;
      clearLastFrame();
      lastPrimaryTargetId = "";
    }
    if (lastTargetReady && !targetReady) pauseRecordingForDisconnect();
    lastTargetReady = targetReady;
    renderTargetInfo(targets);
    drawOverlay();
  }

  function renderTargetInfo(targets) {
    const blocker = byId("workflow-preview-blocker");
    const reconnectButton = byId("workflow-reconnect-target");
    const blockerTitle = byId("workflow-blocker-title");
    const blockerDetail = byId("workflow-blocker-detail");
    const stage = byId("workflow-preview-stage");
    const primaryInfo = integration.describeWorkflowTarget?.(primaryTarget) || null;
    const targetReady = !!primaryTarget?.canReceiveSync?.();
    byId("workflow-primary-device").textContent = primaryInfo ? `Live: ${primaryInfo.id}` : "Chưa có live target";
    byId("workflow-target-summary").textContent = primaryInfo
      ? `${targets.length} target · DC ${primaryInfo.dcOpen ? "open" : "closed"} · video ${primaryInfo.videoReady ? "ready" : "loading"}`
      : "Chọn/tích một máy đang connected trước khi ghi workflow";
    stage.classList.toggle("disconnected", !!primaryTarget && !targetReady);
    if (!primaryTarget) {
      blockerTitle.textContent = "Chưa chọn máy";
      blockerDetail.textContent = "Chọn/tích 1 iPhone rồi mở Workflow Editor để ghi trên màn hình live.";
      reconnectButton.classList.add("hidden");
    } else if (!targetReady) {
      blockerTitle.textContent = "Mất kết nối";
      blockerDetail.textContent = "Workflow đang giữ nguyên. Bấm Kết nối lại để mở stream lại tại đây.";
      reconnectButton.classList.remove("hidden");
      reconnectButton.disabled = reconnectInProgress;
      reconnectButton.textContent = reconnectInProgress ? "Đang kết nối..." : "Kết nối lại";
    }
    blocker.classList.toggle("hidden", !!primaryTarget && targetReady);
    byId("workflow-target-list").innerHTML = targets.map((target) => {
      const info = integration.describeWorkflowTarget?.(target) || { id: target?.device?.id || "unknown", connected: target?.isConnected?.(), dcOpen: target?.isDataChannelOpen?.(), selected: true, videoReady: target?.isVideoReady?.() };
      const ok = info.connected && info.dcOpen;
      return `<span class="workflow-target-chip ${ok ? "ok" : "bad"}">${escapeHtml(info.id)} · ${ok ? "ready" : "not ready"}</span>`;
    }).join("") || "<span class=\"workflow-status\">Chưa có target selected/connected</span>";
  }

  function updateBlocksColumnStatus() {
    const statusEl = byId("workflow-blocks-status");
    if (!statusEl || !currentWorkflow) return;
    const total = Array.isArray(currentWorkflow.blocks) ? currentWorkflow.blocks.length : 0;
    const active = runner?.currentBlockId || "";
    statusEl.textContent = active ? `${total} block · đang chạy ${active}` : `${total} block`;
  }

  function pauseRecordingForDisconnect() {
    cancelRecorderPointer();
    if (isRecording) {
      isRecording = false;
      hasRecordedOnce = true;
      updateRecordingUi();
      byId("workflow-status").textContent = "Mất kết nối · đã tạm dừng ghi, workflow vẫn giữ nguyên";
    }
    if (runner?.status === "running") runner.pause();
  }

  function clearLastFrame() {
    if (!lastFrameCanvas) return;
    const context = lastFrameCanvas.getContext("2d");
    context.clearRect(0, 0, lastFrameCanvas.width || 1, lastFrameCanvas.height || 1);
  }

  function snapshotLastFrame() {
    if (!previewVideo || !lastFrameCanvas || !previewCanvas || previewVideo.readyState < 2) return;
    const rect = previewVideoRect();
    if (!rect) return;
    resizeOverlayCanvas();
    const width = previewCanvas.width || 1;
    const height = previewCanvas.height || 1;
    if (lastFrameCanvas.width !== width) lastFrameCanvas.width = width;
    if (lastFrameCanvas.height !== height) lastFrameCanvas.height = height;
    const context = lastFrameCanvas.getContext("2d");
    context.clearRect(0, 0, width, height);
    context.fillStyle = "#000";
    context.fillRect(0, 0, width, height);
    try {
      context.drawImage(previewVideo, rect.left, rect.top, rect.width, rect.height);
    } catch (_error) {
      // Ignore transient draw failures while the media track is replacing.
    }
  }

  async function reconnectPrimaryTarget() {
    const target = primaryTarget;
    if (!target) {
      integration.toast?.("Chưa có máy để kết nối lại", "error");
      return;
    }
    cancelRecorderPointer();
    if (isRecording) {
      isRecording = false;
      hasRecordedOnce = true;
      updateRecordingUi();
    }
    reconnectInProgress = true;
    renderTargetInfo(integration.getWorkflowTargets?.() || []);
    byId("workflow-status").textContent = `Đang kết nối lại ${target.device?.id || "iPhone"}...`;
    try {
      await integration.reconnectWorkflowTarget?.(target);
      await waitForTargetReady(target, 30000);
      refreshTargets();
      byId("workflow-status").textContent = `Đã kết nối lại ${target.device?.id || "iPhone"} · có thể Tiếp tục ghi`;
      integration.toast?.(`✓ Đã kết nối lại ${target.device?.id || "iPhone"}`, "success");
    } catch (error) {
      refreshTargets();
      integration.toast?.(`Kết nối lại lỗi: ${error.message || error}`, "error");
      byId("workflow-status").textContent = `Kết nối lại lỗi: ${error.message || error}`;
    } finally {
      reconnectInProgress = false;
      renderTargetInfo(integration.getWorkflowTargets?.() || []);
    }
  }

  async function waitForTargetReady(target, timeoutMs) {
    const started = performance.now();
    while (performance.now() - started < timeoutMs) {
      if (target?.canReceiveSync?.()) return true;
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    throw new Error("timeout chờ iPhone connected/DC open");
  }

  function resizeOverlayCanvas() {
    if (!previewCanvas) return;
    const rect = previewCanvas.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    if (previewCanvas.width !== width) previewCanvas.width = width;
    if (previewCanvas.height !== height) previewCanvas.height = height;
  }

  function previewVideoRect() {
    if (!previewVideo || !previewCanvas) return null;
    const canvasBox = previewCanvas.getBoundingClientRect();
    const videoBox = previewVideo.getBoundingClientRect();
    const videoWidth = previewVideo.videoWidth || primaryTarget?.video?.videoWidth || 0;
    const videoHeight = previewVideo.videoHeight || primaryTarget?.video?.videoHeight || 0;
    if (!canvasBox.width || !canvasBox.height || !videoBox.width || !videoBox.height || !videoWidth || !videoHeight) return null;
    const boxAspect = videoBox.width / videoBox.height;
    const videoAspect = videoWidth / videoHeight;
    let width = videoBox.width;
    let height = videoBox.height;
    let left = videoBox.left - canvasBox.left;
    let top = videoBox.top - canvasBox.top;
    if (boxAspect > videoAspect) {
      width = height * videoAspect;
      left += (videoBox.width - width) / 2;
    } else {
      height = width / videoAspect;
      top += (videoBox.height - height) / 2;
    }
    return { left, top, width, height };
  }

  function pointFromPreviewEvent(event, allowOutside = false) {
    const rect = previewVideoRect();
    const canvasBox = previewCanvas.getBoundingClientRect();
    if (!rect || !canvasBox.width || !canvasBox.height) return null;
    const rawX = (event.clientX - canvasBox.left - rect.left) / rect.width;
    const rawY = (event.clientY - canvasBox.top - rect.top) / rect.height;
    if (!allowOutside && (rawX < 0 || rawX > 1 || rawY < 0 || rawY > 1)) return null;
    return { x: Math.min(Math.max(rawX, 0), 1), y: Math.min(Math.max(rawY, 0), 1) };
  }

  function pointToCanvas(point) {
    const rect = previewVideoRect();
    if (!rect || !point) return null;
    return { x: rect.left + point.x * rect.width, y: rect.top + point.y * rect.height };
  }

  function drawOverlay() {
    if (!previewCanvas) return;
    resizeOverlayCanvas();
    const context = previewCanvas.getContext("2d");
    context.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
    const rect = previewVideoRect();
    if (!rect) return;
    context.save();
    context.strokeStyle = "rgba(59,130,246,.55)";
    context.lineWidth = 1;
    context.strokeRect(rect.left, rect.top, rect.width, rect.height);
	    const blocks = currentWorkflow?.blocks || [];
	    blocks.forEach((block, index) => drawBlockMarker(context, block, index));
	    if (recorderState?.startPoint && recorderState?.lastPoint) drawSwipePath(context, recorderState.startPoint, recorderState.lastPoint, true, "Đang kéo");
	    if (imageCropState?.startPoint && imageCropState?.lastPoint) drawImageCropBox(context, imageCropState.startPoint, imageCropState.lastPoint);
	    context.restore();
	  }

	  function drawImageCropBox(context, startNorm, endNorm) {
	    const start = pointToCanvas(startNorm);
	    const end = pointToCanvas(endNorm);
	    if (!start || !end) return;
	    const left = Math.min(start.x, end.x);
	    const top = Math.min(start.y, end.y);
	    const width = Math.abs(end.x - start.x);
	    const height = Math.abs(end.y - start.y);
	    context.save();
	    context.strokeStyle = "#f59e0b";
	    context.fillStyle = "rgba(245,158,11,.16)";
	    context.lineWidth = 2;
	    context.fillRect(left, top, width, height);
	    context.strokeRect(left, top, width, height);
	    context.fillStyle = "#f59e0b";
	    context.font = "bold 12px system-ui";
	    context.fillText("ảnh mẫu", left + 6, Math.max(14, top - 6));
	    context.restore();
	  }

  function drawBlockMarker(context, block, index) {
    const selected = block.id === selectedBlockId;
    const label = String(index + 1);
    context.save();
    context.lineWidth = selected ? 3 : 2;
    context.strokeStyle = selected ? "#f59e0b" : "#22c55e";
    context.fillStyle = selected ? "rgba(245,158,11,.95)" : "rgba(34,197,94,.9)";
    context.font = "bold 12px system-ui";
    const params = block.params || {};
    if (block.type === "tap" || block.type === "long_press") {
      const point = pointToCanvas({ x: Number(params.x), y: Number(params.y) });
      if (!point) { context.restore(); return; }
      const radius = block.type === "long_press" ? 12 : 8;
      context.beginPath();
      context.arc(point.x, point.y, radius, 0, Math.PI * 2);
      context.stroke();
      context.fillText(label, point.x + radius + 4, point.y - radius - 3);
      if (block.type === "long_press") context.fillText(`${params.hold_ms || 800}ms`, point.x + radius + 4, point.y + 12);
    } else if (block.type === "tap_if_image" && String(params.action_mode || "coordinate").trim().toLowerCase() !== "image") {
      const point = pointToCanvas({ x: Number(params.x), y: Number(params.y) });
      if (!point) { context.restore(); return; }
      const radius = 9;
      context.beginPath();
      context.arc(point.x, point.y, radius, 0, Math.PI * 2);
      context.stroke();
      context.fillText(label, point.x + radius + 4, point.y - radius - 3);
      context.fillText("if A", point.x + radius + 4, point.y + 12);
    } else if (block.type === "swipe") {
      const points = global.HidWorkflowBlocks.swipePoints(params);
      drawSwipePath(context, points.from, points.to, selected, label);
    }
    context.restore();
  }

  function drawSwipePath(context, fromNorm, toNorm, selected, label) {
    const from = pointToCanvas(fromNorm);
    const to = pointToCanvas(toNorm);
    if (!from || !to) return;
    context.save();
    context.strokeStyle = selected ? "#f59e0b" : "#38bdf8";
    context.fillStyle = selected ? "#f59e0b" : "#38bdf8";
    context.lineWidth = selected ? 3 : 2;
    context.beginPath();
    context.moveTo(from.x, from.y);
    context.lineTo(to.x, to.y);
    context.stroke();
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    const head = 11;
    context.beginPath();
    context.moveTo(to.x, to.y);
    context.lineTo(to.x - head * Math.cos(angle - Math.PI / 6), to.y - head * Math.sin(angle - Math.PI / 6));
    context.lineTo(to.x - head * Math.cos(angle + Math.PI / 6), to.y - head * Math.sin(angle + Math.PI / 6));
    context.closePath();
    context.fill();
    context.fillText(label, (from.x + to.x) / 2 + 6, (from.y + to.y) / 2 - 6);
    context.restore();
  }

  function hitTestBlock(event) {
    const point = pointFromPreviewEvent(event, true);
    if (!point) return "";
    let best = { id: "", distance: Number.POSITIVE_INFINITY };
    for (const block of currentWorkflow.blocks || []) {
      const params = block.params || {};
      if (block.type === "tap" || block.type === "long_press") {
        const distance = Math.hypot(point.x - Number(params.x), point.y - Number(params.y));
        if (distance < best.distance) best = { id: block.id, distance };
      } else if (block.type === "swipe") {
        const points = global.HidWorkflowBlocks.swipePoints(params);
        const distance = distanceToSegment(point, points.from, points.to);
        if (distance < best.distance) best = { id: block.id, distance };
      }
    }
    return best.distance < 0.04 ? best.id : "";
  }

  function distanceToSegment(point, from, to) {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const lengthSq = dx * dx + dy * dy;
    if (!lengthSq) return Math.hypot(point.x - from.x, point.y - from.y);
    const t = Math.max(0, Math.min(1, ((point.x - from.x) * dx + (point.y - from.y) * dy) / lengthSq));
    return Math.hypot(point.x - (from.x + t * dx), point.y - (from.y + t * dy));
  }

	  function onPreviewPointerDown(event) {
	    refreshTargets();
	    const point = pointFromPreviewEvent(event, false);
	    if (!point) return;
	    if (imageCropState) {
	      onImageCropPointerDown(event, point);
	      return;
	    }
	    if (coordinatePickState) {
	      event.preventDefault();
	      lastPreviewPoint = point;
	      applyCoordinatePick(point);
	      return;
	    }
	    if (!primaryTarget?.canReceiveSync?.()) return;
    event.preventDefault();
	    previewCanvas.setPointerCapture?.(event.pointerId);
    lastPreviewPoint = point;
    const gestureId = crypto.randomUUID();
    recorderState = {
      pointerId: event.pointerId,
      gestureId,
      startPoint: point,
      lastPoint: point,
      startTs: performance.now(),
      moved: false,
      sentDown: false,
      longStarted: false,
      lastMoveAt: 0,
      longTimer: null,
    };
    recorderState.sentDown = sendLiveControl("gesture_down", point, gestureId, { reason: "workflow_live_down" });
    recorderState.longTimer = setTimeout(() => {
      if (!recorderState || recorderState.pointerId !== event.pointerId || recorderState.moved) return;
      recorderState.longStarted = true;
      byId("workflow-status").textContent = "Long press live...";
    }, LiveLongPressMs);
    byId("workflow-coordinate-readout").textContent = `start: ${formatPoint(point)}`;
    drawOverlay();
  }

	  function onPreviewPointerMove(event) {
	    if (imageCropState?.active) {
	      const cropPoint = pointFromPreviewEvent(event, true);
	      if (cropPoint && onImageCropPointerMove(event, cropPoint)) return;
	    }
	    if (!recorderState || recorderState.pointerId !== event.pointerId) return;
    const point = pointFromPreviewEvent(event, true);
    if (!point) return;
    lastPreviewPoint = point;
    const now = performance.now();
    const dx = Math.abs(point.x - recorderState.startPoint.x) * previewCanvas.width;
    const dy = Math.abs(point.y - recorderState.startPoint.y) * previewCanvas.height;
    const movedNow = Math.max(dx, dy) > LiveMoveThresholdPx;
    recorderState.moved = recorderState.moved || movedNow;
    recorderState.lastPoint = point;
    if (movedNow) {
      clearLongTimer(recorderState);
      if (recorderState.sentDown && now - recorderState.lastMoveAt >= LiveMoveThrottleMs) {
        recorderState.lastMoveAt = now;
        sendLiveControl("gesture_move", point, recorderState.gestureId, { reason: "workflow_live_swipe_move" });
      }
    }
    byId("workflow-coordinate-readout").textContent = `drag: ${formatPoint(recorderState.startPoint)} → ${formatPoint(point)}`;
    drawOverlay();
  }

	  function onPreviewPointerUp(event) {
	    if (imageCropState?.active) {
	      const cropPoint = pointFromPreviewEvent(event, true);
	      onImageCropPointerUp(event, cropPoint);
	      return;
	    }
	    if (!recorderState || recorderState.pointerId !== event.pointerId) return;
    const point = pointFromPreviewEvent(event, true) || recorderState.lastPoint || recorderState.startPoint;
    const state = recorderState;
    recorderState = null;
    clearLongTimer(state);
    lastPreviewPoint = point;
    try {
      if (previewCanvas.hasPointerCapture?.(event.pointerId)) previewCanvas.releasePointerCapture(event.pointerId);
    } catch (_error) {}
    const elapsed = performance.now() - state.startTs;
    if (state.sentDown) {
      if (state.moved) sendLiveControl("gesture_move", point, state.gestureId, { reason: "workflow_live_final_move" });
      sendLiveControl("gesture_up", point, state.gestureId, { reason: "workflow_live_up" });
      if (state.moved) {
        maybeRecordSwipe(state.startPoint, point, { source: "live_pointer", gesture_id: state.gestureId });
      } else if (elapsed >= LiveLongPressMs || state.longStarted) {
        maybeRecordPoint("long_press", point, { hold_ms: Math.max(100, Math.round(elapsed)), source: "live_pointer", gesture_id: state.gestureId });
      } else {
        maybeRecordPoint("tap", point, { source: "live_pointer", gesture_id: state.gestureId });
      }
    } else {
      sendLiveControl("tap", point, state.gestureId, { reason: "workflow_live_tap" });
      maybeRecordPoint("tap", point, { source: "live_pointer", gesture_id: state.gestureId });
    }
    drawOverlay();
  }

	  function cancelRecorderPointer() {
	    if (imageCropState) {
	      cancelImageCrop();
	      return;
	    }
	    if (recorderState?.sentDown) {
      sendLiveControl("gesture_cancel", recorderState.lastPoint || recorderState.startPoint, recorderState.gestureId, { reason: "workflow_live_cancel" });
    }
    if (recorderState) clearLongTimer(recorderState);
    recorderState = null;
    drawOverlay();
  }

  function clearLongTimer(state) {
    if (state?.longTimer) {
      clearTimeout(state.longTimer);
      state.longTimer = null;
    }
  }

  function sendLiveControl(type, point, gestureId, extra = {}) {
    if (!primaryTarget?.canReceiveSync?.() || !point) return false;
    const payload = {
      type,
      phase: type,
      x: point.x,
      y: point.y,
      gesture_id: gestureId || crypto.randomUUID(),
      ...extra,
    };
    return integration.sendLiveControl?.(primaryTarget, payload) !== false;
  }

  function applyCoordinatePick(point) {
    const state = coordinatePickState;
    coordinatePickState = null;
    if (!state?.blockId || !point) return;
    const block = currentWorkflow.blocks.find((item) => item.id === state.blockId);
    if (!block) return;
    if (state.target === "image_search") {
      addImageSearchPoint(block, state.prefix || "image", point);
      byId("workflow-coordinate-readout").textContent = `picked search: ${formatPoint(point)}`;
      byId("workflow-status").textContent = `Đã thêm điểm tìm ảnh ${formatPoint(point)} cho ${block.id}`;
      return;
    }
    applyConditionalPoint(block, point);
    byId("workflow-coordinate-readout").textContent = `picked: ${formatPoint(point)}`;
    byId("workflow-status").textContent = `Đã chọn tọa độ ${formatPoint(point)} cho ${block.id}`;
  }

  function applyConditionalPoint(block, point) {
    if (!block || !point) return;
    if (block.type === "tap_image_state_pair") {
      block.params.second_x = Number(point.x);
      block.params.second_y = Number(point.y);
    } else {
      block.params.x = Number(point.x);
      block.params.y = Number(point.y);
    }
    markDirty();
    renderCanvas();
    renderProperties();
    integration.toast?.(`Đã set tọa độ nhấn ${Number(point.x).toFixed(3)},${Number(point.y).toFixed(3)}`, "success");
  }

  function shouldRecordAction() {
    return isRecording || !!recordReplaceBlockId;
  }

  function maybeRecordPoint(type, point, meta = {}) {
    if (!shouldRecordAction()) {
      byId("workflow-status").textContent = `Live ${type} · không ghi`;
      return;
    }
    recordPoint(type, point, meta);
  }

  function maybeRecordSwipe(from, to, meta = {}) {
    if (!shouldRecordAction()) {
      byId("workflow-status").textContent = "Live swipe · không ghi";
      return;
    }
    recordSwipe(from, to, meta);
  }

  function recordPoint(type, point, meta = {}) {
    if (!point) return;
    const params = type === "long_press"
      ? { x: point.x, y: point.y, hold_ms: meta.hold_ms || 800 }
      : { x: point.x, y: point.y };
    recordAction(type, params, meta);
  }

  function recordSwipe(from, to, meta = {}) {
    if (!from || !to) return;
    recordAction("swipe", { preset: meta.preset || "custom", from_x: from.x, from_y: from.y, to_x: to.x, to_y: to.y, duration_ms: meta.duration_ms || 300, steps: meta.steps || 10 }, meta);
  }

  function recordAction(type, params, meta = {}) {
    const metadata = { source_device_id: primaryTarget?.device?.id || "", recorded_at: nowIso(), recording: isRecording, ...meta };
    if (recordReplaceBlockId) {
      const block = currentWorkflow.blocks.find((item) => item.id === recordReplaceBlockId);
      if (block && block.type === type) {
        block.params = { ...block.params, ...params };
        block.authoring = metadata;
        selectedBlockId = block.id;
      } else {
        integration.toast?.("Block đang chọn không cùng loại thao tác, không thay thế", "error");
      }
      recordReplaceBlockId = "";
    } else {
      const block = global.HidWorkflowBlocks.createBlock(type, { params });
      block.authoring = metadata;
      insertBlock(block);
      byId("workflow-status").textContent = `Đã ghi bước ${currentWorkflow.blocks.length}: ${type}`;
      return;
    }
    markDirty();
    renderCanvas();
  }

  function updateSaveGate() {
    if (!modal || !currentWorkflow) return;
    const saveButton = byId("workflow-save");
    const gate = byId("workflow-save-gate");
    if (isRawLuaWorkflow()) {
      saveButton.disabled = false;
      gate.textContent = `Lua nhập trực tiếp · ${currentWorkflow.api_profile || "ioscontrol-v1"} · ${rawLuaLineCount()} dòng`;
      gate.className = "ok";
      return;
    }
    if (!currentWorkflow.blocks.length) {
      saveButton.disabled = false;
      gate.textContent = "Workflow trống";
      gate.className = "";
      return;
    }
    const tested = workflowTested();
    saveButton.disabled = false;
    gate.textContent = tested ? `Đã test OK · ${lastTestMetadata?.tested_primary_device_id || ""}` : "Chưa test · vẫn lưu được";
    gate.className = tested ? "ok" : "";
  }

  function saveCurrent() {
    try {
      currentWorkflow.name = byId("workflow-name").value || currentWorkflow.name;
      if (lastTestMetadata) currentWorkflow.test_metadata = { ...lastTestMetadata, tested_hash: currentHash() };
      const saved = global.HidWorkflowStorage.saveWorkflow(currentWorkflow);
      setWorkflow(saved);
      renderWorkflowList();
      integration.toast?.(`✓ Đã lưu ${isRawLuaWorkflow(saved) ? "Lua" : "kịch bản"}`, "success");
    } catch (error) {
      integration.toast?.(`✗ ${error.message}`, "error");
    }
  }

  function workflowListIcon(workflow) {
    const authoring = workflow?.authoring || {};
    if (typeof authoring.icon_data_url === "string" && authoring.icon_data_url.startsWith("data:image/")) return authoring.icon_data_url;
    if (Array.isArray(authoring.catalog_library)) {
      const firstWithIcon = authoring.catalog_library.find((entry) => typeof entry?.icon_data_url === "string" && entry.icon_data_url.startsWith("data:image/"));
      if (firstWithIcon) return firstWithIcon.icon_data_url;
    }
    return "";
  }

  function getSelectedSavedWorkflowIds() {
    return [...selectedSavedWorkflowIds];
  }

  function getSelectedSavedWorkflows() {
    return getSelectedSavedWorkflowIds()
      .map((id) => global.HidWorkflowStorage.getWorkflow(id))
      .filter(Boolean);
  }

  function notifySavedWorkflowSelectionChange(count = selectedSavedWorkflowIds.size) {
    integration?.onSavedWorkflowSelectionChange?.({
      count,
      ids: getSelectedSavedWorkflowIds(),
      workflows: getSelectedSavedWorkflows(),
    });
  }

  function updateSavedWorkflowSelectionUI(list = global.HidWorkflowStorage.listWorkflows()) {
    const existingIds = new Set(list.map((workflow) => workflow.id));
    selectedSavedWorkflowIds = new Set([...selectedSavedWorkflowIds].filter((id) => existingIds.has(id)));
    const count = selectedSavedWorkflowIds.size;
    const deleteButton = byId("workflow-delete-selected");
    const selectAll = byId("workflow-select-all");
    if (deleteButton) {
      deleteButton.disabled = count === 0;
      deleteButton.textContent = count ? `Xoá ${count} kịch bản đã chọn` : "Xoá kịch bản đã chọn";
    }
    if (selectAll) {
      selectAll.checked = !!list.length && count === list.length;
      selectAll.indeterminate = count > 0 && count < list.length;
    }
    notifySavedWorkflowSelectionChange(count);
  }

  function toggleSelectAllSavedWorkflows(event) {
    const list = global.HidWorkflowStorage.listWorkflows();
    selectedSavedWorkflowIds = event.target.checked ? new Set(list.map((workflow) => workflow.id)) : new Set();
    renderWorkflowList();
  }

  function deleteSelectedSavedWorkflows() {
    const ids = [...selectedSavedWorkflowIds];
    if (!ids.length) return;
    const label = ids.length === 1 ? "1 kịch bản" : `${ids.length} kịch bản`;
    if (!confirm(`Xoá ${label} đã chọn khỏi danh sách web?`)) return;
    ids.forEach((id) => global.HidWorkflowStorage.deleteWorkflow(id));
    const deletedCurrent = currentWorkflow && ids.includes(currentWorkflow.id);
    selectedSavedWorkflowIds = new Set();
    if (deletedCurrent) {
      setWorkflow(global.HidWorkflowBlocks.createWorkflow("Workflow mới"), { resetTest: true });
    } else {
      renderWorkflowList();
    }
    integration.toast?.(`Đã xoá ${label} đã chọn`, "success");
  }

  function renderWorkflowList() {
    const list = global.HidWorkflowStorage.listWorkflows();
    updateSavedWorkflowSelectionUI(list);
    byId("workflow-list").innerHTML = list.map((workflow) => {
      const isLua = isRawLuaWorkflow(workflow);
      const meta = isLua
        ? `Lua · ${workflow.api_profile || "ioscontrol-v1"}${workflow.test_metadata?.tested_hash ? " · tested" : ""}`
        : `${workflow.blocks?.length || 0} blocks${workflow.test_metadata?.tested_hash ? " · tested" : ""}`;
      return `
      <div class="workflow-list-item ${selectedSavedWorkflowIds.has(workflow.id) ? "selected" : ""}">
        <label class="workflow-list-check" title="Chọn kịch bản để xoá hoặc gửi vào máy">
          <input type="checkbox" data-select-workflow="${escapeHtml(workflow.id)}" ${selectedSavedWorkflowIds.has(workflow.id) ? "checked" : ""}>
        </label>
        <button class="workflow-list-load" data-load-workflow="${escapeHtml(workflow.id)}" type="button">
        ${workflowListIcon(workflow)
          ? `<span class="workflow-list-icon-wrap"><img class="workflow-list-icon" src="${escapeHtml(workflowListIcon(workflow))}" alt=""></span>`
          : `<span class="workflow-list-icon-fallback">📄</span>`
        }
        <span class="workflow-list-item-body">
          <strong>${escapeHtml(workflow.name)}</strong>
          <small>${escapeHtml(meta)}</small>
        </span>
        </button>
      </div>`;
    }).join("") || "<p class=\"workflow-status\">Chưa có workflow đã lưu</p>";
    byId("workflow-list").querySelectorAll("[data-select-workflow]").forEach((input) => {
      input.addEventListener("change", () => {
        if (input.checked) selectedSavedWorkflowIds.add(input.dataset.selectWorkflow);
        else selectedSavedWorkflowIds.delete(input.dataset.selectWorkflow);
        updateSavedWorkflowSelectionUI(list);
        input.closest(".workflow-list-item")?.classList.toggle("selected", input.checked);
      });
    });
    byId("workflow-list").querySelectorAll("[data-load-workflow]").forEach((button) => {
      button.addEventListener("click", () => {
        const workflow = global.HidWorkflowStorage.getWorkflow(button.dataset.loadWorkflow);
        if (workflow) setWorkflow(workflow);
      });
    });
  }

  function renderHistory() {
    const history = byId("workflow-history");
    if (!history) return;
    history.innerHTML = global.HidWorkflowStorage.listHistory().slice(0, 10).map((entry) => `
      <div class="workflow-history-row">
        <strong>${escapeHtml(entry.workflow_name)}</strong>
        <span>${escapeHtml(entry.result)} · ${Math.round((entry.duration_ms || 0) / 1000)}s · ${(entry.devices || []).length} máy</span>
      </div>`).join("") || "<p class=\"workflow-status\">Chưa có run history</p>";
  }

  function pointForQuickAction() {
    return lastPreviewPoint || { x: 0.5, y: 0.5 };
  }

  function swipeParamsForPreset(preset) {
    const points = global.HidWorkflowBlocks.swipePoints({ preset });
    return {
      preset,
      from_x: points.from.x,
      from_y: points.from.y,
      to_x: points.to.x,
      to_y: points.to.y,
      duration_ms: points.duration_ms || 300,
      steps: points.steps || 10,
    };
  }

  function commandForRecordedAction(type, params) {
    const block = global.HidWorkflowBlocks.createBlock(type, { params });
    return global.HidWorkflowBlocks.commandFromBlock(block);
  }

  function recordQuickBlock(type, params, actionType) {
    if (!shouldRecordAction()) {
      byId("workflow-status").textContent = `Quick ${actionType} · không ghi`;
      return;
    }
    recordAction(type, params, { source: "quick_button", action: actionType });
  }

  async function runQuickAction(actionType, button = null) {
    refreshTargets();
    if (!primaryTarget?.canReceiveSync?.()) {
      integration.toast?.("Chưa chọn máy live/connected", "error");
      return;
    }
    const point = pointForQuickAction();
    let blockType = "";
    let params = {};
    let command = null;
    if (actionType === "home") {
      blockType = "hardware_home";
      params = { reason: "workflow_quick_home" };
      command = commandForRecordedAction(blockType, params);
    } else if (actionType === "tap") {
      blockType = "tap";
      params = { x: point.x, y: point.y };
      command = commandForRecordedAction(blockType, params);
    } else if (actionType === "long") {
      blockType = "long_press";
      params = { x: point.x, y: point.y, hold_ms: 800 };
      command = commandForRecordedAction(blockType, params);
    } else if (actionType === "screenshot") {
      blockType = "screenshot";
      params = { save_as: `shot_${currentWorkflow.blocks.length + 1}` };
    } else if (actionType.startsWith("swipe_")) {
      blockType = "swipe";
      params = swipeParamsForPreset(actionType.replace("swipe_", ""));
      command = commandForRecordedAction(blockType, params);
    }
    if (!blockType) return;
    button?.classList.add("busy");
    button?.setAttribute("disabled", "disabled");
    try {
      if (actionType === "screenshot") {
        integration.captureScreenshot?.(primaryTarget, params.save_as);
      } else if (command) {
        const ack = await integration.sendWorkflowCommand?.(primaryTarget, command);
        if (ack?.ok === false) throw new Error(ack.reason || (ack.timeout ? "ack_timeout" : "ack_failed"));
      }
      recordQuickBlock(blockType, params, actionType);
      byId("workflow-status").textContent = `${isRecording ? "Đã ghi" : "Đã chạy"} quick ${actionType}`;
    } catch (error) {
      integration.toast?.(`Quick ${actionType} lỗi: ${error.message || error}`, "error");
    } finally {
      button?.classList.remove("busy");
      button?.removeAttribute("disabled");
    }
  }

  function previewOnly() {
    refreshTargets();
    drawOverlay();
    byId("workflow-status").textContent = isRawLuaWorkflow()
      ? `Preview Lua · ${rawLuaLineCount()} dòng`
      : `Preview only · ${currentWorkflow.blocks.length} blocks`;
  }

  function hasTargetDeviceId(target) {
    return !!String(target?.device?.id || target?.device_id || target?.id || "").trim();
  }

  function blockNeedsLiveChannel(block) {
    if (!block) return false;
    if (block.type === "loop") return (block.body || []).some(blockNeedsLiveChannel);
    if (block.type === "if_else") {
      return (block.then || []).some(blockNeedsLiveChannel) || (block.else || []).some(blockNeedsLiveChannel);
    }
    if (block.type === "open_app") return false;
    if (global.HidWorkflowBlocks.isScriptOnlyBlock?.(block.type)) return false;
    return !["wait", "set_variable", "notify"].includes(block.type);
  }

  function workflowNeedsLiveChannel(workflow) {
    return (workflow?.blocks || []).some(blockNeedsLiveChannel);
  }

  function runnableTargetsForWorkflow(workflow, targets) {
    const list = targets || [];
    if (workflowNeedsLiveChannel(workflow)) return list.filter((target) => target?.canReceiveSync?.());
    return list.filter(hasTargetDeviceId);
  }

  async function testSelectedBlock() {
    if (isRawLuaWorkflow()) {
      integration.toast?.("Lua nhập trực tiếp không có block riêng; dùng Chạy trên iPhone để test thật", "info");
      return;
    }
    const block = selectedBlock();
    if (!block) {
      integration.toast?.("Chưa chọn block để test", "error");
      return;
    }
    refreshTargets();
    const temp = global.HidWorkflowBlocks.createWorkflow(`Test ${block.id}`);
    const ordered = global.HidWorkflowBlocks.orderedBlocks(currentWorkflow);
    const orderedIndex = ordered.findIndex((item) => item.id === block.id);
    const range = global.HidWorkflowBlocks.loopRepeatRange?.(block, orderedIndex, ordered);
    const cloneBlock = (item) => JSON.parse(JSON.stringify(item));
    if (block.type === "loop" && range) {
      temp.blocks = [...range.blocks.map(cloneBlock), cloneBlock(block)];
      const tempLoop = temp.blocks[temp.blocks.length - 1];
      tempLoop.params = { ...(tempLoop.params || {}), repeat_from_step: 1, repeat_to_step: 0 };
      temp.connections = temp.blocks.slice(0, -1).map((item, index) => ({ from: item.id, to: temp.blocks[index + 1].id, port: "next" }));
    } else {
      temp.blocks = [cloneBlock(block)];
      temp.connections = [];
    }
    temp.assets = assetsForBlocks(temp.blocks);
    const needsLiveChannel = workflowNeedsLiveChannel(temp);
    if (needsLiveChannel && !primaryTarget?.canReceiveSync?.()) {
      integration.toast?.("Chưa có máy live/connected để test block", "error");
      return;
    }
    if (!needsLiveChannel && !hasTargetDeviceId(primaryTarget)) {
      integration.toast?.("Chưa chọn máy để gửi Lua test", "error");
      return;
    }
    await runWorkflow(temp, [primaryTarget], { markTested: false, label: "Test selected block" });
  }

  async function testWorkflow() {
    if (isRawLuaWorkflow()) {
      await runCurrentOnDevice();
      return { status: "submitted", raw_lua: true };
    }
    refreshTargets();
    const targets = integration.getWorkflowTargets?.() || [];
    if (workflowNeedsLiveChannel(currentWorkflow) && !primaryTarget?.canReceiveSync?.()) {
      integration.toast?.("Chưa chọn máy live/connected để test workflow", "error");
      return { status: "failed", error: "missing_primary_target" };
    }
    if (!workflowNeedsLiveChannel(currentWorkflow) && !hasTargetDeviceId(primaryTarget)) {
      integration.toast?.("Chưa chọn máy để gửi Lua workflow", "error");
      return { status: "failed", error: "missing_primary_target" };
    }
    if (targets.length > 1) {
      integration.toast?.(`Workflow tạo theo màn hình ${primaryTarget?.device?.id || "primary"}; chỉ chạy nhiều máy nếu màn hình giống nhau`, "info");
    }
    const snapshot = await runWorkflow(currentWorkflow, targets, { markTested: true, label: "Test workflow" });
    return snapshot;
  }

  async function runWorkflow(workflow, targets, options = {}) {
    try {
      global.HidWorkflowBlocks.validateWorkflow(workflow);
      const readyTargets = runnableTargetsForWorkflow(workflow, targets);
      if (!readyTargets.length) {
        throw new Error(workflowNeedsLiveChannel(workflow)
          ? "Chưa có target connected/DC open để chạy workflow"
          : "Chưa có target để gửi Lua workflow qua REST");
      }
      runner = new global.HidWorkflowRunner.WorkflowRunner({
        sendCommand: integration.sendWorkflowCommand,
        runOpenApp: runOpenAppLive,
        runLuaBlock: runLuaBlockLive,
        captureScreenshot: integration.captureScreenshot,
        toast: integration.toast,
        onStatus: updateRunStatus,
        onBlockStart: (block) => { selectedBlockId = block.id; renderCanvas(); },
        onBlockDone: () => renderCanvas(),
      });
      byId("workflow-status").textContent = `${options.label || "Run"}...`;
      const snapshot = await runner.run(workflow, readyTargets);
      if (snapshot.status !== "done") throw new Error(`Workflow status=${snapshot.status}`);
      if (options.markTested) {
        lastSuccessfulTestHash = currentHash();
        lastTestMetadata = {
          tested_at: nowIso(),
          tested_hash: lastSuccessfulTestHash,
          tested_primary_device_id: primaryTarget?.device?.id || readyTargets[0]?.device?.id || "",
          tested_target_count: readyTargets.length,
          result: "PASS",
          per_device: readyTargets.map((target) => ({ device_id: target.device?.id || "", result: "PASS" })),
        };
        currentWorkflow.test_metadata = { ...lastTestMetadata };
        updateSaveGate();
      }
      renderHistory();
      integration.toast?.(`${options.label || "Workflow"} PASS`, "success");
      return snapshot;
    } catch (error) {
      if (options.markTested) {
        lastSuccessfulTestHash = "";
        lastTestMetadata = null;
        currentWorkflow.test_metadata = null;
        updateSaveGate();
      }
      integration.toast?.(`${options.label || "Workflow"} lỗi: ${error.message || error}`, "error");
      updateRunStatus({ status: "failed", log: [{ message: error.message || String(error) }] });
      return { status: "failed", error };
    }
  }

  async function runOpenAppLive(block, targets) {
    if (!global.HidWorkflowScriptExport?.exportWorkflowPackage) throw new Error("Thiếu module workflow_export_lua.js");
    if (typeof integration.pushWorkflowScript !== "function" || typeof integration.runOnDeviceScript !== "function") {
      throw new Error("Thiếu API gửi/chạy script để test Mở ứng dụng live");
    }
    const readyTargets = (targets || []).filter(hasTargetDeviceId);
    if (!readyTargets.length) throw new Error("Chưa có target để gửi Lua Mở ứng dụng");
    const params = { ...(block.params || {}) };
    const target = String(params.bundle_id || params.url_scheme || "").trim();
    if (!target) throw new Error(`${block.id}: chọn ứng dụng hoặc nhập bundle_id`);
    const temp = global.HidWorkflowBlocks.createWorkflow(`Live mở ${params.app_name || target}`);
    temp.blocks = [global.HidWorkflowBlocks.createBlock("open_app", {
      id: block.id,
      params,
    })];
    temp.connections = [];
    const targetDeviceIds = readyTargets.map((item) => item?.device?.id || "").filter(Boolean);
	    const packagePayload = await global.HidWorkflowScriptExport.exportWorkflowPackage(temp, {
	      targetDeviceIds,
	      scriptId: `live-open-app-${Date.now()}`,
	    });
    rememberRunningScript(packagePayload, readyTargets);
	    await integration.pushWorkflowScript(temp, readyTargets, { packagePayload });
	    return integration.runOnDeviceScript(temp, readyTargets, {
	      packagePayload,
      runId: `live-open-app-${Date.now()}`,
    });
  }

  async function runLuaBlockLive(block, targets, options = {}) {
    if (!global.HidWorkflowScriptExport?.exportWorkflowPackage) throw new Error("Thiếu module workflow_export_lua.js");
    if (typeof integration.pushWorkflowScript !== "function" || typeof integration.runOnDeviceScript !== "function") {
      throw new Error("Thiếu API gửi/chạy script để test block Lua live");
    }
	    const readyTargets = (targets || []).filter(hasTargetDeviceId);
	    if (!readyTargets.length) throw new Error("Chưa có target để gửi Lua test block");
	    const temp = global.HidWorkflowBlocks.createWorkflow(`Live ${block.type}`);
	    temp.api_profile = "ioscontrol-v1";
	    temp.blocks = [global.HidWorkflowBlocks.createBlock(block.type, {
	      id: block.id,
	      params: { ...(block.params || {}) },
	    })];
	    temp.assets = assetsForBlocks(temp.blocks);
	    temp.connections = [];
    const targetDeviceIds = readyTargets.map((item) => item?.device?.id || "").filter(Boolean);
	    const packagePayload = await global.HidWorkflowScriptExport.exportWorkflowPackage(temp, {
	      targetDeviceIds,
	      scriptId: `live-${block.type}-${Date.now()}`,
	    });
    rememberRunningScript(packagePayload, readyTargets);
	    await integration.pushWorkflowScript(temp, readyTargets, { packagePayload });
	    return integration.runOnDeviceScript(temp, readyTargets, {
	      packagePayload,
      runId: `live-${block.type}-${Date.now()}`,
      onScriptEvent: options.onScriptEvent,
    });
  }

  function meaningfulRunMessage(log = []) {
    const entries = Array.isArray(log) ? log : [];
    for (let index = entries.length - 1; index >= 0; index -= 1) {
      const message = String(entries[index]?.message || "").trim();
      if (!message) continue;
      if (/^(done(?:\s|:)|script_done\b)/i.test(message)) continue;
      return message;
    }
    return String(entries.slice(-1)[0]?.message || "").trim();
  }

  function updateRunStatus(snapshot) {
    const lastMessage = meaningfulRunMessage(snapshot.log);
    const translated = lastMessage ? vietnameseLogEntry({ message: lastMessage }).message : "";
    const suffix = translated ? ` · ${translated.slice(0, 120)}` : "";
    byId("workflow-status").textContent = `${snapshot.status || "idle"} · block=${snapshot.currentBlockId || "-"} · log=${snapshot.log?.length || 0}${suffix}`;
    renderRunLog(snapshot);
    drawOverlay();
  }

  function shortImageName(value) {
    const text = String(value || "").trim();
    if (!text) return "";
    const first = text.split(/[|>]/)[0] || text;
    return first.split(/[\\/]/).pop();
  }

  function formatScore(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return "";
    const percent = number <= 1 ? number * 100 : number;
    return `${percent.toFixed(percent >= 99.95 ? 1 : 1)}%`;
  }

  function formatLogCoord(x, y) {
    const nx = Number(x);
    const ny = Number(y);
    if (!Number.isFinite(nx) || !Number.isFinite(ny)) return "";
    return `X=${nx.toFixed(4)}, Y=${ny.toFixed(4)}`;
  }

  function keyValuesFromText(text) {
    const values = {};
    String(text || "").replace(/(?:^|:|\s)([a-zA-Z_][\w]*)=([^:\s]+)/g, (_match, key, value) => {
      values[key] = value;
      return "";
    });
    return values;
  }

  function translateDiagnostic(value) {
    const text = String(value || "").trim();
    const map = {
      vision_image_miss: "Không khớp ảnh",
      no_match: "Không có vùng ảnh đủ giống",
      strict_threshold: "Bị loại do ngưỡng khớp nghiêm ngặt",
      pixel_template: "Khớp theo pixel",
      feature_template: "Khớp theo đặc trưng ảnh",
      no_clear_winner: "Ảnh dễ nhầm, không có kết quả thắng rõ",
    };
    return map[text] || text;
  }

  function vietnameseLogEntry(entry = {}) {
    const raw = String(entry.message || "").trim();
    const kv = keyValuesFromText(raw);
    const out = {
      block: entry.block_id || "",
      level: entry.level || "",
      message: raw || "—",
      image: "",
      score: "",
      coord: "",
      reason: "",
      raw,
    };
    const scriptMessage = raw.replace(/^[^:]+:\s+script_log\s+/, "").replace(/^lua_reportStep\s+/, "");

    if (/^start\s+/.test(raw)) out.message = `Bắt đầu bước ${raw.replace(/^start\s+/, "")}`;
    if (/^done\s+/.test(raw)) out.message = `Hoàn tất bước ${raw.replace(/^done\s+/, "")}`;
    if (/live_lua_block\s+/.test(raw)) out.message = "Đã chạy xong block Lua trên iPhone";
    if (raw.includes("block_error_continue:")) {
      const reason = raw.split("block_error_continue:")[1] || "";
      out.message = "Block lỗi nhưng đã bỏ qua để chạy block tiếp theo";
      out.reason = reason;
    }

    if (scriptMessage.includes("conditional_image_probe_start:")) {
      const body = scriptMessage.split("conditional_image_probe_start:")[1] || "";
      out.image = shortImageName(body.split(":count=")[0].split(":mode=")[0]);
      out.message = `Bắt đầu tìm ảnh điều kiện A${out.image ? `: ${out.image}` : ""}`;
      out.reason = kv.timeout_ms ? `Chờ tối đa ${kv.timeout_ms}ms` : "";
    } else if (scriptMessage.includes("conditional_image_probe_hit:")) {
      const body = scriptMessage.split("conditional_image_probe_hit:")[1] || "";
      out.image = shortImageName(body.split(":x=")[0]);
      out.score = formatScore(kv.score || kv.confidence || kv.similarity);
      out.coord = formatLogCoord(kv.norm_x || kv.x, kv.norm_y || kv.y);
      out.message = `Đã thấy ảnh điều kiện A${out.score ? `, khớp ${out.score}` : ""}${out.coord ? ` tại ${out.coord}` : ""}`;
      out.reason = translateDiagnostic(kv.reason || kv.diagnostic);
    } else if (scriptMessage.includes("conditional_image_probe_miss:")) {
      out.image = shortImageName(scriptMessage.split("conditional_image_probe_miss:")[1] || "");
      out.message = `Không tìm thấy ảnh điều kiện A${out.image ? `: ${out.image}` : ""}`;
      out.reason = "Bỏ qua bước nhấn vì chưa thấy A";
    } else if (scriptMessage.includes("conditional_image_not_seen_skip:")) {
      out.image = shortImageName(scriptMessage.split("conditional_image_not_seen_skip:")[1] || "");
      out.message = `Không thấy ảnh điều kiện A${out.image ? `: ${out.image}` : ""}, nên bỏ qua`;
    } else if (scriptMessage.includes("conditional_image_anchor_mismatch:")) {
      const body = scriptMessage.split("conditional_image_anchor_mismatch:")[1] || "";
      out.image = shortImageName(body.split(":x=")[0]);
      out.coord = formatLogCoord(kv.x, kv.y);
      out.message = `Ảnh điều kiện A match sai vùng${out.coord ? ` tại ${out.coord}` : ""}`;
      out.reason = kv.anchor ? `Anchor đúng phải gần ${kv.anchor}` : "Sai anchor";
    } else if (scriptMessage.includes("conditional_image_seen:")) {
      const body = scriptMessage.split("conditional_image_seen:")[1] || "";
      out.image = shortImageName(body.split(":x=")[0]);
      out.coord = formatLogCoord(kv.norm_x || kv.x, kv.norm_y || kv.y);
      out.message = `Xác nhận đã thấy ảnh điều kiện A${out.coord ? ` tại ${out.coord}` : ""}`;
    } else if (scriptMessage.includes("conditional_target_probe_start:")) {
      const body = scriptMessage.split("conditional_target_probe_start:")[1] || "";
      const target = body.includes("->") ? body.split("->")[1] : body;
      out.image = shortImageName(target.split(":threshold=")[0]);
      out.message = `Bắt đầu tìm ảnh cần nhấn B${out.image ? `: ${out.image}` : ""}`;
      out.reason = kv.threshold ? `Ngưỡng khớp ${formatScore(kv.threshold)}` : "";
    } else if (scriptMessage.includes("conditional_target_probe_hit:")) {
      const body = scriptMessage.split("conditional_target_probe_hit:")[1] || "";
      out.image = shortImageName(body.split(":x=")[0]);
      out.score = formatScore(kv.score || kv.confidence || kv.similarity);
      out.coord = formatLogCoord(kv.norm_x || kv.x, kv.norm_y || kv.y);
      out.message = `Đã thấy ảnh cần nhấn B${out.score ? `, khớp ${out.score}` : ""}${out.coord ? ` tại ${out.coord}` : ""}`;
      out.reason = translateDiagnostic(kv.reason || kv.diagnostic);
    } else if (scriptMessage.includes("conditional_target_probe_miss:")) {
      out.image = shortImageName(scriptMessage.split("conditional_target_probe_miss:")[1] || "");
      out.message = `Không tìm thấy ảnh cần nhấn B${out.image ? `: ${out.image}` : ""}`;
    } else if (scriptMessage.includes("conditional_target_tap_method:")) {
      const body = scriptMessage.split("conditional_target_tap_method:")[1] || "";
      out.image = shortImageName(body.split(":method=")[0]);
      out.coord = formatLogCoord(kv.pre_norm_x || kv.pre_x, kv.pre_norm_y || kv.pre_y);
      out.message = `Chuẩn bị nhấn ảnh B${out.coord ? ` tại ${out.coord}` : ""}`;
      out.reason = kv.method === "pre_match_coordinate" ? "Dùng đúng tọa độ ảnh B vừa match, không tìm lại lần hai" : kv.method || "";
    } else if (scriptMessage.includes("conditional_image_target_tap:")) {
      const body = scriptMessage.split("conditional_image_target_tap:")[1] || "";
      out.image = shortImageName(body.includes("->") ? body.split("->")[1].split(":ok=")[0] : body);
      out.coord = formatLogCoord(kv.x || kv.pre_x, kv.y || kv.pre_y);
      out.message = `${kv.ok === "true" ? "Đã gửi lệnh nhấn ảnh B" : "Nhấn ảnh B thất bại"}${out.coord ? ` tại ${out.coord}` : ""}`;
      out.reason = "ok=true chỉ là đã gửi lệnh tap, không tự chứng minh màn hình đổi";
    } else if (scriptMessage.includes("conditional_action_mode:")) {
      out.coord = formatLogCoord(kv.x, kv.y);
      out.message = `Chế độ nhấn tọa độ${out.coord ? `: sẽ nhấn ${out.coord}` : ""}`;
    } else if (scriptMessage.includes("conditional_coord_tap:")) {
      out.coord = formatLogCoord(kv.x, kv.y);
      out.message = `${kv.ok === "true" ? "Đã gửi lệnh nhấn tọa độ" : "Nhấn tọa độ thất bại"}${out.coord ? ` ${out.coord}` : ""}`;
      out.reason = "ok=true chỉ là lệnh tap đã gửi tới iPhone";
    } else if (scriptMessage.includes("lua_find_image")) {
      out.image = shortImageName(kv.path);
      out.score = formatScore(kv.score);
      out.coord = formatLogCoord(kv.norm_x || kv.x, kv.norm_y || kv.y);
      out.message = kv.found === "1"
        ? `Ảnh khớp${out.score ? ` ${out.score}` : ""}${out.coord ? ` tại ${out.coord}` : ""}`
        : `Không tìm được ảnh${out.image ? `: ${out.image}` : ""}`;
      out.reason = translateDiagnostic(kv.diagnostic || kv.reason);
    } else if (scriptMessage.includes("conditional_target_image_timeout:")) {
      out.image = shortImageName(scriptMessage.split("conditional_target_image_timeout:")[1] || "");
      out.message = `Quá thời gian: không tìm thấy ảnh cần nhấn B${out.image ? `: ${out.image}` : ""}`;
    } else if (scriptMessage.includes("conditional_image_missing")) {
      out.message = "Thiếu ảnh điều kiện A trong gói kịch bản";
    } else if (scriptMessage.includes("conditional_target_image_tap_failed:")) {
      out.image = shortImageName(scriptMessage.split("conditional_target_image_tap_failed:")[1] || "");
      out.message = `Không nhấn được ảnh B${out.image ? `: ${out.image}` : ""}`;
    }
    return out;
  }

  function renderRunLog(snapshot = {}) {
    const container = byId("workflow-run-log");
    if (!container) return;
    const log = Array.isArray(snapshot.log) ? snapshot.log : [];
    if (!log.length) {
      container.innerHTML = "<p class=\"workflow-status\">Chưa có log debug</p>";
      return;
    }
    const rows = log.slice(-80).map((entry, index) => {
      const item = vietnameseLogEntry(entry);
      const level = item.level === "error" ? "Lỗi" : item.level === "success" ? "OK" : "Info";
      return `<tr class="${item.level === "error" ? "error" : item.level === "success" ? "success" : ""}">
        <td>${index + 1}</td>
        <td>${escapeHtml(level)}</td>
        <td>${escapeHtml(item.block || "-")}</td>
        <td>${escapeHtml(item.message)}</td>
        <td>${escapeHtml(item.image || "-")}</td>
        <td>${escapeHtml(item.score || "-")}</td>
        <td>${escapeHtml(item.coord || "-")}</td>
        <td title="${escapeHtml(item.raw)}">${escapeHtml(item.reason || "-")}</td>
      </tr>`;
    }).join("");
    container.innerHTML = `<table class="workflow-debug-table">
      <thead><tr><th>#</th><th>Mức</th><th>Block</th><th>Nội dung</th><th>Ảnh</th><th>Khớp</th><th>Tọa độ</th><th>Lý do</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  }

  async function copyRunLog() {
    const log = runner?.snapshot?.().log || [];
    const lines = log.map((entry, index) => {
      const item = vietnameseLogEntry(entry);
      return [
        index + 1,
        item.level || "",
        item.block || "",
        item.message || "",
        item.image || "",
        item.score || "",
        item.coord || "",
        item.reason || "",
        item.raw || "",
      ].join("\t");
    });
    const text = ["#\tMức\tBlock\tNội dung\tẢnh\tKhớp\tTọa độ\tLý do\tRaw", ...lines].join("\n");
    await navigator.clipboard?.writeText(text);
    integration.toast?.("Đã copy log debug", "success");
  }

  function exportCurrent() {
    try {
      const safeName = (currentWorkflow.name || "workflow").replace(/[^\w.-]+/g, "_");
      global.HidWorkflowStorage.exportJson(`${safeName}_${new Date().toISOString().replace(/[:.]/g, "-")}.json`, currentWorkflow);
    } catch (error) {
      integration.toast?.(`Export lỗi: ${error.message}`, "error");
    }
  }

  function currentLuaText() {
    if (isRawLuaWorkflow()) return String(currentWorkflow.raw_lua || "");
    if (!currentWorkflow?.blocks?.length) throw new Error("Workflow trống, chưa có bước để sinh Lua");
    if (!global.HidWorkflowScriptExport?.workflowToLua) throw new Error("Thiếu module workflow_export_lua.js");
    return global.HidWorkflowScriptExport.workflowToLua(currentWorkflow, { apiProfile: preferredApiProfile(currentWorkflow) });
  }

  function safeLuaFileName() {
    const rawFile = String(currentWorkflow?.raw_lua_filename || "").trim().split(/[\\/]/).pop();
    if (rawFile && /\.lua$/i.test(rawFile)) return rawFile;
    return `${(currentWorkflow?.name || "workflow").replace(/[^\w.-]+/g, "_") || "workflow"}.lua`;
  }

  function luaEditorText() {
    return String(byId("workflow-lua-output")?.value || "").replace(/\r\n/g, "\n");
  }

  function luaEditorProfile() {
    return String(byId("workflow-lua-api-profile")?.value || currentWorkflow?.api_profile || "ioscontrol-v1").trim() || "ioscontrol-v1";
  }

  function updateLuaEditorSummary() {
    const output = byId("workflow-lua-output");
    const summary = byId("workflow-lua-summary");
    if (!output || !summary) return;
    const lines = output.value.trim() ? output.value.replace(/\r\n/g, "\n").split("\n").length : 0;
    const modeText = luaEditorSourceMode === "raw"
      ? "Lua nhập trực tiếp"
      : "Lua sinh từ block; sửa trong ô chưa đổi block cho tới khi bấm Dùng Lua này làm kịch bản";
    summary.textContent = `${modeText} · ${luaEditorProfile()} · ${lines} dòng · Chạy Lua trong ô sẽ gửi đúng nội dung đang thấy vào iPhone`;
  }

  function onLuaEditorInput() {
    if (isRawLuaWorkflow() && luaEditorSourceMode === "raw") {
      currentWorkflow.raw_lua = luaEditorText();
      currentWorkflow.updated_at = nowIso();
      currentWorkflow.test_metadata = null;
      lastSuccessfulTestHash = "";
      lastTestMetadata = null;
      renderCanvas();
      updateSaveGate();
    }
    updateLuaEditorSummary();
  }

  function onLuaProfileInput() {
    if (isRawLuaWorkflow() && luaEditorSourceMode === "raw") {
      currentWorkflow.api_profile = luaEditorProfile();
      currentWorkflow.updated_at = nowIso();
      renderCanvas();
      updateSaveGate();
    }
    updateLuaEditorSummary();
  }

  function workflowFromLuaText(lua, options = {}) {
    const name = String(options.name || byId("workflow-name")?.value || currentWorkflow?.name || "Lua trực tiếp").trim() || "Lua trực tiếp";
    const workflow = global.HidWorkflowBlocks.createWorkflow(name);
    workflow.id = options.id || currentWorkflow?.id || workflow.id;
    workflow.created_at = currentWorkflow?.created_at || workflow.created_at;
    workflow.updated_at = nowIso();
    workflow.description = options.description || currentWorkflow?.description || "Lua viết/chỉnh trực tiếp trong web";
    workflow.raw_lua = lua;
    workflow.raw_lua_filename = options.filename || safeLuaFileName();
    workflow.api_profile = options.apiProfile || luaEditorProfile();
    workflow.assets = Array.isArray(currentWorkflow?.assets) ? currentWorkflow.assets : [];
    workflow.blocks = [];
    workflow.connections = [];
    workflow.test_metadata = null;
    return global.HidWorkflowBlocks.normalizeWorkflow(workflow);
  }

  function applyLuaEditorToCurrent(options = {}) {
    const lua = luaEditorText();
    if (!lua.trim()) throw new Error("Lua trống, chưa có nội dung để áp dụng");
    currentWorkflow = workflowFromLuaText(lua, {
      id: currentWorkflow?.id,
      name: byId("workflow-name")?.value || currentWorkflow?.name || "Lua trực tiếp",
      filename: safeLuaFileName(),
      apiProfile: luaEditorProfile(),
    });
    luaEditorSourceMode = "raw";
    lastSuccessfulTestHash = "";
    lastTestMetadata = null;
    selectedBlockId = "";
    renderCanvas();
    byId("workflow-name").value = currentWorkflow.name;
    updateSaveGate();
    updateLuaEditorSummary();
    byId("workflow-status").textContent = `Đã dùng nội dung Lua trong ô làm kịch bản · ${rawLuaLineCount()} dòng`;
    integration.toast?.("Đã áp dụng Lua vào kịch bản hiện tại", "success");
    if (options.closeAfterApply) closeLua();
    return currentWorkflow;
  }

  function saveLuaEditorAsWorkflow() {
    try {
      applyLuaEditorToCurrent({ closeAfterApply: false });
      saveCurrent();
      renderWorkflowList();
    } catch (error) {
      integration.toast?.(`Lưu Lua lỗi: ${error.message || error}`, "error");
    }
  }

  async function runLuaEditorOnDevice() {
    try {
      const lua = luaEditorText();
      if (!lua.trim()) throw new Error("Lua trống, chưa có nội dung để chạy");
      const targets = scriptTargets();
      if (!targets.length) throw new Error("Chưa chọn máy để chạy Lua");
      if (!global.HidWorkflowScriptExport?.exportWorkflowPackage) throw new Error("Thiếu module workflow_export_lua.js");
      const tempWorkflow = workflowFromLuaText(lua, {
        id: `lua-editor-${Date.now()}`,
        name: byId("workflow-name")?.value || currentWorkflow?.name || "Lua chạy trực tiếp",
        filename: safeLuaFileName(),
        apiProfile: luaEditorProfile(),
        description: "Lua chạy trực tiếp từ ô editor, không cần lưu trước",
      });
      const targetDeviceIds = targets.map((target) => target?.device?.id || "").filter(Boolean);
      const packagePayload = await global.HidWorkflowScriptExport.exportWorkflowPackage(tempWorkflow, {
        targetDeviceIds,
        apiProfile: tempWorkflow.api_profile,
        scriptId: `lua-editor-${Date.now()}`,
      });
      rememberRunningScript(packagePayload, targets);
      byId("workflow-status").textContent = `Đang gửi + chạy Lua trong ô trên ${targets.length} máy...`;
      await integration.pushWorkflowScript?.(tempWorkflow, targets, { packagePayload });
      const result = await integration.runOnDeviceScript?.(tempWorkflow, targets, {
        packagePayload,
        runId: `lua-editor-${Date.now()}`,
      });
      byId("workflow-status").textContent = `Đã phát lệnh chạy Lua trong ô trên ${result?.length || targets.length} máy`;
      integration.toast?.("✓ Đã chạy Lua trong ô trên iPhone", "success");
    } catch (error) {
      byId("workflow-status").textContent = `Chạy Lua trong ô lỗi: ${error.message || error}`;
      integration.toast?.(`Chạy Lua trong ô lỗi: ${error.message || error}`, "error");
    }
  }

  function viewGeneratedLua() {
    try {
      const lua = currentLuaText();
      luaEditorSourceMode = isRawLuaWorkflow() ? "raw" : "generated";
      byId("workflow-lua-title").textContent = isRawLuaWorkflow() ? "Lua nhập trực tiếp / sửa và chạy" : "Lua sinh từ kịch bản / có thể sửa và chạy";
      byId("workflow-lua-output").value = lua;
      byId("workflow-lua-api-profile").value = preferredApiProfile(currentWorkflow);
      updateLuaEditorSummary();
      byId("workflow-lua-modal").classList.remove("hidden");
    } catch (error) {
      integration.toast?.(`Mở Lua editor lỗi: ${error.message || error}`, "error");
    }
  }

  function closeLua() {
    byId("workflow-lua-modal").classList.add("hidden");
  }

  async function copyGeneratedLua() {
    const output = byId("workflow-lua-output");
    const text = output.value || "";
    if (!text) return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        output.focus();
        output.select();
        document.execCommand("copy");
      }
      integration.toast?.("Đã copy Lua", "success");
    } catch (error) {
      integration.toast?.(`Copy Lua lỗi: ${error.message || error}`, "error");
    }
  }

  function downloadGeneratedLua() {
    try {
      const lua = byId("workflow-lua-output").value || currentLuaText();
      const blob = new Blob([lua], { type: "text/x-lua;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = safeLuaFileName();
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } catch (error) {
      integration.toast?.(`Tải Lua lỗi: ${error.message || error}`, "error");
    }
  }

	  function scriptTargets() {
	    refreshTargets();
	    const targets = integration.getWorkflowTargets?.() || [];
	    if (targets.length) return targets;
	    return primaryTarget ? [primaryTarget] : [];
	  }

	  function workflowHasScriptOnlyBlocks(workflow) {
	    const visit = (block) => {
	      if (!block) return false;
	      if (global.HidWorkflowBlocks.isScriptOnlyBlock?.(block.type)) return true;
	      return (block.body || []).some(visit);
	    };
	    return (workflow?.blocks || []).some(visit);
	  }

		  function preferredApiProfile(workflow) {
		    if (isRawLuaWorkflow()) return currentWorkflow.api_profile || "ioscontrol-v1";
		    const explicit = String(workflow?.api_profile || "").trim();
		    if (workflowHasScriptOnlyBlocks(workflow) && (!explicit || explicit === "hidprobe-v1")) {
		      return "ioscontrol-v1";
		    }
		    return explicit || "hidprobe-v1";
		  }

  function rememberRunningScript(packagePayload, targets) {
    if (!packagePayload?.script_id) return;
    lastRunningScriptPackage = packagePayload;
    lastRunningScriptTargets = Array.isArray(targets) ? targets.filter(Boolean) : [];
  }

  function assertScriptReady() {
    if (isRawLuaWorkflow()) {
      if (!String(currentWorkflow.raw_lua || "").trim()) throw new Error("Lua trống, chưa có nội dung để gửi");
    } else {
      if (!currentWorkflow?.blocks?.length) throw new Error("Workflow trống, chưa có bước để gửi");
      if (!workflowTested()) throw new Error("Cần Test workflow PASS trước khi gửi/chạy trên iPhone");
    }
    if (!global.HidWorkflowScriptExport?.exportWorkflowPackage) throw new Error("Thiếu module workflow_export_lua.js");
  }

  async function currentScriptPackage(targets) {
    assertScriptReady();
    const targetDeviceIds = (targets || []).map((target) => target?.device?.id || "").filter(Boolean);
    return global.HidWorkflowScriptExport.exportWorkflowPackage(currentWorkflow, {
	      targetDeviceIds,
	      apiProfile: preferredApiProfile(currentWorkflow),
    });
  }

  async function pushCurrentScript() {
    try {
      const targets = scriptTargets();
      if (!targets.length) throw new Error("Chưa chọn máy để gửi script");
      const packagePayload = await currentScriptPackage(targets);
      byId("workflow-status").textContent = `Đang gửi script ${packagePayload.version} vào ${targets.length} máy...`;
      const result = await integration.pushWorkflowScript?.(currentWorkflow, targets, { packagePayload });
      byId("workflow-status").textContent = `Đã gửi script vào ${result?.length || targets.length} máy`;
      integration.toast?.("✓ Đã gửi script vào iPhone", "success");
    } catch (error) {
      byId("workflow-status").textContent = `Gửi script lỗi: ${error.message || error}`;
      integration.toast?.(`Gửi script lỗi: ${error.message || error}`, "error");
    }
  }

  async function runCurrentOnDevice() {
    try {
      const targets = scriptTargets();
      if (!targets.length) throw new Error("Chưa chọn máy để chạy script");
      const packagePayload = await currentScriptPackage(targets);
      rememberRunningScript(packagePayload, targets);
      byId("workflow-status").textContent = `Đang gửi + chạy script trên ${targets.length} máy...`;
      await integration.pushWorkflowScript?.(currentWorkflow, targets, { packagePayload });
      const result = await integration.runOnDeviceScript?.(currentWorkflow, targets, { packagePayload });
      byId("workflow-status").textContent = `Đã phát lệnh chạy script trên ${result?.length || targets.length} máy`;
      integration.toast?.("✓ Đã phát lệnh chạy script trên iPhone", "success");
    } catch (error) {
      byId("workflow-status").textContent = `Chạy script lỗi: ${error.message || error}`;
      integration.toast?.(`Chạy script lỗi: ${error.message || error}`, "error");
    }
  }

  async function stopCurrentOnDevice() {
    try {
      const targets = lastRunningScriptTargets.length ? lastRunningScriptTargets : scriptTargets();
      if (!targets.length) throw new Error("Chưa chọn máy để dừng script");
      const packagePayload = lastRunningScriptPackage || {
        script_id: "active-script",
        version: "active",
      };
      const result = await integration.stopOnDeviceScript?.(currentWorkflow, targets, {
        packagePayload,
        reason: "web_stop_script",
      });
      if (lastRunningScriptPackage?.script_id === packagePayload?.script_id) {
        lastRunningScriptPackage = null;
        lastRunningScriptTargets = [];
      }
      byId("workflow-status").textContent = `Đã gửi lệnh dừng script tới ${result?.length || targets.length} máy`;
      integration.toast?.("Đã gửi lệnh dừng script", "info");
    } catch (error) {
      integration.toast?.(`Dừng script lỗi: ${error.message || error}`, "error");
    }
  }

  async function importWorkflowFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const fileName = String(file.name || "script.lua");
      const lowerName = fileName.toLowerCase();
      const looksLua = lowerName.endsWith(".lua") || lowerName.endsWith(".txt") || String(file.type || "").includes("lua") || String(file.type || "").startsWith("text/");
      if (!looksLua || lowerName.endsWith(".json")) {
        const parsed = JSON.parse(text);
        setWorkflow(parsed);
        integration.toast?.("Import workflow OK", "success");
        return;
      }
      const name = fileName.replace(/\.(lua|txt)$/i, "") || "Lua nhập trực tiếp";
      const workflow = global.HidWorkflowBlocks.createWorkflow(name);
      workflow.raw_lua = text;
      workflow.raw_lua_filename = fileName;
      workflow.api_profile = "ioscontrol-v1";
      workflow.description = "Lua nhập trực tiếp từ file local";
      setWorkflow(workflow, { resetTest: true });
      byId("workflow-status").textContent = `Đã nhập Lua ${fileName} · ${rawLuaLineCount()} dòng`;
      integration.toast?.("Import Lua OK; bấm Sửa/Chạy Lua hoặc Chạy trên iPhone", "success");
    } catch (error) {
      integration.toast?.(`Import lỗi: ${error.message}`, "error");
    } finally {
      event.target.value = "";
    }
  }

  async function importImageAssetFile(event) {
    const file = event.target.files?.[0];
    const block = currentWorkflow?.blocks?.find((item) => item.id === assetTargetBlockId) || selectedBlock();
    const paramKey = assetTargetParamKey || "image";
    try {
      if (!file) return;
      if (!blockSupportsImageParam(block, paramKey)) throw new Error("Chọn đúng block/ô ảnh trước khi nhập ảnh");
      if (!file.type.startsWith("image/")) throw new Error("File phải là ảnh PNG/JPG");
      const buffer = await file.arrayBuffer();
      const sha256 = await sha256HexFromArrayBuffer(buffer);
      const dataBase64 = base64FromArrayBuffer(buffer);
      const path = safeAssetPath(file.name || `template_${Date.now()}.png`);
      const dataUrl = `data:${file.type || "image/png"};base64,${dataBase64}`;
      const dims = await imageDimensionsFromDataUrl(dataUrl);
      assignAssetToBlock(block, {
        id: `asset-${sha256.slice(0, 12)}`,
        path,
        name: file.name || path,
        mime: file.type || "image/png",
        size: file.size || buffer.byteLength,
        sha256,
        data_base64: dataBase64,
        preview_data_url: dataUrl,
        source: "web_import",
        width: dims.width || undefined,
        height: dims.height || undefined,
        created_at: nowIso(),
      }, paramKey);
    } catch (error) {
      integration.toast?.(`Nhập ảnh lỗi: ${error.message || error}`, "error");
    } finally {
      assetTargetBlockId = "";
      assetTargetParamKey = "image";
      event.target.value = "";
    }
  }

  function beginImageCrop(blockId, paramKey = "image", options = {}) {
    const block = currentWorkflow?.blocks?.find((item) => item.id === blockId);
    if (!blockSupportsImageParam(block, paramKey)) return;
    refreshTargets();
    const videoWidth = previewVideo?.videoWidth || primaryTarget?.video?.videoWidth || 0;
    const videoHeight = previewVideo?.videoHeight || primaryTarget?.video?.videoHeight || 0;
    if (!previewVideo || previewVideo.readyState < 2 || !videoWidth || !videoHeight || !previewVideoRect()) {
      integration.toast?.("Chưa có live frame để crop ảnh mẫu", "error");
      return;
    }
    snapshotLastFrame();
    const native = options?.native === true;
    imageCropState = { blockId, paramKey, native, pointerId: null, startPoint: null, lastPoint: null, active: false };
    byId("workflow-status").textContent = native
      ? "Kéo vùng trên live; iPhone sẽ tự chụp/cắt ảnh native rồi gửi ảnh về web"
      : "Kéo một vùng trên live screen để crop ảnh mẫu";
    integration.toast?.(native ? "Kéo vùng để crop native từ iPhone" : "Kéo vùng ảnh mẫu trên live screen", "info");
    drawOverlay();
  }

  function cancelImageCrop() {
    imageCropState = null;
    drawOverlay();
  }

  function onImageCropPointerDown(event, point) {
    event.preventDefault();
    previewCanvas.setPointerCapture?.(event.pointerId);
    imageCropState.pointerId = event.pointerId;
    imageCropState.startPoint = point;
    imageCropState.lastPoint = point;
    imageCropState.active = true;
    byId("workflow-coordinate-readout").textContent = `crop: ${formatPoint(point)}`;
    drawOverlay();
  }

  function onImageCropPointerMove(event, point) {
    if (!imageCropState?.active || imageCropState.pointerId !== event.pointerId) return false;
    imageCropState.lastPoint = point;
    byId("workflow-coordinate-readout").textContent = `crop: ${formatPoint(imageCropState.startPoint)} → ${formatPoint(point)}`;
    drawOverlay();
    return true;
  }

  async function onImageCropPointerUp(event, point) {
    if (!imageCropState?.active || imageCropState.pointerId !== event.pointerId) return false;
    const state = imageCropState;
    imageCropState = null;
    try {
      if (previewCanvas.hasPointerCapture?.(event.pointerId)) previewCanvas.releasePointerCapture(event.pointerId);
    } catch (_error) {}
    const endPoint = point || state.lastPoint || state.startPoint;
    try {
      if (state.native) {
        await saveNativeImageCropAsset(state.blockId, state.paramKey || "image", state.startPoint, endPoint);
      } else {
        await saveImageCropAsset(state.blockId, state.paramKey || "image", state.startPoint, endPoint);
      }
    } catch (error) {
      const message = error.message || error;
      byId("workflow-status").textContent = `Crop ảnh lỗi: ${message}`;
      integration.toast?.(`Crop ảnh lỗi: ${message}`, "error");
    }
    drawOverlay();
    return true;
  }

  async function saveImageCropAsset(blockId, paramKey, startPoint, endPoint) {
    const block = currentWorkflow?.blocks?.find((item) => item.id === blockId);
    const videoWidth = previewVideo?.videoWidth || primaryTarget?.video?.videoWidth || 0;
    const videoHeight = previewVideo?.videoHeight || primaryTarget?.video?.videoHeight || 0;
    if (!block || !previewVideo || !videoWidth || !videoHeight || !startPoint || !endPoint) throw new Error("crop_state_missing");
    const minX = Math.min(startPoint.x, endPoint.x);
    const minY = Math.min(startPoint.y, endPoint.y);
    const maxX = Math.max(startPoint.x, endPoint.x);
    const maxY = Math.max(startPoint.y, endPoint.y);
    const sourceX = Math.max(0, Math.min(videoWidth - 1, Math.round(minX * videoWidth)));
    const sourceY = Math.max(0, Math.min(videoHeight - 1, Math.round(minY * videoHeight)));
    const cropWidth = Math.max(1, Math.min(videoWidth - sourceX, Math.round((maxX - minX) * videoWidth)));
    const cropHeight = Math.max(1, Math.min(videoHeight - sourceY, Math.round((maxY - minY) * videoHeight)));
    if (cropWidth < 6 || cropHeight < 6) {
      integration.toast?.("Vùng crop quá nhỏ", "error");
      return;
    }
    const canvas = document.createElement("canvas");
    canvas.width = cropWidth;
    canvas.height = cropHeight;
    const context = canvas.getContext("2d");
    context.drawImage(previewVideo, sourceX, sourceY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    const dataUrl = canvas.toDataURL("image/png");
    const dataBase64 = dataUrl.split(",")[1] || "";
    const bytes = Uint8Array.from(atob(dataBase64), (char) => char.charCodeAt(0));
    const sha256 = await sha256HexFromArrayBuffer(bytes.buffer);
    const path = safeAssetPath(`crop_${new Date().toISOString().replace(/[:.]/g, "-")}.png`);
    assignAssetToBlock(block, {
      id: `asset-${sha256.slice(0, 12)}`,
      path,
      name: path,
      mime: "image/png",
      size: bytes.byteLength,
      sha256,
      data_base64: dataBase64,
      preview_data_url: dataUrl,
      source: "web_live_crop",
      width: cropWidth,
      height: cropHeight,
      source_width: videoWidth,
      source_height: videoHeight,
      crop_norm: {
        x: Number(minX.toFixed(6)),
        y: Number(minY.toFixed(6)),
        width: Number((maxX - minX).toFixed(6)),
        height: Number((maxY - minY).toFixed(6)),
        center_x: Number(((minX + maxX) / 2).toFixed(6)),
        center_y: Number(((minY + maxY) / 2).toFixed(6)),
      },
      created_at: nowIso(),
    }, paramKey || "image");
  }

  function luaStringLiteral(value) {
    return `"${String(value ?? "")
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t")}"`;
  }

  function luaNumberLiteral(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number.toFixed(6) : Number(fallback).toFixed(6);
  }

  function parseUnitNumber(value) {
    if (typeof value === "number") return value;
    const text = String(value ?? "").trim();
    return Number(text && !text.includes(".") && text.includes(",") ? text.replace(",", ".") : text);
  }

  function thresholdKeyForImageParam(paramKey = "image") {
    const key = String(paramKey || "image").trim();
    if (key === "target_image") return "target_threshold";
    if (key === "first_target_image") return "first_target_threshold";
    if (key === "second_image") return "second_threshold";
    if (key === "second_target_image") return "second_target_threshold";
    return "threshold";
  }

  function tuneNativeCropThreshold(block, paramKey = "image") {
    if (!block?.params) return;
    const key = thresholdKeyForImageParam(paramKey);
    const current = parseUnitNumber(block.params[key]);
    if (!Number.isFinite(current) || current > 0.85) {
      block.params[key] = 0.85;
    }
  }

  function buildNativeCropLua(path, crop) {
    const cropJson = [
      `x = ${luaNumberLiteral(crop.x)}`,
      `y = ${luaNumberLiteral(crop.y)}`,
      `width = ${luaNumberLiteral(crop.width, 1)}`,
      `height = ${luaNumberLiteral(crop.height, 1)}`,
      `center_x = ${luaNumberLiteral(crop.center_x, 0.5)}`,
      `center_y = ${luaNumberLiteral(crop.center_y, 0.5)}`,
    ].join(", ");
    return `-- HIDProbe native crop asset capture
local native_crop_path = ${luaStringLiteral(path)}
local native_crop = { ${cropJson} }
local function native_crop_fail(reason)
  if reportResult then
    reportResult({
      kind = "native_crop_asset",
      ok = false,
      path = native_crop_path,
      reason = tostring(reason or "unknown"),
      crop_norm = native_crop
    })
  end
  if fail then fail("native_crop_failed:" .. tostring(reason or "unknown")) end
  error("native_crop_failed:" .. tostring(reason or "unknown"), 0)
end

if not saveImageTemplate then native_crop_fail("saveImageTemplate_missing") end
if not readTemplateBase64 then native_crop_fail("readTemplateBase64_missing") end

reportStep("native_crop:start:path=" .. native_crop_path)
local saved, save_reason, save_timed_out = saveImageTemplate(native_crop_path, native_crop.x, native_crop.y, native_crop.width, native_crop.height, 6)
if not saved then native_crop_fail(save_reason or (save_timed_out and "save_timeout" or "save_failed")) end

local asset = readTemplateBase64(native_crop_path, ${NativeCropMaxBytes})
if type(asset) ~= "table" or asset.ok ~= true then
  local reason = type(asset) == "table" and asset.reason or "read_failed"
  native_crop_fail(reason)
end

local screen_width = 0
local screen_height = 0
if screenSize then
  local sw, sh = screenSize()
  screen_width = tonumber(sw or 0) or 0
  screen_height = tonumber(sh or 0) or 0
end
asset.kind = "native_crop_asset"
asset.ok = true
asset.reason = "ok"
asset.path = native_crop_path
asset.name = native_crop_path
asset.mime = asset.mime or "image/png"
asset.source = "iphone_native_crop"
asset.crop_norm = native_crop
asset.source_width = screen_width
asset.source_height = screen_height
reportResult(asset)
reportStep("native_crop:done:path=" .. native_crop_path .. ":bytes=" .. tostring(asset.size or 0))
`;
  }

  function parseNativeCropResultFromEvents(runResults = []) {
    const events = [];
    for (const result of runResults || []) {
      for (const event of result?.events || []) events.push(event);
    }
    for (const event of events) {
      const raw = String(event?.message || event?.event || "").trim();
      const text = raw.replace(/^[^:]+:\s+script_log\s+/, "").replace(/^lua_reportStep\s+/, "");
      const markerIndex = text.indexOf("result:");
      if (markerIndex < 0) continue;
      const jsonText = text.slice(markerIndex + "result:".length).trim();
      if (!jsonText.startsWith("{")) continue;
      try {
        const parsed = JSON.parse(jsonText);
        if (parsed?.kind === "native_crop_asset") return parsed;
      } catch (_error) {}
    }
    return null;
  }

  async function runNativeCropOnIPhone(path, crop) {
    if (!global.HidWorkflowScriptExport?.exportWorkflowPackage) throw new Error("Thiếu module workflow_export_lua.js");
    if (typeof integration.pushWorkflowScript !== "function" || typeof integration.runOnDeviceScript !== "function") {
      throw new Error("Thiếu API gửi/chạy script để crop native");
    }
    refreshTargets();
    const target = hasTargetDeviceId(primaryTarget) ? primaryTarget : scriptTargets().find(hasTargetDeviceId);
    if (!target) throw new Error("Chưa chọn iPhone để crop native");

    const lua = buildNativeCropLua(path, crop);
    const temp = global.HidWorkflowBlocks.createWorkflow(`Native crop ${path}`);
    temp.api_profile = "ioscontrol-v1";
    temp.raw_lua = lua;
    temp.raw_lua_filename = `native_crop_${Date.now()}.lua`;
    temp.blocks = [];
    temp.connections = [];
    temp.assets = [];

    const targetDeviceIds = [target?.device?.id || target?.device_id || target?.id].filter(Boolean);
    const scriptId = `native-crop-${Date.now()}`;
    const runId = `native-crop-${Date.now()}`;
    const packagePayload = await global.HidWorkflowScriptExport.exportWorkflowPackage(temp, {
      targetDeviceIds,
      apiProfile: "ioscontrol-v1",
      scriptId,
    });

    const previousRunningPackage = lastRunningScriptPackage;
    const previousRunningTargets = lastRunningScriptTargets.slice();
    rememberRunningScript(packagePayload, [target]);
    try {
      byId("workflow-status").textContent = `Đang gửi yêu cầu crop native tới ${targetDeviceIds[0]}...`;
      await integration.pushWorkflowScript(temp, [target], { packagePayload });
      byId("workflow-status").textContent = `Đã gửi gói crop native; đang chờ iPhone bắt đầu chạy Lua...`;
      const runResults = await integration.runOnDeviceScript(temp, [target], {
        packagePayload,
        runId,
        waitTimeoutMs: 45000,
        startTimeoutMs: 12000,
        pollIntervalMs: 500,
        limit: 240,
      });
      const result = parseNativeCropResultFromEvents(runResults);
      if (!result) throw new Error("iPhone chưa trả result native_crop_asset qua script-events");
      if (result.ok !== true) throw new Error(`iPhone crop native lỗi: ${result.reason || "unknown"}`);
      if (!String(result.data_base64 || "").trim()) throw new Error("iPhone crop native không trả data_base64");
      return result;
    } finally {
      if (lastRunningScriptPackage?.script_id === packagePayload.script_id) {
        lastRunningScriptPackage = previousRunningPackage;
        lastRunningScriptTargets = previousRunningTargets;
      }
    }
  }

  async function saveNativeImageCropAsset(blockId, paramKey, startPoint, endPoint) {
    const block = currentWorkflow?.blocks?.find((item) => item.id === blockId);
    const videoWidth = previewVideo?.videoWidth || primaryTarget?.video?.videoWidth || 0;
    const videoHeight = previewVideo?.videoHeight || primaryTarget?.video?.videoHeight || 0;
    if (!block || !videoWidth || !videoHeight || !startPoint || !endPoint) throw new Error("native_crop_state_missing");
    const minX = Math.min(startPoint.x, endPoint.x);
    const minY = Math.min(startPoint.y, endPoint.y);
    const maxX = Math.max(startPoint.x, endPoint.x);
    const maxY = Math.max(startPoint.y, endPoint.y);
    const cropWidth = Math.max(1, Math.round((maxX - minX) * videoWidth));
    const cropHeight = Math.max(1, Math.round((maxY - minY) * videoHeight));
    if (cropWidth < 6 || cropHeight < 6) {
      integration.toast?.("Vùng crop quá nhỏ", "error");
      return;
    }

    const crop = {
      x: Number(minX.toFixed(6)),
      y: Number(minY.toFixed(6)),
      width: Number((maxX - minX).toFixed(6)),
      height: Number((maxY - minY).toFixed(6)),
      center_x: Number(((minX + maxX) / 2).toFixed(6)),
      center_y: Number(((minY + maxY) / 2).toFixed(6)),
    };
    const path = safeAssetPath(`native_crop_${new Date().toISOString().replace(/[:.]/g, "-")}.png`);
    const result = await runNativeCropOnIPhone(path, crop);
    const dataBase64 = String(result.data_base64 || "").trim();
    const bytes = Uint8Array.from(atob(dataBase64), (char) => char.charCodeAt(0));
    const sha256 = String(result.sha256 || "").trim().toLowerCase() || await sha256HexFromArrayBuffer(bytes.buffer);
    const dataUrl = `data:${result.mime || "image/png"};base64,${dataBase64}`;
    const dims = await imageDimensionsFromDataUrl(dataUrl);
    assignAssetToBlock(block, {
      id: `asset-${sha256.slice(0, 12)}`,
      path,
      name: path,
      mime: result.mime || "image/png",
      size: Number(result.size || bytes.byteLength) || bytes.byteLength,
      sha256,
      data_base64: dataBase64,
      preview_data_url: dataUrl,
      source: "iphone_native_crop",
      width: Number(result.width || dims.width || 0) || undefined,
      height: Number(result.height || dims.height || 0) || undefined,
      source_width: Number(result.source_width || videoWidth || 0) || undefined,
      source_height: Number(result.source_height || videoHeight || 0) || undefined,
      crop_norm: crop,
      created_at: nowIso(),
    }, paramKey || "image");
    tuneNativeCropThreshold(block, paramKey || "image");
    renderProperties();
    byId("workflow-status").textContent = `Đã nhận ảnh native từ iPhone: ${path}`;
    integration.toast?.(`Đã crop native từ iPhone: ${path}`, "success");
  }

  function openAi() {
    byId("workflow-ai-modal").classList.remove("hidden");
    byId("ai-status").textContent = "Nhập prompt hoặc chọn ví dụ";
  }

  function closeAi() {
    byId("workflow-ai-modal").classList.add("hidden");
  }

  async function generateAiWorkflow() {
    const prompt = byId("ai-prompt").value.trim();
    if (!prompt) {
      byId("ai-status").textContent = "Prompt đang trống";
      return;
    }
    byId("ai-status").textContent = "Đang tạo...";
    byId("ai-preview").textContent = "";
    try {
      const settings = global.HidWorkflowStorage.loadAiSettings();
      const client = new global.HidAiClient.AIClient(settings);
      const result = await client.generate(prompt);
      result.workflow.test_metadata = null;
      lastAiWorkflow = result.workflow;
      settings.tokenUsage = (Number(settings.tokenUsage) || 0) + Number(result.tokens_used?.input || 0) + Number(result.tokens_used?.output || 0);
      global.HidWorkflowStorage.saveAiSettings(settings);
      byId("ai-preview").textContent = JSON.stringify(result.workflow, null, 2);
      byId("ai-status").textContent = `✓ ${result.workflow.blocks.length} blocks · có thể lưu · cần test trước khi gửi/chạy`;
    } catch (error) {
      byId("ai-status").textContent = `✗ ${error.message || error}`;
      byId("ai-preview").textContent = String(error.stack || error);
    }
  }

  function insertAiWorkflow() {
    if (!lastAiWorkflow) {
      byId("ai-status").textContent = "Chưa có workflow AI để insert";
      return;
    }
    if (currentWorkflow.blocks.length && !confirm("Editor đang có workflow. Ghi đè bằng workflow AI?")) return;
    const workflow = global.HidWorkflowBlocks.normalizeWorkflow(lastAiWorkflow);
    workflow.test_metadata = null;
    setWorkflow(workflow, { resetTest: true });
    closeAi();
    integration.toast?.("Đã insert workflow AI; có thể lưu, cần test trước khi gửi/chạy", "success");
  }

  global.HidWorkflowEditor = {
    install,
    open,
    close,
    saveCurrent,
    runCurrent: testWorkflow,
    setWorkflow,
    getSelectedSavedWorkflowIds,
    getSelectedSavedWorkflows,
  };
})(window);
