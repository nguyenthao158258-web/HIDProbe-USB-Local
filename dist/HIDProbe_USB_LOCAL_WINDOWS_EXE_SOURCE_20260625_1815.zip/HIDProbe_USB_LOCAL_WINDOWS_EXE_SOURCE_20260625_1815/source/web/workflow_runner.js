"use strict";

(function attachWorkflowRunner(global) {
  class WorkflowCancelledError extends Error {
    constructor(message = "Workflow cancelled") {
      super(message);
      this.name = "WorkflowCancelledError";
    }
  }

  class WorkflowRunner {
    constructor(integration) {
      this.integration = integration;
      this.status = "idle";
      this.workflow = null;
      this.targets = [];
      this.variables = {};
      this.log = [];
      this.currentBlockId = "";
      this.pauseResolver = null;
      this.startedAt = 0;
    }

    async run(workflow, targets) {
      this.workflow = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
      this.targets = targets || [];
      this.variables = { ...(this.workflow.variables || {}) };
      this.log = [];
      this.status = "running";
      this.startedAt = performance.now();
      this.integration.onStatus?.(this.snapshot());
      try {
        const blocks = global.HidWorkflowBlocks.orderedBlocks(this.workflow);
        for (let index = 0; index < blocks.length; index += 1) {
          const block = blocks[index];
          await this.executeBlock(block, { orderedBlocks: blocks, blockIndex: index });
        }
        this.status = "done";
      } catch (error) {
        if (error instanceof WorkflowCancelledError) {
          this.status = "cancelled";
        } else {
          this.status = "failed";
          this.log.push({ level: "error", block_id: this.currentBlockId, message: error.message || String(error) });
        }
      } finally {
        const durationMs = Math.round(performance.now() - this.startedAt);
        this.integration.onStatus?.(this.snapshot());
        global.HidWorkflowStorage.addHistory({
          workflow_id: this.workflow.id,
          workflow_name: this.workflow.name,
          started_at: new Date(Date.now() - durationMs).toISOString(),
          duration_ms: durationMs,
          devices: this.targets.map((target) => target.device?.id || target.id || String(target)),
          result: this.status,
          log: this.log,
        });
      }
      return this.snapshot();
    }

    snapshot() {
      return {
        status: this.status,
        workflow: this.workflow,
        targets: this.targets,
        variables: this.variables,
        log: this.log,
        currentBlockId: this.currentBlockId,
        elapsed_ms: this.startedAt ? Math.round(performance.now() - this.startedAt) : 0,
      };
    }

    pause() {
      if (this.status !== "running") return;
      this.status = "paused";
      this.integration.onStatus?.(this.snapshot());
    }

    resume() {
      if (this.status !== "paused") return;
      this.status = "running";
      if (this.pauseResolver) this.pauseResolver();
      this.pauseResolver = null;
      this.integration.onStatus?.(this.snapshot());
    }

    cancel() {
      this.status = "cancelled";
      if (this.pauseResolver) this.pauseResolver();
      this.pauseResolver = null;
      this.integration.onStatus?.(this.snapshot());
    }

    async waitIfPaused() {
      if (this.status === "cancelled") throw new WorkflowCancelledError();
      if (this.status !== "paused") return;
      await new Promise((resolve) => { this.pauseResolver = resolve; });
      if (this.status === "cancelled") throw new WorkflowCancelledError();
    }

    async executeBlock(block, context = {}) {
      await this.waitIfPaused();
      if (this.status === "cancelled") throw new WorkflowCancelledError();
      this.currentBlockId = block.id;
      this.log.push({ level: "info", block_id: block.id, message: `start ${block.type}` });
      this.integration.onBlockStart?.(block, this.snapshot());
      this.integration.onStatus?.(this.snapshot());

      try {
        if (block.type === "wait") {
          await this.delay(global.HidWorkflowBlocks.asPositiveInt(block.params?.ms, 1000));
        } else if (block.type === "loop") {
          const count = global.HidWorkflowBlocks.asPositiveInt(block.params?.iterations, 1, 1, 10000);
          const range = global.HidWorkflowBlocks.loopRepeatRange?.(block, context.blockIndex, context.orderedBlocks || []);
          const children = range ? range.blocks : (block.body || []);
          for (let index = 0; index < count; index += 1) {
            this.variables._loop_index = index;
            this.log.push({ level: "info", block_id: block.id, message: range ? `loop ${index + 1}/${count} steps ${range.start_step}-${range.end_step}` : `loop ${index + 1}/${count}` });
            for (const child of children) {
              const childIndex = Array.isArray(context.orderedBlocks) ? context.orderedBlocks.findIndex((item) => item.id === child.id) : -1;
              await this.executeBlock(child, { orderedBlocks: context.orderedBlocks || [], blockIndex: childIndex });
            }
          }
        } else if (block.type === "if_else") {
          const ok = this.evaluateCondition(block.params || {});
          this.log.push({ level: "info", block_id: block.id, message: `condition=${ok ? "true" : "false"}` });
        } else if (block.type === "set_variable") {
          this.variables[String(block.params?.name || "value")] = block.params?.value ?? "";
        } else if (block.type === "notify") {
          this.integration.toast?.(block.params?.message || "Workflow notification", block.params?.level || "info");
          this.log.push({ level: block.params?.level || "info", block_id: block.id, message: block.params?.message || "" });
        } else if (block.type === "screenshot") {
          for (const target of this.targets) {
            const name = String(block.params?.save_as || "screenshot");
            const value = await this.integration.captureScreenshot?.(target, name);
            this.variables[name] = value || this.variables[name];
          }
        } else if (block.type === "open_app") {
          const target = String(block.params?.bundle_id || block.params?.url_scheme || "").trim();
          if (!target) throw new Error(`${block.id}: chọn ứng dụng hoặc nhập bundle_id`);
          if (typeof this.integration.runOpenApp !== "function") throw new Error(`${block.id}: live_open_app chưa được hỗ trợ`);
          const result = await this.integration.runOpenApp(block, this.targets);
          this.log.push({ level: "success", block_id: block.id, message: `live_open_app ${target} · ${result?.length || this.targets.length} máy` });
        } else if (global.HidWorkflowBlocks.isScriptOnlyBlock?.(block.type)) {
          if (typeof this.integration.runLuaBlock !== "function") throw new Error(`${block.id}: live_lua_block chưa được hỗ trợ`);
          const result = await this.integration.runLuaBlock(block, this.targets, {
            onScriptEvent: (entry) => this.appendLiveScriptEvent(block, entry),
          });
          this.appendScriptRunEvidence(block, result);
          this.log.push({ level: "success", block_id: block.id, message: `live_lua_block ${block.type} · ${result?.length || this.targets.length} máy` });
        } else {
          const command = global.HidWorkflowBlocks.commandFromBlock(block);
          if (!command) throw new Error(`Unsupported block: ${block.type}`);
          await this.sendToTargets(command, block);
        }
      } catch (error) {
        if (this.shouldContinueOnBlockError(block)) {
          const message = error?.message || String(error);
          this.log.push({ level: "error", block_id: block.id, message: `block_error_continue:${message}` });
          this.integration.onBlockDone?.(block, this.snapshot());
          this.integration.onStatus?.(this.snapshot());
          return;
        }
        throw error;
      }

      this.integration.onBlockDone?.(block, this.snapshot());
      this.log.push({ level: "success", block_id: block.id, message: `done ${block.type}` });
      this.integration.onStatus?.(this.snapshot());
    }

    shouldContinueOnBlockError(block) {
      return String(block?.params?.on_error || "fail").trim().toLowerCase() === "continue";
    }

    appendLiveScriptEvent(block, entry) {
      const event = entry?.event || {};
      const deviceId = entry?.device_id || "device";
      const message = [event.event, event.message].filter(Boolean).join(" ");
      if (!message) return;
      this.log.push({
        level: event.status === "failed" ? "error" : "info",
        block_id: block.id,
        message: `${deviceId}: ${message}`,
      });
      this.integration.onStatus?.(this.snapshot());
    }

    appendScriptRunEvidence(block, results) {
      for (const item of results || []) {
        const deviceId = item.device_id || "device";
        for (const event of item.events || []) {
          const message = [event.event, event.message].filter(Boolean).join(" ");
          if (!message) continue;
          if (this.log.some((entry) => entry.block_id === block.id && entry.message === `${deviceId}: ${message}`)) continue;
          this.log.push({
            level: event.status === "failed" ? "error" : "info",
            block_id: block.id,
            message: `${deviceId}: ${message}`,
          });
        }
      }
    }

    async delay(ms) {
      const end = performance.now() + ms;
      while (performance.now() < end) {
        await this.waitIfPaused();
        if (this.status === "cancelled") throw new WorkflowCancelledError();
        await new Promise((resolve) => setTimeout(resolve, Math.min(100, end - performance.now())));
      }
    }

    evaluateCondition(params) {
      const variable = String(params.variable || params.var || "");
      if (params.condition_type === "var_equals") return String(this.variables[variable]) === String(params.value ?? "");
      if (params.condition_type === "var_exists") return this.variables[variable] !== undefined;
      return false;
    }

    async sendToTargets(command, block) {
      const results = await Promise.allSettled(this.targets.map(async (target) => {
        if (!target?.canReceiveSync?.()) throw new Error(`${target?.device?.id || "unknown"} offline`);
        return this.integration.sendCommand(target, command, block);
      }));
      const failures = [];
      for (let index = 0; index < results.length; index += 1) {
        const result = results[index];
        const target = this.targets[index];
        const deviceId = target?.device?.id || `target-${index}`;
        if (result.status === "rejected") {
          const message = result.reason?.message || String(result.reason);
          failures.push(`${deviceId}: ${message}`);
          this.log.push({ level: "error", block_id: block.id, device_id: deviceId, message });
        } else if (result.value?.ok === false) {
          const message = result.value?.reason || (result.value?.timeout ? "ack_timeout" : "ack_failed");
          failures.push(`${deviceId}: ${message}`);
          this.log.push({ level: "error", block_id: block.id, device_id: deviceId, message });
        } else {
          this.log.push({ level: "success", block_id: block.id, device_id: deviceId, message: result.value?.phase ? `ack ${result.value.phase}` : "sent" });
        }
      }
      if (failures.length) throw new Error(`Block ${block.id} failed: ${failures.join(" | ")}`);
    }
  }

  global.HidWorkflowRunner = {
    WorkflowRunner,
    WorkflowCancelledError,
  };
})(window);
