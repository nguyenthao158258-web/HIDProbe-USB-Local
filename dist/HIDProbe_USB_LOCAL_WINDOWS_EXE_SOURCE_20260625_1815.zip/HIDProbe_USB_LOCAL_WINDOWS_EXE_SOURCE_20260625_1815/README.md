# HIDProbe USB Local - Windows EXE Source Handoff

Package time: 2026-06-25 18:15 ICT

Muc tieu cua goi nay la dua cho Codex/agent khac de port app dieu khien USB hien tai sang Windows va dong goi thanh file `.exe`.

## Trang thai hien tai

- Ban macOS dang chay la `HIDProbeUSBLocalController.app`.
- Source macOS tham chieu nam tai `source/mac_reference/HIDProbeUSBLocalController.swift`.
- Web UI/UX hien tai nam tai `source/web/`.
- Web UI da xoa bang dem nguoc Lua OK o phia may tinh.
- Dong ho OK phai hien tren iPhone IPA/HUD, khong hien tren app may tinh.

## Yeu cau bat buoc khi lam Windows EXE

- Khong dung WDA.
- Khong quay lai LAN/WiFi lam duong chinh.
- Duong chinh la USB local tunnel vao iPhone app port `17391`.
- Man hinh, HID touch va Lua phai di qua USB native bridge.
- App Windows phai copy UI web hien tai gan 100%.
- App Windows khong duoc them panel Lua OK/dem nguoc o phia may tinh.
- Chi iPhone/HID IPA moi hien countdown OK tren toast/HUD.

## Kien truc can port

Mac app hien tai gom 2 phan:

1. Native shell:
   - WebView hien UI tu `source/web/`.
   - Liet ke iPhone USB bang `pymobiledevice3 --no-color usbmux list`.
   - Tao USB forward local port `17391 -> 17391`.
   - Mo socket TCP toi `127.0.0.1:17391`.
   - Doc frame native tu iPhone va day vao web bang `window.HIDProbeUSB.onNativeFrame(...)`.
   - Gui HID/Lua qua native packet tren socket USB.

2. Web UI:
   - File chinh: `source/web/index.html`.
   - Adapter USB: `source/web/usb_local_adapter.js`.
   - Adapter nay dang dung bridge JS tu native qua `window.webkit.messageHandlers.hidprobe.postMessage(...)`.

## Goi y hien thuc Windows

Co 2 huong tot:

1. `.NET 8 WPF/WinForms + WebView2`
   - EXE gon, on dinh tren Windows.
   - Inject JS shim:
     `window.webkit.messageHandlers.hidprobe.postMessage(msg)` -> `chrome.webview.postMessage(msg)`.
   - Native C# xu ly message `listDevices`, `connect`, `disconnect`, `hid`, `lua`, `runWorkflow`.

2. `Electron`
   - Nhanh de port UI web.
   - Main process xu ly USB/pymobiledevice3/socket.
   - Preload inject shim tu `window.webkit.messageHandlers.hidprobe.postMessage` sang IPC.

## Windows dependency

- WebView2 Runtime neu dung .NET WebView2.
- Python 3.11+ va `pymobiledevice3`, hoac bundle san Python embeddable + pymobiledevice3.
- Neu `pymobiledevice3 usbmux forward` khong on tren Windows, dung `iproxy.exe`/libimobiledevice tuong duong de forward:
  - local `127.0.0.1:17391`
  - remote iPhone `127.0.0.1:17391`

## Native protocol can giu nguyen

Port lai logic trong `HIDProbeUSBLocalController.swift`:

- `pollDevices`
- `ensureTunnel`
- `terminateTunnel`
- `startNativeStream`
- `sendNativeHID`
- `sendNativeLua`
- `USBNativeWire.encode`
- `USBNativeWire.nextPacket`

Web side da san:

- `window.HIDProbeUSB.onDevices(devices)`
- `window.HIDProbeUSB.onTunnelStatus(text)`
- `window.HIDProbeUSB.onNativeFrame(dataBase64)`
- `window.HIDProbeUSB.onLog(message)`

## Tieu chi PASS cho EXE

- Cam iPhone bang USB, bam Trust, app Windows tu nhan may.
- Bam Ket noi, stream hien hinh.
- Tap/vuot tren man hinh web dieu khien duoc iPhone.
- Push/Run Lua di qua USB.
- Khi mat frame/socket, app tu reconnect.
- Khong co bang Lua OK countdown tren app Windows.
- Countdown OK chi hien tren iPhone/HID IPA toast/HUD.

## Khong public goi nay

Goi nay co source app dieu khien may tinh, chi dung noi bo de build EXE. Repo GitHub public chi duoc de IPA.
