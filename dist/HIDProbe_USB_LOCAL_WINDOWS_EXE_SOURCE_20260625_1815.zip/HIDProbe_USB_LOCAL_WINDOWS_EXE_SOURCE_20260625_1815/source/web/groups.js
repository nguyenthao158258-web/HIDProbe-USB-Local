"use strict";

(function attachGroups(global) {
  const Palette = ["#22c55e", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];
  function makeGroup(name) {
    return {
      id: `group-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`,
      name: String(name || "Nhóm mới").trim() || "Nhóm mới",
      color: Palette[Math.floor(Math.random() * Palette.length)],
      created_at: Date.now(),
    };
  }
  function groupCounts(devices, groups) {
    const counts = new Map(groups.map((group) => [group.id, 0]));
    let ungrouped = 0;
    for (const device of devices) {
      if (device.group_id && counts.has(device.group_id)) counts.set(device.group_id, counts.get(device.group_id) + 1);
      else ungrouped += 1;
    }
    return { counts, ungrouped };
  }
  global.HidGroups = { makeGroup, groupCounts, Palette };
})(window);
