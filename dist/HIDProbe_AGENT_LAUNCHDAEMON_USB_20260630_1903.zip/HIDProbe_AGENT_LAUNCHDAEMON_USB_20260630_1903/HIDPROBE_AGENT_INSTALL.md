# HIDProbe Agent LaunchDaemon Install

Mục tiêu của bản này: PC nói chuyện với `hidprobe_agent` chạy nền qua USB port `17391`, không phụ thuộc app HID đang foreground.

## File tạo ra

- `dist/HIDProbeApp_AGENT_LAUNCHDAEMON_USB_*.ipa`: IPA mới, có bunded `hidprobe_agent` và installer trong app.
- `HIDProbeApp/Resources/Agent/hidprobe_agent`: agent binary arm64.
- `HIDProbeApp/Resources/Agent/com.hidprobe.agent.plist`: LaunchDaemon plist.
- `installer/install_hidprobe_agent_ssh.sh`: cài agent qua SSH nếu IPA không đủ quyền ghi LaunchDaemons.
- `dist/hidprobe-agent_1.0.0_iphoneos-arm64.deb`: package rootless.

## Cách cài bằng IPA

1. Cài IPA bằng TrollStore.
2. Mở HIDProbe một lần để app chạy bootstrap.
3. App sẽ cố copy/load:
   - Rootless: `/var/jb/usr/local/bin/hidprobe_agent`
   - Rootful: `/usr/local/bin/hidprobe_agent`
   - Plist: `/var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist` hoặc `/Library/LaunchDaemons/com.hidprobe.agent.plist`
4. Sau đó có thể đóng app HID. PC vẫn kết nối USB tới port `17391`.

## Cách cài qua SSH

```bash
bash installer/install_hidprobe_agent_ssh.sh root@IPHONE_IP
```

Nếu SSH chạy port khác:

```bash
bash installer/install_hidprobe_agent_ssh.sh root@IPHONE_IP 2222
```

## Kiểm tra trên iPhone

```bash
launchctl list | grep hidprobe
ps aux | grep hidprobe_agent
tail -n 80 /var/mobile/Library/Logs/hidprobe-agent.log
cat /var/mobile/Library/Logs/hidprobe-agent-heartbeat.json
```

## Kiểm tra từ PC/Mac qua USB

Sau khi forward USB port `17391 -> 17391`, gọi:

```bash
curl http://127.0.0.1:17391/health
curl -o screen.jpg http://127.0.0.1:17391/screenshot.jpg
```

Mac app hiện tại dùng native `HPB1` protocol và sẽ nhận frame JPEG từ agent nếu tunnel USB còn sống.

## Ghi chú kỹ thuật

- Agent có `RunAtLoad=true`, `KeepAlive=true`, `UserName=root`.
- Agent log: `/var/mobile/Library/Logs/hidprobe-agent.log`.
- Agent heartbeat: `/var/mobile/Library/Logs/hidprobe-agent-heartbeat.json`.
- OCR/findText xử lý bên PC. Agent chỉ gửi screenshot/frame và nhận tọa độ tap/swipe.
- Lua engine đầy đủ vẫn nằm trong IPA foreground ở bản này; agent nhận script packet và ack rõ `lua_engine_lives_in_ipa_foreground_agent_v1_ack_only`.
