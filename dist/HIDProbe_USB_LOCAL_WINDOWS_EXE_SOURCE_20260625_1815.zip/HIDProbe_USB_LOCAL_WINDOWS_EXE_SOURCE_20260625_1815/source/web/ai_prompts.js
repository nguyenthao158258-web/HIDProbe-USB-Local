"use strict";

(function attachAiPrompts(global) {
  const SystemPrompt = `You are a workflow generator for HIDProbe iPhone automation.

Generate ONLY a JSON object matching this schema. No prose, no markdown.

Available block types:
- tap: { x: 0-1, y: 0-1 }
- long_press: { x, y, hold_ms }
- swipe: { preset: "custom"|"up"|"down"|"left"|"right"|"bottom_up", from_x?, from_y?, to_x?, to_y?, duration_ms, steps }
- hardware_home: { reason?: string }
- wait: { ms }
- screenshot: { save_as: string }
- loop: { iterations: int, body: [block...] }
- if_else: { condition_type: "var_equals"|"var_exists", variable: string, value?: string }
- set_variable: { name, value }
- notify: { message, level }

Schema:
{
  "schema_version": "1.1",
  "name": string,
  "description": string,
  "blocks": [{ "id": string, "type": string, "params": object }],
  "connections": [{ "from": string, "to": string, "port": "next" }]
}

Coordinate convention: (0,0) = top-left, (1,1) = bottom-right.
AI may only create candidate workflow JSON. Never include test_metadata and never claim the workflow is tested; the operator can save it, but must review markers on the live iPhone screen and run Test workflow before sending/running on iPhone.
Respond ONLY with JSON.`;

  const Examples = [
    { label: "Mở Facebook", prompt: "Mở Facebook rồi chụp màn hình kiểm tra" },
    { label: "Like 10 bài", prompt: "Mở Facebook, vuốt xuống xem newsfeed, like 10 bài đầu" },
    { label: "Vuốt 5 lần", prompt: "Vuốt xuống 5 lần, mỗi lần chờ 2 giây" },
    { label: "Tap giữa 100 lần", prompt: "Mỗi 5 giây tap vào giữa màn hình, làm 100 lần" },
    { label: "Screenshot", prompt: "Chụp màn hình hiện tại và thông báo xong" },
    { label: "Messenger", prompt: "Mở messenger, tap tin nhắn đầu, chờ 2 giây, chụp màn hình" },
    { label: "Instagram story", prompt: "Mở Instagram, chờ load, vuốt xuống 3 lần, screenshot cuối" },
    { label: "Captcha check", prompt: "Nếu đã có biến captcha thì báo lỗi, nếu không thì tap continue" },
    { label: "Login flow", prompt: "Tap username, chờ, tap password, chờ, tap submit" },
    { label: "Scroll + wait", prompt: "Vuốt xuống 3 lần, mỗi lần chờ 2 giây, screenshot cuối cùng" },
  ];

  function localWorkflowFromPrompt(prompt) {
    const text = String(prompt || "").toLowerCase();
    const workflow = global.HidWorkflowBlocks.createWorkflow("AI Local Workflow");
    workflow.description = prompt;
    const blocks = [];
    const add = (type, params = {}, body = null) => {
      const block = global.HidWorkflowBlocks.createBlock(type, { params, body: body || undefined });
      blocks.push(block);
      return block;
    };
    if (text.includes("facebook") || text.includes("mở")) {
      add("open_app", { bundle_id: text.includes("instagram") ? "com.burbn.instagram" : "com.facebook.Facebook" });
      add("wait", { ms: 2500 });
    }
    if (text.includes("like")) {
      const match = text.match(/(\d+)\s*(bài|lan|lần)/);
      const iterations = Math.min(Math.max(Number(match?.[1] || 5), 1), 100);
      add("loop", { iterations }, [
        global.HidWorkflowBlocks.createBlock("tap", { params: { x: 0.2, y: 0.72 } }),
        global.HidWorkflowBlocks.createBlock("wait", { params: { ms: 800 } }),
        global.HidWorkflowBlocks.createBlock("swipe", { params: { preset: "down", duration_ms: 450, steps: 12 } }),
        global.HidWorkflowBlocks.createBlock("wait", { params: { ms: 1200 } }),
      ]);
    } else if (text.includes("vuốt") || text.includes("scroll")) {
      const match = text.match(/(\d+)\s*(lần|lan)/);
      const iterations = Math.min(Math.max(Number(match?.[1] || 3), 1), 100);
      add("loop", { iterations }, [
        global.HidWorkflowBlocks.createBlock("swipe", { params: { preset: text.includes("lên") ? "up" : "down", duration_ms: 450, steps: 12 } }),
        global.HidWorkflowBlocks.createBlock("wait", { params: { ms: 1500 } }),
      ]);
    } else if (text.includes("tap")) {
      const match = text.match(/(\d+)\s*(lần|lan)/);
      const iterations = Math.min(Math.max(Number(match?.[1] || 1), 1), 200);
      add("loop", { iterations }, [
        global.HidWorkflowBlocks.createBlock("tap", { params: { x: 0.5, y: 0.5 } }),
        global.HidWorkflowBlocks.createBlock("wait", { params: { ms: text.includes("5 giây") ? 5000 : 800 } }),
      ]);
    }
    if (text.includes("screenshot") || text.includes("chụp")) add("screenshot", { save_as: "result" });
    if (!blocks.length) {
      add("tap", { x: 0.5, y: 0.5 });
      add("wait", { ms: 1000 });
      add("screenshot", { save_as: "result" });
    }
    add("notify", { message: "Workflow đã chạy xong", level: "success" });
    workflow.blocks = blocks;
    workflow.connections = blocks.slice(0, -1).map((block, index) => ({ from: block.id, to: blocks[index + 1].id, port: "next" }));
    return global.HidWorkflowBlocks.normalizeWorkflow(workflow);
  }

  global.HidAiPrompts = {
    SystemPrompt,
    Examples,
    localWorkflowFromPrompt,
  };
})(window);
