# Prompt dua cho Codex build Windows EXE

Hay doc toan bo goi source nay va dong goi thanh app Windows `.exe` ten `HIDProbeUSBLocalController.exe`.

Bat buoc:

- Giu UI web trong `source/web` gan 100%.
- Khong them bang countdown Lua OK tren app Windows.
- Countdown OK chi hien tren iPhone/HID IPA toast/HUD.
- Khong dung WDA.
- Khong dung LAN/WiFi lam duong chinh.
- Duong chinh la USB local tunnel port `17391`.
- Port logic native tu `source/mac_reference/HIDProbeUSBLocalController.swift` sang Windows.
- Neu dung WebView2/Electron, inject bridge tu:
  `window.webkit.messageHandlers.hidprobe.postMessage(msg)`
  sang native IPC Windows.

Can implement cac message tu web:

- `listDevices`
- `connect`
- `disconnect`
- `health`
- `screenshot`
- `hid`
- `lua`
- `runWorkflow`

Can implement callback ve web:

- `window.HIDProbeUSB.onDevices(devices)`
- `window.HIDProbeUSB.onTunnelStatus(text)`
- `window.HIDProbeUSB.onNativeFrame(dataBase64)`
- `window.HIDProbeUSB.onLog(message)`

Dependency Windows:

- WebView2 Runtime neu dung .NET.
- Python + pymobiledevice3 hoac libimobiledevice/iproxy.exe de forward USB.

Tieu chi PASS:

- Cam iPhone USB, Trust, app tu nhan may.
- Bam Ket noi hien stream.
- Tap/vuot tren stream dieu khien duoc iPhone.
- Gui Lua qua USB chay duoc.
- Mat ket noi thi tu reconnect.
- Khong co countdown tren UI may tinh.
