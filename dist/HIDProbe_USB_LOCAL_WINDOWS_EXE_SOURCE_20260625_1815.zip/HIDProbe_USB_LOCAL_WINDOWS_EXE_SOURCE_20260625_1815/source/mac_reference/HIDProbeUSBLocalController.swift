import AppKit
import Darwin
import Foundation
import Network
import WebKit

struct USBDevice: Hashable {
    let id: String
    let name: String
    let productType: String
    let productVersion: String
    let connectionType: String

    var jsonObject: [String: Any] {
        [
            "id": id,
            "name": name,
            "productType": productType,
            "productVersion": productVersion,
            "connectionType": connectionType,
        ]
    }
}

final class USBWebBridge: NSObject, WKScriptMessageHandler {
    private static let fallbackUSBDeviceID = "d01e75a5689c16316e2a8cac4a50907f55a9311e"
    private static let nativeQueue = DispatchQueue(label: "hidprobe.usb.native")

    weak var webView: WKWebView?
    private var devices: [USBDevice] = []
    private var selectedDeviceID = ""
    private var pollTimer: Timer?
    private var usbListInFlight = false
    private var tunnelProcess: Process?
    private var tunnelDeviceID = ""
    private var tunnelRestartInFlight = false
    private var lastTunnelStatus = ""
    private var lastDeviceSignature = ""
    private var lastForwardRecoveryAt: Date = .distantPast
    private let forwardRecoveryCooldown: TimeInterval = 8
    private let localPort: UInt16 = 17391
    private let logURL = URL(fileURLWithPath: "/tmp/hidprobe-usb-web.log")
    private var nativeConnection: NWConnection?
    private var nativeSocketFD: Int32 = -1
    private var nativeReadBuffer = Data()
    private var nativeStreamDeviceID = ""
    private var nativeStreamReady = false
    private var nativeConnectInFlight = false
    private var nativeConnectStartedAt: Date = .distantPast
    private var nativeSeq: UInt32 = 0

    func start() {
        debugLog("bridge.start")
        pollDevices(reason: "startup")
        pollTimer?.invalidate()
        let timer = Timer(timeInterval: 5.0, repeats: true) { [weak self] _ in
            self?.pollDevices(reason: "poll")
        }
        RunLoop.main.add(timer, forMode: .common)
        pollTimer = timer
        ensureTunnel(reason: "startup")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            self?.pollDevices(reason: "delayed_start")
            self?.ensureTunnel(reason: "delayed_start")
        }
    }

    func stop() {
        pollTimer?.invalidate()
        pollTimer = nil
        terminateTunnel()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "hidprobe" else { return }
        guard let body = message.body as? [String: Any] else { return }
        let type = String(body["type"] as? String ?? "")
        switch type {
        case "listDevices":
            pollDevices(reason: "web")
        case "connectDevice":
            let id = String(body["device_id"] as? String ?? body["id"] as? String ?? "")
            if !id.isEmpty {
                if id == selectedDeviceID, tunnelRestartInFlight || (tunnelProcess?.isRunning == true) {
                    ensureTunnel(reason: "web_connect_existing")
                    return
                }
                selectedDeviceID = id
                restartTunnel(reason: "web_connect")
            } else {
                ensureTunnel(reason: "web_connect_no_id")
            }
        case "disconnectAll":
            terminateTunnel()
            emitTunnel("USB tunnel: stopped")
        case "ensureTunnel":
            let reason = String(body["reason"] as? String ?? "web")
            ensureTunnel(reason: reason)
        case "requestNativeFrame":
            let reason = String(body["reason"] as? String ?? "manual_frame")
            ensureTunnel(reason: reason)
            if nativeStreamReady {
                sendNativeHello(reason: reason)
            }
        case "sendNativeHID":
            guard let payload = body["payload"] as? [String: Any] else { return }
            sendNativeHID(payload)
        case "runNativeLua":
            let lua = String(body["lua"] as? String ?? "")
            let name = String(body["name"] as? String ?? "USB native script")
            let id = String(body["id"] as? String ?? "usb-native-\(Int(Date().timeIntervalSince1970))")
            runNativeLua(id: id, lua: lua, name: name)
        default:
            break
        }
    }

    private func pollDevices(reason: String) {
        guard !usbListInFlight else { return }
        guard let pmdPath = resolvePymobiledevicePath() else {
            debugLog("pollDevices \(reason): pymobiledevice3 missing")
            emitLog("Khong tim thay pymobiledevice3.")
            emitDevices([])
            return
        }
        debugLog("pollDevices \(reason): \(pmdPath)")
        usbListInFlight = true
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let readDevices = Self.readUSBDevices(pmdPath: pmdPath)
            DispatchQueue.main.async {
                guard let self else { return }
                self.usbListInFlight = false
                let effectiveDevices = readDevices.isEmpty ? [Self.autoUSBDevice()] : readDevices
                self.debugLog("pollDevices \(reason): found \(readDevices.count) effective=\(effectiveDevices.count)")
                self.applyDevices(effectiveDevices, reason: reason)
            }
        }
    }

    private static func autoUSBDevice() -> USBDevice {
        USBDevice(
            id: fallbackUSBDeviceID,
            name: "iPhone USB",
            productType: "iPhone8,1",
            productVersion: "",
            connectionType: "USB"
        )
    }

    private func applyDevices(_ newDevices: [USBDevice], reason: String) {
        let newSignature = deviceSignature(newDevices)
        let devicesChanged = newSignature != lastDeviceSignature
        lastDeviceSignature = newSignature
        devices = newDevices
        let deviceIDs = newDevices.map(\.id).joined(separator: ",")
        if devicesChanged || reason == "web" || reason == "startup" || reason == "delayed_start" {
            debugLog("applyDevices \(reason): \(deviceIDs)")
            emitDevices(newDevices)
        }
        if newDevices.isEmpty {
            selectedDeviceID = ""
            terminateTunnel()
            emitTunnel("USB discovery: chua thay iPhone USB, unlock va bam Trust")
            return
        }
        if selectedDeviceID.isEmpty || !newDevices.contains(where: { $0.id == selectedDeviceID }) {
            selectedDeviceID = newDevices[0].id
            restartTunnel(reason: "auto_select_\(reason)")
        } else if shouldEnsureTunnel() {
            ensureTunnel(reason: "device_poll_\(reason)")
        }
    }

    private func deviceSignature(_ devices: [USBDevice]) -> String {
        devices.map { device in
            [
                device.id,
                device.name,
                device.productType,
                device.productVersion,
                device.connectionType,
            ].joined(separator: "|")
        }.joined(separator: ";")
    }

    private func shouldEnsureTunnel() -> Bool {
        guard !selectedDeviceID.isEmpty else { return false }
        guard !tunnelRestartInFlight else { return false }
        if let tunnelProcess, tunnelProcess.isRunning, tunnelDeviceID == selectedDeviceID {
            let connectStale = nativeConnectInFlight && Date().timeIntervalSince(nativeConnectStartedAt) >= 2.0
            return !nativeStreamReady && (!nativeConnectInFlight || connectStale)
        }
        return true
    }

    private static func readUSBDevices(pmdPath: String) -> [USBDevice] {
        let process = Process()
        let quotedPMDPath = "'\(pmdPath.replacingOccurrences(of: "'", with: "'\\''"))'"
        let outputPath = "/tmp/hidprobe-usb-list-\(UUID().uuidString).json"
        let quotedOutputPath = "'\(outputPath.replacingOccurrences(of: "'", with: "'\\''"))'"
        process.executableURL = URL(fileURLWithPath: "/bin/zsh")
        process.arguments = ["-lc", "\(quotedPMDPath) --no-color usbmux list > \(quotedOutputPath) 2>/tmp/hidprobe-usbmux-list.stderr"]
        process.standardInput = FileHandle.nullDevice
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            let deadline = Date().addingTimeInterval(20.0)
            while process.isRunning && Date() < deadline {
                Thread.sleep(forTimeInterval: 0.05)
            }
            if process.isRunning {
                process.terminate()
                process.waitUntilExit()
                return []
            }
            guard process.terminationStatus == 0 else { return [] }
            defer { try? FileManager.default.removeItem(atPath: outputPath) }
            let data = (try? Data(contentsOf: URL(fileURLWithPath: outputPath))) ?? Data()
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
            return rows.compactMap { row in
                let id = String(row["Identifier"] as? String ?? row["UniqueDeviceID"] as? String ?? "")
                guard !id.isEmpty else { return nil }
                return USBDevice(
                    id: id,
                    name: String(row["DeviceName"] as? String ?? row["Name"] as? String ?? "iPhone USB"),
                    productType: String(row["ProductType"] as? String ?? ""),
                    productVersion: String(row["ProductVersion"] as? String ?? ""),
                    connectionType: String(row["ConnectionType"] as? String ?? "USB")
                )
            }
        } catch {
            return []
        }
    }

    private func restartTunnel(reason: String) {
        let hadRunningTunnel = tunnelProcess?.isRunning == true
        terminateTunnel()
        if hadRunningTunnel {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
                self?.ensureTunnel(reason: reason)
            }
        } else {
            ensureTunnel(reason: reason)
        }
    }

    private func ensureTunnel(reason: String) {
        if tunnelRestartInFlight { return }
        if let tunnelProcess, tunnelProcess.isRunning, tunnelDeviceID == selectedDeviceID {
            if isLocalHealthOK() {
                debugLog("ensureTunnel \(reason): already active \(tunnelDeviceID)")
                emitTunnel("USB native stream: active port=\(localPort)")
                startNativeStream(reason: reason)
                return
            }
            if isLocalPortListening(port: localPort) {
                debugLog("ensureTunnel \(reason): forward active, HIDProbe health not ready")
                emitTunnel("USB tunnel: forward active, mo HIDProbe tren iPhone de bat server")
                return
            }
            let now = Date()
            guard now.timeIntervalSince(lastForwardRecoveryAt) >= forwardRecoveryCooldown else {
                debugLog("ensureTunnel \(reason): forward unhealthy, recovery cooldown")
                emitTunnel("USB tunnel: reconnect cooldown, dang giu USB forward")
                return
            }
            lastForwardRecoveryAt = now
            debugLog("ensureTunnel \(reason): active forward lost port, restarting")
            emitTunnel("USB tunnel: port lost, restarting forward")
            restartTunnel(reason: "health_fail_\(reason)")
            return
        }
        if isLocalPortListening(port: localPort) {
            if isLocalHealthOK() {
                debugLog("ensureTunnel \(reason): external listener healthy")
                emitTunnel("USB native stream: external forwarder healthy port=\(localPort)")
                startNativeStream(reason: reason)
                return
            }
            let now = Date()
            guard now.timeIntervalSince(lastForwardRecoveryAt) >= forwardRecoveryCooldown else {
                debugLog("ensureTunnel \(reason): external listener unhealthy, recovery cooldown")
                emitTunnel("USB tunnel: forward active, mo HIDProbe tren iPhone de bat server")
                return
            }
            lastForwardRecoveryAt = now
            debugLog("ensureTunnel \(reason): stale listener on port \(localPort), killing forwarders")
            emitTunnel("USB tunnel: stale listener, restarting USB forward")
            killStaleForwarders()
        }
        let deviceID = selectedDeviceID.isEmpty ? devices.first?.id ?? "" : selectedDeviceID
        guard !deviceID.isEmpty else {
            debugLog("ensureTunnel \(reason): no selected device")
            emitTunnel("USB tunnel: waiting for trusted iPhone")
            return
        }
        guard let pmdPath = resolvePymobiledevicePath() else {
            debugLog("ensureTunnel \(reason): pymobiledevice3 missing")
            emitTunnel("USB tunnel: pymobiledevice3 missing")
            return
        }
        debugLog("ensureTunnel \(reason): spawning forward for \(deviceID)")
        tunnelRestartInFlight = true
        lastForwardRecoveryAt = Date()
        let process = Process()
        process.executableURL = URL(fileURLWithPath: pmdPath)
        var arguments = ["--no-color", "usbmux", "forward", "\(localPort)", "\(localPort)"]
        arguments += ["--serial", deviceID]
        process.arguments = arguments
        process.standardInput = FileHandle.nullDevice
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        process.terminationHandler = { [weak self] process in
            self?.debugLog("forward exited status=\(process.terminationStatus)")
        }
        do {
            try process.run()
            tunnelProcess = process
            tunnelDeviceID = deviceID
            emitTunnel("USB tunnel: starting port=\(localPort) device=\(shortID(deviceID)) reason=\(reason)")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in
                guard let self else { return }
                self.tunnelRestartInFlight = false
                if self.isLocalHealthOK() {
                    self.emitTunnel("USB native stream: active port=\(self.localPort)")
                    self.startNativeStream(reason: reason)
                } else if self.isLocalPortListening(port: self.localPort) {
                    self.emitTunnel("USB tunnel: forward active, mo HIDProbe tren iPhone de bat server")
                } else {
                    self.emitTunnel("USB tunnel: started, waiting for HIDProbe on iPhone")
                }
            }
        } catch {
            tunnelRestartInFlight = false
            emitTunnel("USB tunnel failed: \(error.localizedDescription)")
            debugLog("ensureTunnel \(reason): run failed \(error.localizedDescription)")
        }
    }

    private func terminateTunnel() {
        if let tunnelProcess, tunnelProcess.isRunning {
            tunnelProcess.terminate()
        }
        stopNativeStream(reason: "terminate_tunnel")
        tunnelProcess = nil
        tunnelDeviceID = ""
        tunnelRestartInFlight = false
        lastTunnelStatus = ""
    }

    private func resolvePymobiledevicePath() -> String? {
        let candidates = [
            "/Users/chung/Documents/Codex/2026-06-24/users-chung-desktop-ba-n-sao/tools/pymobiledevice3-venv/bin/pymobiledevice3",
            "/opt/homebrew/bin/pymobiledevice3",
            "/usr/local/bin/pymobiledevice3",
            "/usr/bin/pymobiledevice3",
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    private func isLocalPortListening(port: UInt16) -> Bool {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        if fd < 0 { return false }
        defer { close(fd) }
        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = port.bigEndian
        addr.sin_addr = in_addr(s_addr: inet_addr("127.0.0.1"))
        let result = withUnsafePointer(to: &addr) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockaddrPointer in
                Darwin.connect(fd, sockaddrPointer, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        return result == 0
    }

    private func isLocalHealthOK() -> Bool {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        if fd < 0 { return false }
        defer { close(fd) }

        var timeout = timeval(tv_sec: 1, tv_usec: 200_000)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = localPort.bigEndian
        addr.sin_addr = in_addr(s_addr: inet_addr("127.0.0.1"))
        let connected = withUnsafePointer(to: &addr) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockaddrPointer in
                Darwin.connect(fd, sockaddrPointer, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else { return false }

        let payload = (try? JSONSerialization.data(withJSONObject: [
            "command": "health",
            "client": "hidprobe-usb-web-health",
        ], options: [])) ?? Data("{}".utf8)
        let request = USBNativeWire.encode(type: .health, seq: 1, payload: payload)
        guard writeAll(fd: fd, data: request) else { return false }
        guard let packet = readNativePacket(fd: fd),
              packet.type == .health,
              let object = try? JSONSerialization.jsonObject(with: packet.payload) as? [String: Any] else {
            return false
        }
        return (object["ok"] as? Bool) == true
    }

    private func killStaleForwarders() {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/pkill")
        process.arguments = ["-f", "pymobiledevice3.*usbmux forward \(localPort) \(localPort)"]
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            process.waitUntilExit()
            debugLog("killStaleForwarders status=\(process.terminationStatus)")
        } catch {
            debugLog("killStaleForwarders failed err=\(error.localizedDescription)")
        }
    }

    private func emitDevices(_ devices: [USBDevice]) {
        guard let data = try? JSONSerialization.data(withJSONObject: devices.map(\.jsonObject), options: []),
              let json = String(data: data, encoding: .utf8) else { return }
        evaluate("window.HIDProbeUSB && window.HIDProbeUSB.onDevices(\(json));")
    }

    private func emitTunnel(_ status: String) {
        guard status != lastTunnelStatus else { return }
        lastTunnelStatus = status
        evaluateCall("window.HIDProbeUSB && window.HIDProbeUSB.onTunnel", argument: status)
    }

    private func emitLog(_ message: String) {
        debugLog(message)
        evaluateCall("window.HIDProbeUSB && window.HIDProbeUSB.onLog", argument: message)
    }

    private func startNativeStream(reason: String) {
        guard !selectedDeviceID.isEmpty else { return }
        if nativeStreamReady, nativeStreamDeviceID == selectedDeviceID, nativeSocketFD >= 0 {
            return
        }
        if nativeConnectInFlight, nativeStreamDeviceID == selectedDeviceID {
            if Date().timeIntervalSince(nativeConnectStartedAt) < 2.0 {
                debugLog("native stream connect already in flight reason=\(reason)")
                return
            }
            debugLog("native stream connect stale, restarting reason=\(reason)")
        }
        stopNativeStream(reason: "restart_\(reason)")
        nativeConnectInFlight = true
        nativeConnectStartedAt = Date()
        nativeStreamDeviceID = selectedDeviceID
        nativeReadBuffer.removeAll(keepingCapacity: true)
        let deviceID = selectedDeviceID
        let port = localPort
        debugLog("native socket opening port=\(port) reason=\(reason)")
        Self.nativeQueue.async { [weak self] in
            guard let self else { return }
            let fd = self.openNativeSocket(port: port)
            guard fd >= 0 else {
                self.debugLog("native socket open failed fd=\(fd) reason=\(reason)")
                DispatchQueue.main.async {
                    guard self.nativeConnectInFlight, self.nativeStreamDeviceID == deviceID else { return }
                    self.stopNativeStream(reason: "socket_open_failed")
                    self.emitTunnel("USB native stream: socket open failed")
                }
                return
            }
            self.debugLog("native socket opened fd=\(fd) reason=\(reason)")
            DispatchQueue.main.async {
                guard self.nativeConnectInFlight, self.nativeStreamDeviceID == deviceID else {
                    close(fd)
                    return
                }
                self.nativeSocketFD = fd
                self.nativeConnectInFlight = false
                self.nativeStreamReady = true
                self.emitTunnel("USB native stream: connected port=\(port)")
                self.sendNativeHello(reason: reason)
            }
            self.readNativeSocketLoop(fd: fd)
        }
    }

    private func stopNativeStream(reason: String) {
        if let nativeConnection {
            nativeConnection.cancel()
        }
        if nativeSocketFD >= 0 {
            close(nativeSocketFD)
        }
        nativeConnection = nil
        nativeSocketFD = -1
        nativeReadBuffer.removeAll(keepingCapacity: true)
        nativeStreamReady = false
        nativeConnectInFlight = false
        nativeConnectStartedAt = .distantPast
        if !reason.isEmpty {
            debugLog("native stream stopped reason=\(reason)")
        }
    }

    private func handleNativeState(_ state: NWConnection.State, connection: NWConnection, reason: String) {
        switch state {
        case .ready:
            nativeConnectInFlight = false
            nativeStreamReady = true
            emitTunnel("USB native stream: connected port=\(localPort)")
            sendNativeHello(reason: reason)
            readNativeLoop(connection: connection)
        case .failed(let error):
            debugLog("native stream failed err=\(error.localizedDescription)")
            if nativeConnection === connection {
                stopNativeStream(reason: "failed")
                emitTunnel("USB native stream: failed \(error.localizedDescription)")
            }
        case .cancelled:
            if nativeConnection === connection {
                stopNativeStream(reason: "cancelled")
            }
        case .waiting(let error):
            debugLog("native stream waiting err=\(error.localizedDescription)")
        case .preparing:
            debugLog("native stream preparing reason=\(reason)")
        default:
            break
        }
    }

    private func sendNativeHello(reason: String) {
        let payload = [
            "command": "hello",
            "client": "hidprobe-usb-web-native",
            "device_id": selectedDeviceID,
            "fps": 12,
            "quality": 0.42,
            "reason": reason,
            "wants_stream": true,
        ] as [String: Any]
        sendNativeJSON(type: .health, payload: payload)
    }

    private func sendNativeHID(_ payload: [String: Any]) {
        var normalized = payload
        normalized["device_id"] = normalized["device_id"] ?? selectedDeviceID
        normalized["sent_at"] = ISO8601DateFormatter().string(from: Date())
        guard sendNativeJSON(type: .hid, payload: normalized) else {
            emitLog("USB native HID dropped: stream not connected")
            ensureTunnel(reason: "native_hid_no_stream")
            return
        }
    }

    private func runNativeLua(id: String, lua: String, name: String) {
        let cleanID = id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "usb-native-\(Int(Date().timeIntervalSince1970))"
            : id
        let store: [String: Any] = [
            "action": "store_script",
            "id": cleanID,
            "script_id": cleanID,
            "lua": lua,
            "name": name,
            "language": "lua",
        ]
        let run: [String: Any] = [
            "action": "run_script",
            "script_id": cleanID,
            "trigger": "usb_native_web",
        ]
        guard sendNativeJSON(type: .script, payload: store) else {
            emitLog("USB native Lua dropped: stream not connected")
            ensureTunnel(reason: "native_lua_no_stream")
            return
        }
        _ = sendNativeJSON(type: .script, payload: run)
    }

    @discardableResult
    private func sendNativeJSON(type: USBNativeMessageType, payload: [String: Any]) -> Bool {
        guard nativeStreamReady, nativeSocketFD >= 0 else { return false }
        let body = (try? JSONSerialization.data(withJSONObject: payload, options: [])) ?? Data("{}".utf8)
        nativeSeq &+= 1
        let packet = USBNativeWire.encode(type: type, seq: nativeSeq, payload: body)
        let fd = nativeSocketFD
        guard writeAll(fd: fd, data: packet) else {
            debugLog("native socket send failed")
            stopNativeStream(reason: "socket_send_failed")
            ensureTunnel(reason: "socket_send_failed")
            return false
        }
        return true
    }

    private func openNativeSocket(port: UInt16) -> Int32 {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        if fd < 0 { return -1 }
        let originalFlags = fcntl(fd, F_GETFL, 0)
        if originalFlags >= 0 {
            _ = fcntl(fd, F_SETFL, originalFlags | O_NONBLOCK)
        }
        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = port.bigEndian
        addr.sin_addr = in_addr(s_addr: inet_addr("127.0.0.1"))
        let result = withUnsafePointer(to: &addr) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockaddrPointer in
                Darwin.connect(fd, sockaddrPointer, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        if result != 0 && errno != EINPROGRESS {
            close(fd)
            return -1
        }
        if result != 0 {
            var pfd = pollfd(fd: fd, events: Int16(POLLOUT), revents: 0)
            guard poll(&pfd, 1, 2_000) > 0, (pfd.revents & Int16(POLLOUT)) != 0 else {
                close(fd)
                return -1
            }
            var socketError: Int32 = 0
            var socketErrorLength = socklen_t(MemoryLayout<Int32>.size)
            let ok = withUnsafeMutablePointer(to: &socketError) { pointer in
                getsockopt(fd, SOL_SOCKET, SO_ERROR, pointer, &socketErrorLength)
            }
            guard ok == 0, socketError == 0 else {
                close(fd)
                return -1
            }
        }
        if originalFlags >= 0 {
            _ = fcntl(fd, F_SETFL, originalFlags)
        }
        return fd
    }

    private func readNativeSocketLoop(fd: Int32) {
        while true {
            guard let packet = readNativePacket(fd: fd) else { break }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.nativeSocketFD == fd else { return }
                self.handleNativePacket(packet)
            }
        }
        DispatchQueue.main.async { [weak self] in
            guard let self, self.nativeSocketFD == fd else { return }
            self.debugLog("native socket read loop ended")
            self.stopNativeStream(reason: "socket_read_closed")
            self.ensureTunnel(reason: "socket_read_closed")
        }
    }

    private func readNativeLoop(connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 256 * 1024) { [weak self, weak connection] data, _, isComplete, error in
            DispatchQueue.main.async {
                guard let self, let connection, self.nativeConnection === connection else { return }
                if let data, !data.isEmpty {
                    self.nativeReadBuffer.append(data)
                    self.consumeNativeBuffer()
                }
                if isComplete || error != nil {
                    self.debugLog("native read closed err=\(error?.localizedDescription ?? "complete")")
                    self.stopNativeStream(reason: "read_closed")
                    self.emitTunnel("USB native stream: disconnected")
                    return
                }
                self.readNativeLoop(connection: connection)
            }
        }
    }

    private func consumeNativeBuffer() {
        while true {
            switch USBNativeWire.nextPacket(from: &nativeReadBuffer) {
            case .success(let packet):
                handleNativePacket(packet)
            case .needMore:
                return
            case .invalid:
                stopNativeStream(reason: "bad_packet")
                emitTunnel("USB native stream: bad packet")
                return
            }
        }
    }

    private func handleNativePacket(_ packet: USBNativePacket) {
        switch packet.type {
        case .health:
            emitTunnel("USB native stream: health ok port=\(localPort)")
        case .frame:
            emitNativeFrame(packet)
        case .ack:
            if let object = try? JSONSerialization.jsonObject(with: packet.payload) as? [String: Any],
               let kind = object["kind"] as? String, kind != "hid_ack" {
                emitLog("USB native ack \(kind)")
            }
        case .hid, .script:
            break
        }
    }

    private func emitNativeFrame(_ packet: USBNativePacket) {
        let payload: [String: Any] = [
            "seq": packet.seq,
            "mime": "image/jpeg",
            "dataBase64": packet.payload.base64EncodedString(),
            "receivedAt": ISO8601DateFormatter().string(from: Date()),
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: payload, options: []),
              let json = String(data: data, encoding: .utf8) else { return }
        evaluate("window.HIDProbeUSB && window.HIDProbeUSB.onNativeFrame && window.HIDProbeUSB.onNativeFrame(\(json));")
    }

    private func evaluateCall(_ function: String, argument: String) {
        guard let data = try? JSONSerialization.data(withJSONObject: [argument], options: []),
              let json = String(data: data, encoding: .utf8) else { return }
        evaluate("\(function)(\(json.dropFirst().dropLast()));")
    }

    private func evaluate(_ script: String) {
        DispatchQueue.main.async { [weak self] in
            self?.webView?.evaluateJavaScript(script, completionHandler: nil)
        }
    }

    private func writeAll(fd: Int32, data: Data) -> Bool {
        let bytes = [UInt8](data)
        var offset = 0
        while offset < bytes.count {
            let written = bytes.withUnsafeBytes { rawBuffer in
                Darwin.write(fd, rawBuffer.baseAddress!.advanced(by: offset), bytes.count - offset)
            }
            if written <= 0 { return false }
            offset += written
        }
        return true
    }

    private func readNativePacket(fd: Int32) -> USBNativePacket? {
        var header = [UInt8](repeating: 0, count: USBNativeWire.headerLength)
        guard readExact(fd: fd, into: &header, count: header.count) else { return nil }
        guard let envelope = USBNativeWire.parseHeader(header) else { return nil }
        guard envelope.length <= 16 * 1024 * 1024 else { return nil }
        var payload = [UInt8](repeating: 0, count: envelope.length)
        guard envelope.length == 0 || readExact(fd: fd, into: &payload, count: envelope.length) else { return nil }
        return USBNativePacket(type: envelope.type, flags: envelope.flags, seq: envelope.seq, payload: Data(payload))
    }

    private func readExact(fd: Int32, into buffer: inout [UInt8], count: Int) -> Bool {
        var offset = 0
        while offset < count {
            let readCount = buffer.withUnsafeMutableBytes { rawBuffer in
                Darwin.read(fd, rawBuffer.baseAddress!.advanced(by: offset), count - offset)
            }
            if readCount <= 0 { return false }
            offset += readCount
        }
        return true
    }

    private func shortID(_ id: String) -> String {
        if id.count <= 12 { return id }
        return "\(id.prefix(7))...\(id.suffix(5))"
    }

    private func debugLog(_ message: String) {
        let line = "[\(ISO8601DateFormatter().string(from: Date()))] \(message)\n"
        guard let data = line.data(using: .utf8) else { return }
        if FileManager.default.fileExists(atPath: logURL.path),
           let handle = try? FileHandle(forWritingTo: logURL) {
            defer { try? handle.close() }
            _ = try? handle.seekToEnd()
            try? handle.write(contentsOf: data)
        } else {
            try? data.write(to: logURL)
        }
    }
}

private enum USBNativeMessageType: UInt8 {
    case health = 1
    case frame = 2
    case hid = 3
    case ack = 4
    case script = 5
}

private struct USBNativePacket {
    let type: USBNativeMessageType
    let flags: UInt16
    let seq: UInt32
    let payload: Data
}

private enum USBNativeReadResult {
    case success(USBNativePacket)
    case needMore
    case invalid
}

private enum USBNativeWire {
    static let headerLength = 16
    private static let magic = Array("HPB1".utf8)
    private static let version: UInt8 = 1
    private static let maxPayloadLength = 16 * 1024 * 1024

    struct Header {
        let type: USBNativeMessageType
        let flags: UInt16
        let seq: UInt32
        let length: Int
    }

    static func encode(type: USBNativeMessageType, seq: UInt32, flags: UInt16 = 0, payload: Data) -> Data {
        var data = Data()
        data.append(contentsOf: magic)
        data.append(version)
        data.append(type.rawValue)
        appendUInt16(flags, to: &data)
        appendUInt32(seq, to: &data)
        appendUInt32(UInt32(payload.count), to: &data)
        data.append(payload)
        return data
    }

    static func nextPacket(from buffer: inout Data) -> USBNativeReadResult {
        guard buffer.count >= headerLength else { return .needMore }
        let headerBytes = Array(buffer.prefix(headerLength))
        guard let header = parseHeader(headerBytes) else { return .invalid }
        guard header.length <= maxPayloadLength else { return .invalid }
        guard buffer.count >= headerLength + header.length else { return .needMore }
        let payload = Data(buffer[headerLength..<(headerLength + header.length)])
        buffer.removeSubrange(0..<(headerLength + header.length))
        return .success(USBNativePacket(type: header.type, flags: header.flags, seq: header.seq, payload: payload))
    }

    static func parseHeader(_ bytes: [UInt8]) -> Header? {
        guard bytes.count >= headerLength else { return nil }
        guard Array(bytes[0..<4]) == magic, bytes[4] == version else { return nil }
        guard let type = USBNativeMessageType(rawValue: bytes[5]) else { return nil }
        return Header(
            type: type,
            flags: readUInt16(bytes, offset: 6),
            seq: readUInt32(bytes, offset: 8),
            length: Int(readUInt32(bytes, offset: 12))
        )
    }

    private static func appendUInt16(_ value: UInt16, to data: inout Data) {
        data.append(UInt8((value >> 8) & 0xff))
        data.append(UInt8(value & 0xff))
    }

    private static func appendUInt32(_ value: UInt32, to data: inout Data) {
        data.append(UInt8((value >> 24) & 0xff))
        data.append(UInt8((value >> 16) & 0xff))
        data.append(UInt8((value >> 8) & 0xff))
        data.append(UInt8(value & 0xff))
    }

    private static func readUInt16(_ bytes: [UInt8], offset: Int) -> UInt16 {
        (UInt16(bytes[offset]) << 8) | UInt16(bytes[offset + 1])
    }

    private static func readUInt32(_ bytes: [UInt8], offset: Int) -> UInt32 {
        (UInt32(bytes[offset]) << 24)
            | (UInt32(bytes[offset + 1]) << 16)
            | (UInt32(bytes[offset + 2]) << 8)
            | UInt32(bytes[offset + 3])
    }
}

final class HIDProbeUSBLocalWebApp: NSObject, NSApplicationDelegate, WKNavigationDelegate {
    private var window: NSWindow!
    private let bridge = USBWebBridge()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApplication.shared.setActivationPolicy(.regular)

        let userContent = WKUserContentController()
        userContent.add(bridge, name: "hidprobe")

        let config = WKWebViewConfiguration()
        config.userContentController = userContent
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.allowsAirPlayForMediaPlayback = false

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        bridge.webView = webView

        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 1500, height: 940),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "HIDProbe USB Local Controller"
        window.center()
        window.contentView = webView
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        loadWebUI(in: webView)
        bridge.start()
    }

    func applicationWillTerminate(_ notification: Notification) {
        bridge.stop()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }

    private func loadWebUI(in webView: WKWebView) {
        guard let resourceURL = Bundle.main.resourceURL else {
            showInlineError(webView, message: "Khong tim thay app resources.")
            return
        }
        let webRoot = resourceURL.appendingPathComponent("web", isDirectory: true)
        let htmlURL = webRoot.appendingPathComponent("webrtc_multi_viewer_usb.html")
        if FileManager.default.fileExists(atPath: htmlURL.path) {
            webView.loadFileURL(htmlURL, allowingReadAccessTo: webRoot)
        } else {
            showInlineError(webView, message: "Thieu webrtc_multi_viewer_usb.html trong Resources/web.")
        }
    }

    private func showInlineError(_ webView: WKWebView, message: String) {
        let html = """
        <html><body style="font:16px -apple-system;padding:24px">
        <h2>HIDProbe USB Local Controller</h2>
        <p>\(message)</p>
        </body></html>
        """
        webView.loadHTMLString(html, baseURL: nil)
    }
}

@main
struct HIDProbeUSBLocalMain {
    static func main() {
        let app = NSApplication.shared
        let delegate = HIDProbeUSBLocalWebApp()
        app.delegate = delegate
        app.run()
        _ = delegate
    }
}
