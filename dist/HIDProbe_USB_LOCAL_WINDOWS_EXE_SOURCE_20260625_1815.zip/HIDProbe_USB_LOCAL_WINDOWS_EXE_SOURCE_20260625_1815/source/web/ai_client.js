"use strict";

(function attachAiClient(global) {
  function extractJson(text) {
    const raw = String(text || "").trim();
    const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const candidate = fenced ? fenced[1] : raw;
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");
    if (start < 0 || end < start) throw new Error("AI không trả JSON object");
    return candidate.slice(start, end + 1);
  }

  function mapApiError(status) {
    if (status === 401 || status === 403) return "Sai API key hoặc key không có quyền";
    if (status === 429) return "Rate limited, đợi 1 phút rồi thử lại";
    if (status >= 500) return "Lỗi server AI, thử lại sau";
    return `API lỗi HTTP ${status}`;
  }

  class AIClient {
    constructor(settings) {
      this.settings = settings || global.HidWorkflowStorage.loadAiSettings();
    }

    async testConnection() {
      try {
        await this.generate("Tạo workflow test gồm tap giữa rồi notify xong", { timeoutMs: 15000 });
        return { ok: true };
      } catch (error) {
        return { ok: false, error: error.message || String(error) };
      }
    }

    async generate(userPrompt, options = {}) {
      const prompt = String(userPrompt || "").slice(0, 4000);
      const started = performance.now();
      if (!this.settings.apiKey || this.settings.provider === "local") {
        const workflow = global.HidAiPrompts.localWorkflowFromPrompt(prompt);
        return {
          workflow,
          duration_ms: Math.round(performance.now() - started),
          tokens_used: { input: Math.ceil(prompt.length / 4), output: JSON.stringify(workflow).length / 4 },
          raw_response: JSON.stringify(workflow, null, 2),
          explanation: "Local generator: không dùng API key.",
        };
      }
      const raw = await this.callProvider(prompt, options.timeoutMs || 30000);
      const workflow = global.HidWorkflowBlocks.normalizeWorkflow(JSON.parse(extractJson(raw.text)));
      return {
        workflow,
        duration_ms: Math.round(performance.now() - started),
        tokens_used: raw.usage || { input: Math.ceil(prompt.length / 4), output: Math.ceil(raw.text.length / 4) },
        raw_response: raw.text,
        explanation: raw.explanation || "",
      };
    }

    async callProvider(userPrompt, timeoutMs) {
      const provider = String(this.settings.provider || "local");
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      try {
        if (provider === "openai") return await this.callOpenAI(userPrompt, controller.signal);
        if (provider === "gemini") return await this.callGemini(userPrompt, controller.signal);
        if (provider === "anthropic") return await this.callAnthropic(userPrompt, controller.signal);
        throw new Error(`Provider chưa hỗ trợ: ${provider}`);
      } finally {
        clearTimeout(timeout);
      }
    }

    async callOpenAI(userPrompt, signal) {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        signal,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${this.settings.apiKey}`,
        },
        body: JSON.stringify({
          model: this.settings.model || "gpt-4o-mini",
          temperature: this.settings.temperature ?? 0.3,
          max_tokens: this.settings.maxTokens || 4096,
          messages: [
            { role: "system", content: this.settings.promptTemplate || global.HidAiPrompts.SystemPrompt },
            { role: "user", content: userPrompt },
          ],
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error?.message || mapApiError(response.status));
      return { text: data.choices?.[0]?.message?.content || "", usage: data.usage };
    }

    async callAnthropic(userPrompt, signal) {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal,
        headers: {
          "Content-Type": "application/json",
          "x-api-key": this.settings.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: this.settings.model || "claude-3-5-sonnet-latest",
          temperature: this.settings.temperature ?? 0.3,
          max_tokens: this.settings.maxTokens || 4096,
          system: this.settings.promptTemplate || global.HidAiPrompts.SystemPrompt,
          messages: [{ role: "user", content: userPrompt }],
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error?.message || mapApiError(response.status));
      return { text: (data.content || []).map((part) => part.text || "").join("\n"), usage: data.usage };
    }

    async callGemini(userPrompt, signal) {
      const model = this.settings.model || "gemini-pro";
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(this.settings.apiKey)}`;
      const response = await fetch(url, {
        method: "POST",
        signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${this.settings.promptTemplate || global.HidAiPrompts.SystemPrompt}\n\nUSER PROMPT:\n${userPrompt}` }] }],
          generationConfig: { temperature: this.settings.temperature ?? 0.3, maxOutputTokens: this.settings.maxTokens || 4096 },
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error?.message || mapApiError(response.status));
      return { text: data.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("\n") || "", usage: data.usageMetadata };
    }
  }

  global.HidAiClient = {
    AIClient,
    extractJson,
  };
})(window);
