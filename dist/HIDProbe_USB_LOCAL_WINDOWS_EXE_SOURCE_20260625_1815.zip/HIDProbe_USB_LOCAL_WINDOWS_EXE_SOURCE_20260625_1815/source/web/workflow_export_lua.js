"use strict";

(function attachWorkflowScriptExport(global) {
  function escapeLuaString(value) {
    return String(value ?? "").replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\n/g, "\\n");
  }

  function parseNumber(value) {
    if (typeof value === "number") return value;
    const text = String(value ?? "").trim();
    const normalized = text && !text.includes(".") && text.includes(",")
      ? text.replace(",", ".")
      : text;
    return Number(normalized);
  }

  function number(value, fallback = 0.5) {
    const parsed = parseNumber(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(Math.max(parsed, 0), 1);
  }

  function positiveInt(value, fallback, min = 1, max = 3600000) {
    return global.HidWorkflowBlocks.asPositiveInt(value, fallback, min, max);
  }

  function threshold(value, fallback = 0.9) {
    const parsed = parseNumber(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(Math.max(parsed, 0.01), 1);
  }

  function profileName(value, fallback = "hidprobe-v1") {
    const text = String(value || fallback || "hidprobe-v1").trim().toLowerCase();
    return text || fallback;
  }

  function usesIOSControlAPI(apiProfile) {
    return ["ioscontrol-v1", "xxtouch-v1"].includes(profileName(apiProfile));
  }

  function luaNumber(value, decimals = 3) {
    const parsed = parseNumber(value);
    const safe = Number.isFinite(parsed) ? parsed : 0;
    return safe.toFixed(decimals).replace(/\.?0+$/, "") || "0";
  }

  function stripVietnameseMarks(value) {
    return String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d")
      .replace(/Đ/g, "D");
  }

  function textSearchVariants(value) {
    const raw = String(value ?? "").replace(/\s+/g, " ").trim();
    const plain = stripVietnameseMarks(raw).replace(/\s+/g, " ").trim();
    const seen = new Set();
    const variants = [];
    for (const candidate of [plain, raw]) {
      if (!candidate) continue;
      const key = candidate.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      variants.push(candidate);
    }
    return variants.length ? variants : [raw];
  }

  function luaStringTable(values) {
    return `{ ${values.map((value) => `"${escapeLuaString(value)}"`).join(", ")} }`;
  }

  function imageParamAsset(params = {}, key = "image", context = {}) {
    const path = String(params?.[key] || "").trim();
    if (!path || !context?.assetByPath) return null;
    return context.assetByPath.get(path) || null;
  }

  function imageAssetByPath(path, context = {}) {
    const wanted = String(path || "").trim();
    if (!wanted || !context?.assetByPath) return null;
    return context.assetByPath.get(wanted) || null;
  }

  function isNativeCropAsset(asset) {
    const source = String(asset?.source || "").trim().toLowerCase();
    const path = String(asset?.path || asset?.name || "").trim().toLowerCase();
    return source === "iphone_native_crop" || path.startsWith("native_crop_");
  }

  function imageListFromValue(value) {
    if (Array.isArray(value)) {
      return value.map((item) => String(item || "").trim()).filter(Boolean);
    }
    return String(value || "")
      .split(/[\n,|]+/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  function uniqueImageList(list) {
    const seen = new Set();
    const out = [];
    for (const item of list || []) {
      const path = String(item || "").trim();
      if (!path || seen.has(path)) continue;
      seen.add(path);
      out.push(path);
    }
    return out;
  }

  function conditionImagePaths(params = {}) {
    return uniqueImageList([
      String(params.condition_image || "").trim(),
      ...imageListFromValue(params.condition_images),
    ]);
  }

  function smartImageAnchorRadius(asset, fallback = 0.16) {
    const width = Number(asset?.width || 0) || 0;
    const height = Number(asset?.height || 0) || 0;
    const maxPx = Math.max(width, height);
    if (maxPx > 0 && maxPx < 100) return 0.05;
    if (maxPx > 0 && maxPx < 200) return 0.08;

    const crop = asset?.crop_norm || {};
    const cropMax = Math.max(Number(crop.width || 0) || 0, Number(crop.height || 0) || 0);
    if (cropMax > 0 && cropMax < 0.08) return 0.05;
    if (cropMax > 0 && cropMax < 0.16) return 0.08;
    return fallback;
  }

  function imageAssetMaxSide(asset) {
    const width = Number(asset?.width || 0) || 0;
    const height = Number(asset?.height || 0) || 0;
    if (width > 0 && height > 0) return Math.max(width, height);

    const sourceWidth = Number(asset?.source_width || 0) || 0;
    const sourceHeight = Number(asset?.source_height || 0) || 0;
    const crop = asset?.crop_norm || {};
    const cropWidth = Number(crop.width || 0) || 0;
    const cropHeight = Number(crop.height || 0) || 0;
    if (sourceWidth > 0 && sourceHeight > 0 && cropWidth > 0 && cropHeight > 0) {
      return Math.max(sourceWidth * cropWidth, sourceHeight * cropHeight);
    }

    return 0;
  }

  function isSmallImageAsset(asset) {
    const maxPx = imageAssetMaxSide(asset);
    if (maxPx > 0) return maxPx <= 160;

    const crop = asset?.crop_norm || {};
    const cropMax = Math.max(Number(crop.width || 0) || 0, Number(crop.height || 0) || 0);
    return cropMax > 0 && cropMax <= 0.16;
  }

  function imageThresholdForParam(params = {}, key = "image", value, context = {}, fallback = 0.95, forceSmallStrict = true) {
    const base = threshold(value, fallback);
    const asset = imageParamAsset(params, key, context);
    if (isNativeCropAsset(asset)) return Math.min(base, 0.85);
    if (forceSmallStrict && isSmallImageAsset(asset)) return Math.max(base, 0.97);
    return base;
  }

  function imageThresholdForPath(path, value, context = {}, fallback = 0.95, forceSmallStrict = true) {
    const base = threshold(value, fallback);
    const asset = imageAssetByPath(path, context);
    if (isNativeCropAsset(asset)) return Math.min(base, 0.85);
    if (forceSmallStrict && isSmallImageAsset(asset)) return Math.max(base, 0.97);
    return base;
  }

  function imageAnchor(params = {}, context = {}) {
    return imageAnchorFor(params, "image", context);
  }

  function imageAnchorFor(params = {}, key = "image", context = {}) {
    const x = parseNumber(params[`${key}_anchor_x`]);
    const y = parseNumber(params[`${key}_anchor_y`]);
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 1 || y < 0 || y > 1) return null;
    const radius = parseNumber(params[`${key}_anchor_radius`]);
    const asset = imageParamAsset(params, key, context);
    const explicitRadius = Number.isFinite(radius) && radius > 0 ? Math.min(Math.max(radius, 0.02), 0.5) : 0.16;
    return {
      x,
      y,
      radius: Math.min(explicitRadius, smartImageAnchorRadius(asset, explicitRadius)),
    };
  }

  function imageAnchorForPath(path, context = {}) {
    const asset = imageAssetByPath(path, context);
    const crop = asset?.crop_norm || {};
    const x = Number(crop.center_x);
    const y = Number(crop.center_y);
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 1 || y < 0 || y > 1) return null;
    return {
      x,
      y,
      radius: smartImageAnchorRadius(asset, 0.16),
    };
  }

  function imageKeyForSearchPrefix(prefix = "") {
    const key = String(prefix || "").trim();
    if (!key || key === "image") return "image";
    if (key === "condition") return "condition_image";
    if (key === "target") return "target_image";
    if (key === "first") return "first_image";
    if (key === "second") return "second_image";
    if (key === "first_target") return "first_target_image";
    if (key === "second_target") return "second_target_image";
    return key.endsWith("_image") ? key : `${key}_image`;
  }

  function imageAnchorSearchPoint(params = {}, prefix = "", context = {}) {
    const key = imageKeyForSearchPrefix(prefix);
    const anchor = imageAnchorFor(params, key, context);
    if (!anchor) return null;
    return {
      x: anchor.x,
      y: anchor.y,
      radius_norm: anchor.radius,
    };
  }

  function truthy(value) {
    if (typeof value === "boolean") return value;
    const text = String(value ?? "").trim().toLowerCase();
    return ["1", "true", "yes", "on"].includes(text);
  }

  function firstPresent(params = {}, keys = []) {
    for (const key of keys) {
      if (!Object.prototype.hasOwnProperty.call(params, key)) continue;
      const value = params[key];
      if (value === undefined || value === null) continue;
      if (typeof value === "string" && !value.trim()) continue;
      return value;
    }
    return undefined;
  }

  function prefixedParam(params = {}, prefix, names = []) {
    const keys = [];
    if (prefix) {
      for (const name of names) keys.push(`${prefix}_${name}`);
    }
    keys.push(...names);
    return firstPresent(params, keys);
  }

  function normalizeSearchMode(value, fallback = "") {
    const text = String(value ?? "").trim().toLowerCase().replace(/[\s-]+/g, "_");
    if (!text) return fallback;
    if ([
      "roi_only",
      "only_roi",
      "manual_roi_only",
      "saved_roi_only",
      "regions_only",
      "points_only",
      "manual_regions_only",
      "no_fallback",
    ].includes(text)) return "roi_only";
    if ([
      "prefer_roi",
      "roi_first",
      "prefer_saved_roi",
      "saved_roi",
      "manual_roi",
      "manual_regions",
      "roi",
      "auto_roi",
      "prefer_regions_then_full",
      "regions_then_full",
      "roi_then_full",
      "regions_first",
      "points_first",
    ].includes(text)) return "prefer_roi";
    if (["full", "full_screen", "fullscreen", "screen", "default"].includes(text)) return "full";
    return fallback;
  }

  function parseMaybeJson(value) {
    if (typeof value !== "string") return value;
    const text = value.trim();
    if (!text) return null;
    if (!/^[\[{]/.test(text)) return value;
    try {
      return JSON.parse(text);
    } catch (_) {
      return value;
    }
  }

  function rawPointList(value) {
    const parsed = parseMaybeJson(value);
    if (!parsed) return [];
    if (Array.isArray(parsed)) return parsed;
    if (typeof parsed === "object") {
      for (const key of ["search_points", "points", "rois", "roi", "regions", "search_regions", "manual_rois", "manualROIs"]) {
        if (Array.isArray(parsed[key])) return parsed[key];
      }
      return [parsed];
    }
    return String(parsed)
      .split(/[\n;|]+/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const parts = line.split(/[,\s]+/).map((part) => Number(part)).filter((part) => Number.isFinite(part));
        return parts.length ? parts : null;
      })
      .filter(Boolean);
  }

  function finiteNumber(...values) {
    for (const value of values) {
      const parsed = parseNumber(value);
      if (Number.isFinite(parsed)) return parsed;
    }
    return null;
  }

  function clampNumber(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function normalizeSearchPoint(raw) {
    const item = Array.isArray(raw)
      ? { x: raw[0], y: raw[1], radius_norm: raw[2], radius_px: raw[3] }
      : (raw || {});
    let x = finiteNumber(item.x, item.norm_x, item.center_x, item.cx);
    let y = finiteNumber(item.y, item.norm_y, item.center_y, item.cy);
    const width = finiteNumber(item.width, item.w);
    const height = finiteNumber(item.height, item.h);
    const x2 = finiteNumber(item.x2, item.right);
    const y2 = finiteNumber(item.y2, item.bottom);

    if ((x == null || y == null) && width != null && height != null) {
      const left = finiteNumber(item.left, item.x) ?? 0;
      const top = finiteNumber(item.top, item.y) ?? 0;
      x = left + width / 2;
      y = top + height / 2;
    } else if (x != null && y != null && x2 != null && y2 != null) {
      x = (x + x2) / 2;
      y = (y + y2) / 2;
    }

    if (x == null || y == null) return null;
    const radiusNorm = finiteNumber(
      item.radius_norm,
      item.radius,
      item.r,
      item.search_radius_norm,
      width != null || height != null ? Math.max(width || 0, height || 0) / 2 : null,
      x2 != null || y2 != null ? Math.max(Math.abs((x2 ?? x) - x), Math.abs((y2 ?? y) - y)) : null
    );
    const radiusPx = finiteNumber(item.radius_px, item.radiusPx, item.search_radius_px);
    const point = {
      x: clampNumber(x, 0, 1),
      y: clampNumber(y, 0, 1),
    };
    if (radiusNorm != null && radiusNorm > 0) point.radius_norm = clampNumber(radiusNorm, 0.001, 1);
    if (radiusPx != null && radiusPx > 0) point.radius_px = Math.round(clampNumber(radiusPx, 1, 10000));
    return point;
  }

  function searchPointsFromValue(value) {
    return rawPointList(value).map(normalizeSearchPoint).filter(Boolean);
  }

  function uniqueSearchPoints(points) {
    const seen = new Set();
    const out = [];
    for (const point of points || []) {
      const key = [
        luaNumber(point.x, 6),
        luaNumber(point.y, 6),
        point.radius_norm == null ? "" : luaNumber(point.radius_norm, 6),
        point.radius_px == null ? "" : String(point.radius_px),
      ].join(":");
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(point);
    }
    return out;
  }

  function imageSearchOptions(params = {}, prefix = "", context = {}) {
    const modeRaw = prefixedParam(params, prefix, ["search_mode", "image_search_mode"]);
    const intervalRaw = prefixedParam(params, prefix, ["interval_ms", "intervalMs", "poll_interval_ms", "pollIntervalMs"]) ?? params.interval_ms ?? params.intervalMs;
    const intervalMs = positiveInt(intervalRaw, 0, 0, 60000);
    const anchorPoint = imageAnchorSearchPoint(params, prefix, context);
    const imageKey = imageKeyForSearchPrefix(prefix);
    const asset = imageParamAsset(params, imageKey, context);
    const points = uniqueSearchPoints([
      ...(anchorPoint ? [anchorPoint] : []),
      ...searchPointsFromValue(prefixedParam(params, prefix, ["search_points", "points", "manual_rois"])),
      ...searchPointsFromValue(prefixedParam(params, prefix, ["roi", "rois", "region", "regions", "search_roi", "search_regions"])),
    ]);
    const thresholdMode = isNativeCropAsset(asset) ? "normal" : "";
    const hasConfig = modeRaw !== undefined || points.length > 0 || intervalMs > 0 || thresholdMode;
    if (!hasConfig) return null;

    let mode = normalizeSearchMode(modeRaw, points.length ? "prefer_roi" : "full");
    if (anchorPoint && mode === "full") {
      mode = "prefer_roi";
    }
    const fallback = mode === "roi_only" ? "none" : (mode === "prefer_roi" ? "full_screen" : "full_screen");
    return {
      mode,
      points,
      fallback,
      allowFullscreenFallback: mode !== "roi_only",
      intervalMs,
      thresholdMode,
    };
  }

  function luaSearchPoint(point) {
    const fields = [
      `x = ${luaNumber(point.x, 6)}`,
      `y = ${luaNumber(point.y, 6)}`,
      `center_x = ${luaNumber(point.x, 6)}`,
      `center_y = ${luaNumber(point.y, 6)}`,
    ];
    if (point.radius_norm != null) {
      fields.push(`radius = ${luaNumber(point.radius_norm, 6)}`);
      fields.push(`radius_norm = ${luaNumber(point.radius_norm, 6)}`);
    }
    if (point.radius_px != null) fields.push(`radius_px = ${point.radius_px}`);
    return `{ ${fields.join(", ")} }`;
  }

  function luaImageSearchOptions(options) {
    const pointRows = (options.points || []).map(luaSearchPoint);
    const pointsTable = `{ ${pointRows.join(", ")} }`;
    return [
      "{",
      `  search_mode = "${escapeLuaString(options.mode)}",`,
      `  mode = "${escapeLuaString(options.mode)}",`,
      `  fallback = "${escapeLuaString(options.fallback)}",`,
      `  allow_fullscreen_fallback = ${options.allowFullscreenFallback ? "true" : "false"},`,
      ...(options.thresholdMode ? [
        `  threshold_mode = "${escapeLuaString(options.thresholdMode)}",`,
        `  match_mode = "${escapeLuaString(options.thresholdMode)}",`,
      ] : []),
      `  interval_ms = ${positiveInt(options.intervalMs, 0, 0, 60000)},`,
      `  poll_interval_ms = ${positiveInt(options.intervalMs, 0, 0, 60000)},`,
      `  search_points = ${pointsTable},`,
      `  manual_rois = ${pointsTable},`,
      `  rois = ${pointsTable},`,
      `  roi = ${pointsTable},`,
      `  regions = ${pointsTable}`,
      "}",
    ].join(" ");
  }

  function appendImageSearchOptionsVar(lines, suffix, label, options) {
    if (!options) return "";
    const safeLabel = String(label || "image").replace(/[^A-Za-z0-9_]/g, "_");
    const varName = `image_search_options_${safeLabel}_${suffix}`;
    lines.push(`local ${varName} = ${luaImageSearchOptions(options)}`);
    lines.push(`reportStep("image_search_options:${escapeLuaString(label)}:mode=${escapeLuaString(options.mode)}:points=${options.points.length}:fallback=${escapeLuaString(options.fallback)}")`);
    return varName;
  }

  function imageOptionsArg(optionsVar) {
    return optionsVar ? `, ${optionsVar}` : "";
  }

  function normalizeOpenUrl(value) {
    const raw = String(value || "").trim();
    return raw;
  }

  function shouldUseElementGuard(params = {}) {
    const source = String(params.element_source || "").trim().toLowerCase();
    const reason = String(params.reason || "").trim().toLowerCase();
    return truthy(params.strict_element)
      || source.includes("catalog")
      || reason.startsWith("catalog:");
  }

  function elementSelectorLabel(params = {}) {
    return String(params.element_label || params.element_value || "").trim();
  }

  function elementSelectorRole(params = {}) {
    return String(params.element_role || "").trim();
  }

  function elementTolerance(params = {}) {
    const parsed = parseNumber(params.element_tolerance ?? params.tolerance ?? 0.04);
    if (!Number.isFinite(parsed)) return 0.04;
    return Math.min(Math.max(parsed, 0.005), 0.25);
  }

  function stableVersion(workflow) {
    const hash = global.HidWorkflowBlocks.workflowStableHash(workflow).replace(/^fnv1a-/, "");
    return `v-${hash}`;
  }

  function luaSuffix(block) {
    return String(block?.id || "block").replace(/[^A-Za-z0-9_]/g, "_");
  }

  function wantsTelegramOnTimeout(params = {}) {
    const mode = String(params.on_timeout || "").trim().toLowerCase();
    return mode.includes("telegram")
      || !!String(params.telegram_chat_id || "").trim()
      || !!String(params.telegram_bot_token || "").trim();
  }

  function appendTimeoutLines(lines, params, reason, suffix) {
    const message = String(params.telegram_message || reason || "Workflow timeout").trim();
    const chatId = String(params.telegram_chat_id || "").trim();
    const botToken = String(params.telegram_bot_token || "").trim();
    if (wantsTelegramOnTimeout(params)) {
      if (chatId && botToken) {
        lines.push(`  sendTelegramScreenshot("${escapeLuaString(message)}", "${escapeLuaString(chatId)}", "${escapeLuaString(botToken)}", "timeout_${escapeLuaString(suffix)}")`);
      } else {
        lines.push(`  reportStep("telegram_missing_config:${escapeLuaString(reason)}")`);
      }
    }
    lines.push(`  fail("${escapeLuaString(reason)}")`);
  }

  function appendDelayLine(lines, ms, context = {}) {
    const safeMs = positiveInt(ms, 1000, 1, 3600000);
    const seconds = luaNumber(safeMs / 1000, 3);
    if (usesIOSControlAPI(context.apiProfile)) {
      lines.push(`if msleep then msleep(${safeMs}) elseif sleep then sleep(${seconds}) end`);
    } else {
      lines.push(`if msleep then msleep(${safeMs}) elseif sleep then sleep(${safeMs}) end`);
    }
  }

  function appendRawWebsiteOpenLines(lines, block, params, context = {}) {
    const suffix = luaSuffix(block);
    const target = normalizeOpenUrl(params.url);

    lines.push(`reportStep("open_url:${escapeLuaString(target)}:start")`);
    lines.push(`local open_url_ok_${suffix}, open_url_reason_${suffix} = appRun("com.apple.mobilesafari")`);
    lines.push(`reportStep("open_url:${escapeLuaString(target)}:open_safari_ok=" .. tostring(open_url_ok_${suffix}) .. ":reason=" .. tostring(open_url_reason_${suffix}))`);
    lines.push(`if open_url_ok_${suffix} == false then fail("open_url_failed:${escapeLuaString(target)}:open_safari:" .. tostring(open_url_reason_${suffix})) end`);
    appendDelayLine(lines, 3500, context);

    lines.push(`reportStep("open_url:${escapeLuaString(target)}:tap_address_bar")`);
    lines.push("tap(0.50, 0.92)");
    appendDelayLine(lines, 1800, context);

    lines.push(`reportStep("open_url:${escapeLuaString(target)}:input_raw_url")`);
    lines.push(`inputText("${escapeLuaString(target)}")`);
    appendDelayLine(lines, 2500, context);

    lines.push(`reportStep("open_url:${escapeLuaString(target)}:tap_go")`);
    lines.push("tap(0.94, 0.945)");
    appendDelayLine(lines, 500, context);
    lines.push(`reportStep("open_url:${escapeLuaString(target)}:submitted")`);
    lines.push(`if reportResult then reportResult({ ok = true, stage = "open_url", url = "${escapeLuaString(target)}", reason = "submitted" }) end`);
  }

  function appendImageAnchorGuard(lines, params, suffix, image, context = {}) {
    const anchor = imageAnchor(params, context);
    appendNamedImageAnchorGuard(lines, anchor, suffix, image, "image_match", "image_anchor_mismatch", true);
  }

  function appendNamedImageAnchorGuard(lines, anchor, suffix, image, matchName, eventName, failOnMismatch) {
    if (!anchor) return;
    lines.push(`if ${matchName}_${suffix}.norm_x ~= nil and ${matchName}_${suffix}.norm_y ~= nil then`);
    lines.push(`  local image_dx_${suffix} = math.abs(${matchName}_${suffix}.norm_x - ${luaNumber(anchor.x, 6)})`);
    lines.push(`  local image_dy_${suffix} = math.abs(${matchName}_${suffix}.norm_y - ${luaNumber(anchor.y, 6)})`);
    lines.push(`  if image_dx_${suffix} > ${luaNumber(anchor.radius, 6)} or image_dy_${suffix} > ${luaNumber(anchor.radius, 6)} then`);
    lines.push(`    reportStep("${escapeLuaString(eventName)}:${escapeLuaString(image)}:x=" .. tostring(${matchName}_${suffix}.norm_x) .. ":y=" .. tostring(${matchName}_${suffix}.norm_y) .. ":anchor=${luaNumber(anchor.x, 6)},${luaNumber(anchor.y, 6)}")`);
    if (failOnMismatch) {
      lines.push(`    fail("tap_image_anchor_mismatch:${escapeLuaString(image)}")`);
    } else {
      lines.push(`    ${matchName}_${suffix} = nil`);
    }
    lines.push("  end");
    lines.push("end");
  }

  function appendTapImageMatchLines(lines, matchName, suffix, image, okName, eventName, failReason, score = "0.900", optionsVar = "") {
    lines.push(`  local ${matchName}_x_${suffix}, ${matchName}_y_${suffix} = ${matchName}_${suffix}.x, ${matchName}_${suffix}.y`);
    lines.push(`  local ${okName}_${suffix} = tapNorm(${matchName}_x_${suffix}, ${matchName}_y_${suffix})`);
    lines.push(`  reportStep("${escapeLuaString(eventName)}:${escapeLuaString(image)}:ok=" .. tostring(${okName}_${suffix}) .. ":x=" .. tostring(${matchName}_x_${suffix}) .. ":y=" .. tostring(${matchName}_y_${suffix}) .. ":source=pre_matched")`);
    lines.push(`  if not ${okName}_${suffix} then fail("${escapeLuaString(failReason)}:${escapeLuaString(image)}") end`);
  }

  function appendStatePairSecondActionLines(lines, params, suffix, secondImage, context = {}) {
    const mode = String(params.second_action_mode || "coordinate").trim().toLowerCase() === "image" ? "image" : "coordinate";
    if (mode === "image") {
      const targetImage = String(params.second_target_image || "").trim();
      const targetTimeoutMs = positiveInt(params.second_target_timeout_ms, 3000, 1, 3600000);
      const targetSeconds = luaNumber(targetTimeoutMs / 1000, 3);
      const targetScore = imageThresholdForParam(params, "second_target_image", params.second_target_threshold, context, 0.95, false).toFixed(3);
      const targetOptionsVar = context.imageSearchOptionVars?.second_target || "";
      lines.push(`  local second_target_match_${suffix} = waitForImage("${escapeLuaString(targetImage)}", ${targetSeconds}, ${targetScore}${imageOptionsArg(targetOptionsVar)})`);
      lines.push(`  if not second_target_match_${suffix} then fail("state_pair_second_target_timeout:${escapeLuaString(targetImage)}") end`);
      appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "second_target_image", context), suffix, targetImage, "second_target_match", "state_pair_second_target_anchor_mismatch", true);
      appendTapImageMatchLines(lines, "second_target_match", suffix, targetImage, "state_pair_second_target_tap_ok", `state_pair_second_target_tap:${secondImage}`, "state_pair_second_target_tap_failed", targetScore, targetOptionsVar);
    } else {
      const x = number(params.second_x).toFixed(6);
      const y = number(params.second_y).toFixed(6);
      lines.push(`  local state_pair_second_tap_ok_${suffix} = tapNorm(${x}, ${y})`);
      lines.push(`  reportStep("state_pair_second_coord_tap:${escapeLuaString(secondImage)}:ok=" .. tostring(state_pair_second_tap_ok_${suffix}) .. ":x=${x}:y=${y}")`);
      lines.push(`  if not state_pair_second_tap_ok_${suffix} then fail("state_pair_second_coord_tap_failed:${escapeLuaString(secondImage)}") end`);
    }
  }

  function appendStatePairFirstActionLines(lines, params, suffix, firstImage, context = {}) {
    const mode = String(params.first_action_mode || "self").trim().toLowerCase();
    if (mode === "image") {
      const targetImage = String(params.first_target_image || "").trim();
      const targetTimeoutMs = positiveInt(params.first_target_timeout_ms, 3000, 1, 3600000);
      const targetSeconds = luaNumber(targetTimeoutMs / 1000, 3);
      const targetScore = imageThresholdForParam(params, "first_target_image", params.first_target_threshold, context, 0.95, false).toFixed(3);
      const targetOptionsVar = context.imageSearchOptionVars?.first_target || "";
      lines.push(`  local first_target_match_${suffix} = waitForImage("${escapeLuaString(targetImage)}", ${targetSeconds}, ${targetScore}${imageOptionsArg(targetOptionsVar)})`);
      lines.push(`  if not first_target_match_${suffix} then fail("state_pair_first_target_timeout:${escapeLuaString(targetImage)}") end`);
      appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "first_target_image", context), suffix, targetImage, "first_target_match", "state_pair_first_target_anchor_mismatch", true);
      appendTapImageMatchLines(lines, "first_target_match", suffix, targetImage, "state_pair_first_target_tap_ok", `state_pair_first_target_tap:${firstImage}`, "state_pair_first_target_tap_failed", targetScore, targetOptionsVar);
    } else if (mode === "coordinate") {
      const x = number(params.first_x).toFixed(6);
      const y = number(params.first_y).toFixed(6);
      lines.push(`  local state_pair_first_tap_ok_${suffix} = tapNorm(${x}, ${y})`);
      lines.push(`  reportStep("state_pair_first_coord_tap:${escapeLuaString(firstImage)}:ok=" .. tostring(state_pair_first_tap_ok_${suffix}) .. ":x=${x}:y=${y}")`);
      lines.push(`  if not state_pair_first_tap_ok_${suffix} then fail("state_pair_first_coord_tap_failed:${escapeLuaString(firstImage)}") end`);
    } else {
      const firstScore = imageThresholdForParam(params, "first_image", params.threshold, context, 0.95).toFixed(3);
      appendTapImageMatchLines(lines, "first_match", suffix, firstImage, "state_pair_first_tap_ok", "state_pair_first_tap", "state_pair_first_tap_failed", firstScore, context.imageSearchOptionVars?.first || "");
    }
  }

  function referencedLuaImagePaths(content) {
    const paths = new Set();
    const source = String(content || "");
    const pattern = /\b(?:waitForImage|tapImage|findImage|findImages)\s*\(\s*(["'])(.*?)\1/g;
    let match = pattern.exec(source);
    while (match) {
      const path = String(match[2] || "").trim();
      if (path) paths.add(path);
      match = pattern.exec(source);
    }
    return paths;
  }

  function referencedImagePaths(workflow, content = "") {
    const paths = new Set();
    function visit(block) {
      if (!block) return;
      if (block.type === "wait_image" || block.type === "tap_image" || block.type === "tap_image_optional") {
        const image = String(block.params?.image || "").trim();
        if (image) paths.add(image);
      }
      if (block.type === "tap_if_image") {
        for (const condition of conditionImagePaths(block.params || {})) paths.add(condition);
        const mode = String(block.params?.action_mode || "coordinate").trim().toLowerCase();
        const target = String(block.params?.target_image || "").trim();
        if (mode === "image" && target) paths.add(target);
      }
      if (block.type === "tap_image_state_pair") {
        const first = String(block.params?.first_image || "").trim();
        const second = String(block.params?.second_image || "").trim();
        const firstMode = String(block.params?.first_action_mode || "self").trim().toLowerCase();
        const firstTarget = String(block.params?.first_target_image || "").trim();
        const mode = String(block.params?.second_action_mode || "coordinate").trim().toLowerCase();
        const target = String(block.params?.second_target_image || "").trim();
        if (first) paths.add(first);
        if (firstMode === "image" && firstTarget) paths.add(firstTarget);
        if (second) paths.add(second);
        if (mode === "image" && target) paths.add(target);
      }
      for (const child of block.body || []) visit(child);
    }
    for (const block of workflow.blocks || []) visit(block);
    for (const path of referencedLuaImagePaths(content)) paths.add(path);
    return paths;
  }

  function packageAssets(workflow, content = "") {
    const refs = referencedImagePaths(workflow, content);
    if (!refs.size) return [];
    const assets = (workflow.assets || [])
      .filter((asset) => refs.has(String(asset?.path || "").trim()))
      .map((asset) => ({
        id: asset.id || asset.path,
        path: asset.path,
        name: asset.name || asset.path,
        mime: asset.mime || "image/png",
        size: Number(asset.size || 0) || 0,
        sha256: String(asset.sha256 || "").trim().toLowerCase(),
        data_base64: asset.data_base64 || "",
        source: asset.source || "workflow",
        width: Number(asset.width || 0) || undefined,
        height: Number(asset.height || 0) || undefined,
        source_width: Number(asset.source_width || 0) || undefined,
        source_height: Number(asset.source_height || 0) || undefined,
        crop_norm: asset.crop_norm || undefined,
        neighbor_texts: Array.isArray(asset.neighbor_texts) ? asset.neighbor_texts : undefined,
      }));
    const available = new Set(assets.map((asset) => String(asset.path || "").trim()).filter(Boolean));
    const missing = Array.from(refs).filter((path) => !available.has(path));
    if (missing.length) {
      throw new Error(`Thiếu ảnh mẫu trong gói script: ${missing.join(", ")}. Cần crop/nhập lại ảnh rồi gửi cả assets[] sang iPhone.`);
    }
    return assets;
  }

  function orderedLines(workflow, options = {}) {
    const normalized = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
    if (String(normalized.raw_lua || "").trim()) return String(normalized.raw_lua).replace(/\r\n/g, "\n").split("\n");
    const blocks = global.HidWorkflowBlocks.orderedBlocks(normalized);
    const blockNumberMap = new Map();
    blocks.forEach((block, index) => {
      if (block?.id) blockNumberMap.set(block.id, index + 1);
    });
    const context = {
      apiProfile: profileName(options.apiProfile || normalized.api_profile || "hidprobe-v1"),
      assetByPath: new Map((normalized.assets || []).map((asset) => [String(asset?.path || "").trim(), asset])),
      workflowName: normalized.name || "workflow",
      blockNumberMap,
      blockTotal: blocks.length,
    };
    const lines = [
      "-- HIDProbe generated workflow script",
      `reportStep("start:${escapeLuaString(normalized.name || "workflow")}")`,
    ];
    blocks.forEach((block, index) => {
      appendBlockWithErrorPolicy(lines, block, { ...context, orderedBlocks: blocks, blockIndex: index });
    });
    lines.push(`reportStep("done:${escapeLuaString(normalized.name || "workflow")}")`);
    return lines;
  }

  function blockContinuesOnError(block) {
    return String(block?.params?.on_error || "fail").trim().toLowerCase() === "continue";
  }

  function blockHUDIndex(block, context = {}) {
    const mapped = block?.id ? context.blockNumberMap?.get(block.id) : null;
    if (Number.isFinite(mapped)) return mapped;
    const fallback = Number(context.blockIndex);
    return Number.isFinite(fallback) ? fallback + 1 : 0;
  }

  function blockHUDDetail(block) {
    const params = block?.params || {};
    if (block?.type === "wait") {
      const ms = global.HidWorkflowBlocks.asPositiveInt(params.ms, 1000, 1, 600000);
      if (ms >= 1000 && ms % 1000 === 0) return `${Math.floor(ms / 1000)}s`;
      return `${ms}ms`;
    }
    return "";
  }

  function appendBlockHUDReport(lines, block, context = {}, status = "running", indent = "", detailOverride = "") {
    const payload = {
      hud: "block",
      status,
      block_index: blockHUDIndex(block, context),
      block_total: Number(context.blockTotal || 0) || 0,
      kind: String(block?.type || "block"),
    };
    const detail = detailOverride || blockHUDDetail(block);
    if (detail) payload.detail = detail;
    if (context.workflowName) payload.script = String(context.workflowName);
    if (Number.isFinite(context.loopRun) && Number.isFinite(context.loopTotal)) {
      payload.loop_run = context.loopRun;
      payload.loop_total = context.loopTotal;
    }
    lines.push(`${indent}reportStep("${escapeLuaString(`state:${JSON.stringify(payload)}`)}")`);
  }

  function appendBlockWithErrorPolicy(lines, block, context = {}) {
    const continueOnError = blockContinuesOnError(block);
    const suffix = luaSuffix(block);
    appendBlockHUDReport(lines, block, context, "running");
    lines.push("do");
    lines.push(`  local block_ok_${suffix}, block_err_${suffix} = pcall(function()`);
    appendBlockLines(lines, block, context);
    lines.push("  end)");
    lines.push(`  if block_ok_${suffix} then`);
    appendBlockHUDReport(lines, block, context, "ok", "    ");
    lines.push("  else");
    appendBlockHUDReport(lines, block, context, "failed", "    ");
    lines.push(`    if block_err_${suffix} == "lua_interrupted" then error(block_err_${suffix}, 0) end`);
    if (continueOnError) {
      lines.push(`    reportStep("block_error_continue:${escapeLuaString(block.id || "block")}:" .. tostring(block_err_${suffix}))`);
    } else {
      lines.push(`    error(block_err_${suffix}, 0)`);
    }
    lines.push("  end");
    lines.push("end");
  }

  function appendExtokTikTokJobLines(lines, block, context = {}) {
    const params = block.params || {};
    const suffix = luaSuffix(block);
    const apiKey = String(params.api_key || "").trim();
    const uniqueUsername = String(params.unique_username || "").trim();
    const jobType = String(params.job_type || "follow").trim().toLowerCase();
    const skipType = String(params.skip_type || "").trim().toLowerCase();
    const lang = String(params.lang || "vi").trim().toLowerCase() || "vi";
    const actionTimeoutMs = positiveInt(params.action_timeout_ms, 20000, 1000, 180000);
    const completeAfterAction = truthy(params.complete_after_action);
    const skipUnsupported = truthy(params.skip_unsupported);
    const note = String(params.note || "").trim();
    const followTexts = String(params.follow_texts || "Follow|Theo dõi|Follow back")
      .split(/[|,\n]+/)
      .map((item) => item.trim())
      .filter(Boolean);
    const followTable = luaStringTable(followTexts.length ? followTexts : ["Follow", "Theo dõi", "Follow back"]);

    lines.push(`local extok_base_${suffix} = "https://api.extok.net/api/v2"`);
    lines.push(`local extok_key_${suffix} = "${escapeLuaString(apiKey)}"`);
    lines.push(`local extok_user_${suffix} = "${escapeLuaString(uniqueUsername)}"`);
    lines.push(`local extok_type_${suffix} = "${escapeLuaString(jobType)}"`);
    lines.push(`local extok_skip_type_${suffix} = "${escapeLuaString(skipType)}"`);
    lines.push(`local extok_lang_${suffix} = "${escapeLuaString(lang)}"`);
    lines.push(`local extok_note_${suffix} = "${escapeLuaString(note)}"`);
    lines.push(`if extok_key_${suffix} == "" then fail("extok_api_key_missing") end`);
    lines.push(`if extok_user_${suffix} == "" then fail("extok_unique_username_missing") end`);
    lines.push(`if not httpGet or not httpPost then fail("extok_http_api_missing") end`);
    lines.push(`local function extok_json_${suffix}(body)`);
    lines.push(`  if not jsonDecode then return nil, "jsonDecode_missing" end`);
    lines.push(`  local data, reason = jsonDecode(body or "")`);
    lines.push(`  if not data then return nil, reason or "json_decode_failed" end`);
    lines.push(`  return data, "ok"`);
    lines.push(`end`);
    lines.push(`local function extok_post_${suffix}(endpoint, payload)`);
    lines.push(`  local response = httpPost(extok_base_${suffix} .. endpoint, payload, { ["Content-Type"] = "application/json", ["Accept"] = "application/json" }, { timeout_ms = 15000 })`);
    lines.push(`  local status = response and tonumber(response.status or 0) or 0`);
    lines.push(`  reportStep("extok_post:" .. endpoint .. ":status=" .. tostring(status))`);
    lines.push(`  if status < 200 or status >= 300 then return nil, "http_status_" .. tostring(status) end`);
    lines.push(`  return extok_json_${suffix}(response.body or "")`);
    lines.push(`end`);
    lines.push(`local function extok_skip_${suffix}(job, reason)`);
    lines.push(`  if not job or not job.id then return nil, "missing_job_id" end`);
    lines.push(`  return extok_post_${suffix}("/tiktok-jobs/skip", { key = extok_key_${suffix}, job_id = job.id, unique_username = extok_user_${suffix} })`);
    lines.push(`end`);
    lines.push(`local function extok_complete_${suffix}(job, success, reason)`);
    lines.push(`  if not job or not job.id then return nil, "missing_job_id" end`);
    lines.push(`  local payload = { key = extok_key_${suffix}, job_id = job.id, unique_username = extok_user_${suffix}, success = success and true or false }`);
    lines.push(`  if reason and reason ~= "" then payload.note = reason end`);
    lines.push(`  if job.comment_id then payload.comment_id = job.comment_id end`);
    lines.push(`  return extok_post_${suffix}("/tiktok-jobs/complete", payload)`);
    lines.push(`end`);
    lines.push(`local function extok_tap_any_text_${suffix}(labels, timeoutMs)`);
    lines.push(`  local attempts = math.max(1, math.ceil((tonumber(timeoutMs or 10000) or 10000) / 1000))`);
    lines.push(`  for try = 1, attempts do`);
    lines.push(`    for _, label in ipairs(labels or {}) do`);
    lines.push(`      if label ~= "" then`);
    lines.push(`        if element and element.tapContains then`);
    lines.push(`          local element_call_ok, element_tap_ok = pcall(function() return element.tapContains(label, 1000) end)`);
    lines.push(`          if element_call_ok and element_tap_ok then reportStep("extok_tap_element:" .. label .. ":ok=true"); return true, label, "element" end`);
    lines.push(`        end`);
    lines.push(`        if ocrFind and tapNorm then`);
    lines.push(`          local match = ocrFind(label)`);
    lines.push(`          local x = match and (match.norm_x or match.x) or nil`);
    lines.push(`          local y = match and (match.norm_y or match.y) or nil`);
    lines.push(`          reportStep("extok_text_probe:" .. label .. ":try=" .. tostring(try) .. ":found=" .. tostring(match ~= nil) .. ":x=" .. tostring(x) .. ":y=" .. tostring(y))`);
    lines.push(`          if type(x) == "number" and type(y) == "number" and x >= 0 and x <= 1 and y >= 0 and y <= 1 then`);
    lines.push(`            local ok = tapNorm(x, y)`);
    lines.push(`            if ok then return true, label, "ocr" end`);
    lines.push(`          end`);
    lines.push(`        elseif tapText then`);
    lines.push(`          local ok = tapText(label, 1)`);
    lines.push(`          if ok then return true, label, "tapText" end`);
    lines.push(`        end`);
    lines.push(`      end`);
    lines.push(`    end`);
    lines.push(`    if try < attempts then sleep(1) end`);
    lines.push(`  end`);
    lines.push(`  return false, "", "not_found"`);
    lines.push(`end`);
    lines.push(`reportStep("extok_get_job:start:type=" .. extok_type_${suffix} .. ":user=" .. extok_user_${suffix})`);
    lines.push(`local extok_params_${suffix} = { key = extok_key_${suffix}, unique_username = extok_user_${suffix}, lang = extok_lang_${suffix} }`);
    lines.push(`if extok_type_${suffix} ~= "" then extok_params_${suffix}.type = extok_type_${suffix} end`);
    lines.push(`if extok_skip_type_${suffix} ~= "" then extok_params_${suffix}.skip_type = extok_skip_type_${suffix} end`);
    lines.push(`local extok_response_${suffix} = httpGet(extok_base_${suffix} .. "/tiktok-jobs", extok_params_${suffix}, { ["Accept"] = "application/json" }, { timeout_ms = 15000 })`);
    lines.push(`local extok_status_${suffix} = extok_response_${suffix} and tonumber(extok_response_${suffix}.status or 0) or 0`);
    lines.push(`reportStep("extok_get_job:status=" .. tostring(extok_status_${suffix}))`);
    lines.push(`if extok_status_${suffix} < 200 or extok_status_${suffix} >= 300 then fail("extok_get_job_http_status:" .. tostring(extok_status_${suffix})) end`);
    lines.push(`local extok_payload_${suffix}, extok_decode_reason_${suffix} = extok_json_${suffix}(extok_response_${suffix}.body or "")`);
    lines.push(`if not extok_payload_${suffix} then fail("extok_get_job_json:" .. tostring(extok_decode_reason_${suffix})) end`);
    lines.push(`local extok_jobs_${suffix} = extok_payload_${suffix}.data or {}`);
    lines.push(`local extok_job_${suffix} = extok_jobs_${suffix}[1]`);
    lines.push(`if not extok_job_${suffix} then fail("extok_no_job") end`);
    lines.push(`local extok_job_type_${suffix} = tostring(extok_job_${suffix}.type or "")`);
    lines.push(`local extok_link_${suffix} = tostring(extok_job_${suffix}.link or "")`);
    lines.push(`reportStep("extok_job:id=" .. tostring(extok_job_${suffix}.id) .. ":type=" .. extok_job_type_${suffix} .. ":coin=" .. tostring(extok_job_${suffix}.fix_coin_job or ""))`);
    lines.push(`if extok_link_${suffix} == "" then`);
    lines.push(`  extok_skip_${suffix}(extok_job_${suffix}, "missing_link")`);
    lines.push(`  fail("extok_job_missing_link")`);
    lines.push(`end`);
    lines.push(`if extok_job_type_${suffix} ~= "follow" then`);
    lines.push(`  if ${skipUnsupported ? "true" : "false"} then`);
    lines.push(`    extok_skip_${suffix}(extok_job_${suffix}, "unsupported_type:" .. extok_job_type_${suffix})`);
    lines.push(`  end`);
    lines.push(`  fail("extok_unsupported_job_type:" .. extok_job_type_${suffix})`);
    lines.push(`end`);
    lines.push(`local extok_open_ok_${suffix}, extok_open_reason_${suffix} = false, "no_open_url"`);
    lines.push(`if openURL then`);
    lines.push(`  extok_open_ok_${suffix}, extok_open_reason_${suffix} = openURL(extok_link_${suffix})`);
    lines.push(`elseif app and app.open_url then`);
    lines.push(`  extok_open_ok_${suffix}, extok_open_reason_${suffix} = app.open_url(extok_link_${suffix})`);
    lines.push(`end`);
    lines.push(`reportStep("extok_open_job:ok=" .. tostring(extok_open_ok_${suffix}) .. ":reason=" .. tostring(extok_open_reason_${suffix}))`);
    lines.push(`if not extok_open_ok_${suffix} then`);
    lines.push(`  extok_skip_${suffix}(extok_job_${suffix}, "open_failed")`);
    lines.push(`  fail("extok_open_job_failed:" .. tostring(extok_open_reason_${suffix}))`);
    lines.push(`end`);
    lines.push(`sleep(5)`);
    lines.push(`local extok_follow_labels_${suffix} = ${followTable}`);
    lines.push(`local extok_tapped_${suffix}, extok_label_${suffix}, extok_method_${suffix} = extok_tap_any_text_${suffix}(extok_follow_labels_${suffix}, ${actionTimeoutMs})`);
    lines.push(`reportStep("extok_follow_action:ok=" .. tostring(extok_tapped_${suffix}) .. ":label=" .. tostring(extok_label_${suffix}) .. ":method=" .. tostring(extok_method_${suffix}))`);
    lines.push(`if not extok_tapped_${suffix} then`);
    lines.push(`  extok_skip_${suffix}(extok_job_${suffix}, "follow_button_missing")`);
    lines.push(`  fail("extok_follow_button_missing")`);
    lines.push(`end`);
    lines.push(`sleep(2)`);
    if (completeAfterAction) {
      lines.push(`local extok_complete_payload_${suffix}, extok_complete_reason_${suffix} = extok_complete_${suffix}(extok_job_${suffix}, true, extok_note_${suffix})`);
      lines.push(`if not extok_complete_payload_${suffix} then fail("extok_complete_failed:" .. tostring(extok_complete_reason_${suffix})) end`);
      lines.push(`reportResult({ ok = true, stage = "extok_tiktok_job", job_id = extok_job_${suffix}.id, job_type = extok_job_type_${suffix}, action = "follow", complete_status = extok_complete_payload_${suffix}.status or 200, message = extok_complete_payload_${suffix}.message or "completed" })`);
    } else {
      lines.push(`reportResult({ ok = true, stage = "extok_tiktok_job", job_id = extok_job_${suffix}.id, job_type = extok_job_type_${suffix}, action = "follow", complete_skipped_by_config = true })`);
    }
  }

  function appendBlockLines(lines, block, context = {}) {
    const params = block.params || {};
    const isIOSControl = usesIOSControlAPI(context.apiProfile);
    if (block.type === "tap") {
      const tapX = number(params.x).toFixed(6);
      const tapY = number(params.y).toFixed(6);
      if (shouldUseElementGuard(params)) {
        const label = elementSelectorLabel(params);
        const role = elementSelectorRole(params);
        if (!label && !role) {
          const reason = params.reason || params.element_source || block.id || "tap";
          lines.push(`fail("element_selector_missing:${escapeLuaString(reason)}")`);
          return;
        }
        lines.push(`tapElement("${escapeLuaString(label)}", "${escapeLuaString(role)}", ${tapX}, ${tapY}, ${elementTolerance(params).toFixed(3)})`);
        return;
      }
      lines.push(`tapNorm(${tapX}, ${tapY})`);
      return;
    }
    if (block.type === "long_press") {
      const hold = global.HidWorkflowBlocks.asPositiveInt(params.hold_ms, 800, 100, 10000);
      lines.push(`longPressNorm(${number(params.x).toFixed(6)}, ${number(params.y).toFixed(6)}, ${hold})`);
      return;
    }
    if (block.type === "swipe") {
      const points = global.HidWorkflowBlocks.swipePoints(params);
      lines.push(`swipeNorm(${number(points.from.x).toFixed(6)}, ${number(points.from.y).toFixed(6)}, ${number(points.to.x).toFixed(6)}, ${number(points.to.y).toFixed(6)}, ${Number(points.duration_ms || 300).toFixed(0)}, ${Number(points.steps || 10).toFixed(0)})`);
      return;
    }
    if (block.type === "hardware_home") {
      lines.push("pressHome()");
      return;
    }
    if (block.type === "wait") {
      const ms = global.HidWorkflowBlocks.asPositiveInt(params.ms, 1000, 1, 600000);
      lines.push(isIOSControl ? `sleep(${luaNumber(ms / 1000, 3)})` : `sleep(${ms})`);
      return;
    }
    if (block.type === "input_text") {
      const suffix = luaSuffix(block);
      const text = String(params.input_text ?? params.text ?? "");
      const delayMs = global.HidWorkflowBlocks.asPositiveInt(params.delay_ms, 300, 0, 60000);
      lines.push(`local input_ok_${suffix}, input_reason_${suffix} = inputText("${escapeLuaString(text)}")`);
      lines.push(`reportStep("input_text:${escapeLuaString(text)}:ok=" .. tostring(input_ok_${suffix}) .. ":reason=" .. tostring(input_reason_${suffix}))`);
      lines.push(`if not input_ok_${suffix} then fail("input_text_failed:${escapeLuaString(text)}:" .. tostring(input_reason_${suffix})) end`);
      if (truthy(params.submit_after)) {
        if (delayMs > 0) lines.push(isIOSControl ? `sleep(${luaNumber(delayMs / 1000, 3)})` : `sleep(${delayMs})`);
        lines.push(`local input_submit_ok_${suffix}, input_submit_reason_${suffix} = inputText("\\n")`);
        lines.push(`reportStep("input_submit:${escapeLuaString(text)}:ok=" .. tostring(input_submit_ok_${suffix}) .. ":reason=" .. tostring(input_submit_reason_${suffix}))`);
        lines.push(`if not input_submit_ok_${suffix} then fail("input_submit_failed:${escapeLuaString(text)}:" .. tostring(input_submit_reason_${suffix})) end`);
      }
      return;
    }
    if (block.type === "loop") {
      const iterations = global.HidWorkflowBlocks.asPositiveInt(params.iterations, 1, 1, 1000);
      const range = global.HidWorkflowBlocks.loopRepeatRange?.(block, context.blockIndex, context.orderedBlocks || []);
      const children = range ? range.blocks : (block.body || []);
      for (let index = 0; index < iterations; index += 1) {
        if (range) {
          lines.push(`reportStep("loop:${index + 1}/${iterations}:steps=${range.start_step}-${range.end_step}")`);
        } else {
          lines.push(`reportStep("loop:${index + 1}/${iterations}")`);
        }
        for (const child of children) {
          appendBlockWithErrorPolicy(lines, child, {
            ...context,
            loopRun: index + 1,
            loopTotal: iterations,
          });
        }
      }
      return;
    }
    if (block.type === "screenshot") {
      lines.push(`reportStep("screenshot:${escapeLuaString(params.save_as || "screenshot")} unsupported_on_mvp")`);
      return;
    }
    if (block.type === "open_app") {
      const target = params.bundle_id || params.url_scheme || "";
      if (!target) {
        lines.push(`fail("open_app_missing_bundle_id:${escapeLuaString(params.app_name || block.id)}")`);
        return;
      }
      lines.push(`openApp("${escapeLuaString(target)}")`);
      return;
    }
    if (block.type === "open_url") {
      const target = normalizeOpenUrl(params.url);
      if (!target) {
        lines.push(`fail("open_url_missing:${escapeLuaString(block.id)}")`);
        return;
      }
      appendRawWebsiteOpenLines(lines, block, params, context);
      return;
    }
    if (block.type === "extok_tiktok_job") {
      appendExtokTikTokJobLines(lines, block, context);
      return;
    }
    if (block.type === "kill_app") {
      const suffix = luaSuffix(block);
      const target = String(params.bundle_id || "").trim();
      const killFn = isIOSControl ? "appKill" : "killApp";
      if (!target) {
        lines.push(`fail("kill_app_missing_bundle_id:${escapeLuaString(params.app_name || block.id)}")`);
        return;
      }
      if (isIOSControl) {
        lines.push("if not appKill then");
        lines.push("  function appKill(bundleID)");
        lines.push("    if app and app.close then return app.close(bundleID) end");
        lines.push("    return killApp(bundleID)");
        lines.push("  end");
        lines.push("end");
      }
      lines.push(`local kill_ok_${suffix}, kill_reason_${suffix} = ${killFn}("${escapeLuaString(target)}")`);
      lines.push(`reportStep("kill_app:${escapeLuaString(target)}:ok=" .. tostring(kill_ok_${suffix}) .. ":reason=" .. tostring(kill_reason_${suffix}))`);
      lines.push(`if not kill_ok_${suffix} then`);
      lines.push(`  local kill_reason_text_${suffix} = tostring(kill_reason_${suffix})`);
      lines.push(`  if string.find(kill_reason_text_${suffix}, "not_running", 1, true) then`);
      lines.push(`    reportStep("kill_app_already_closed:${escapeLuaString(target)}")`);
      lines.push("  else");
      lines.push(`    fail("kill_app_failed:${escapeLuaString(target)}:" .. kill_reason_text_${suffix})`);
      lines.push("  end");
      lines.push("end");
      return;
    }
    if (block.type === "wait_text" || block.type === "tap_text") {
      const suffix = luaSuffix(block);
      const text = String(params.text || "").trim();
      const timeoutMs = positiveInt(params.timeout_ms, 300000, 1, 3600000);
      if (isIOSControl) {
        const intervalMs = positiveInt(params.interval_ms, 1000, 100, 60000);
        const attempts = Math.max(1, Math.ceil(timeoutMs / intervalMs));
        const intervalSeconds = luaNumber(intervalMs / 1000, 3);
        const variants = textSearchVariants(text);
        const variantTable = luaStringTable(variants);
        const maxYParam = firstPresent(params, ["text_max_y", "tap_max_y", "max_y"]);
        const parsedMaxY = parseNumber(maxYParam);
        const hasMaxYParam = maxYParam !== undefined && maxYParam !== null && String(maxYParam).trim() !== "";
        const tapMaxY = hasMaxYParam && Number.isFinite(parsedMaxY) ? Math.min(Math.max(parsedMaxY, 0.01), 1) : 0.88;
        const tapMaxYLua = luaNumber(tapMaxY, 3);
        if (block.type === "tap_text") {
          lines.push(`local text_match_${suffix} = nil`);
          lines.push(`local text_match_label_${suffix} = nil`);
          lines.push(`local text_variants_${suffix} = ${variantTable}`);
          lines.push(`for text_try_${suffix} = 1, ${attempts} do`);
          lines.push(`  for _, text_candidate_${suffix} in ipairs(text_variants_${suffix}) do`);
          lines.push(`    local text_candidate_match_${suffix} = ocrFind(text_candidate_${suffix})`);
          lines.push(`    local text_nx_${suffix} = text_candidate_match_${suffix} and (text_candidate_match_${suffix}.norm_x or text_candidate_match_${suffix}.x) or nil`);
          lines.push(`    local text_ny_${suffix} = text_candidate_match_${suffix} and (text_candidate_match_${suffix}.norm_y or text_candidate_match_${suffix}.y) or nil`);
          lines.push(`    local text_valid_${suffix} = text_candidate_match_${suffix} ~= nil and type(text_nx_${suffix}) == "number" and type(text_ny_${suffix}) == "number" and text_nx_${suffix} >= 0 and text_nx_${suffix} <= 1 and text_ny_${suffix} >= 0 and text_ny_${suffix} <= ${tapMaxYLua}`);
          lines.push(`    local text_reject_${suffix} = ""`);
          lines.push(`    if text_candidate_match_${suffix} ~= nil and not text_valid_${suffix} and type(text_ny_${suffix}) == "number" and text_ny_${suffix} > ${tapMaxYLua} then text_reject_${suffix} = "bottom_toolbar" end`);
          lines.push(`    reportStep("text_probe:${escapeLuaString(text)}:try=" .. tostring(text_try_${suffix}) .. ":candidate=" .. tostring(text_candidate_${suffix}) .. ":found=" .. tostring(text_candidate_match_${suffix} ~= nil) .. ":valid=" .. tostring(text_valid_${suffix}) .. ":x=" .. tostring(text_nx_${suffix}) .. ":y=" .. tostring(text_ny_${suffix}) .. ":reject=" .. tostring(text_reject_${suffix}))`);
          lines.push(`    if text_valid_${suffix} then`);
          lines.push(`      text_match_${suffix} = text_candidate_match_${suffix}`);
          lines.push(`      text_match_label_${suffix} = text_candidate_${suffix}`);
          lines.push("      break");
          lines.push("    end");
          lines.push("  end");
          lines.push(`  if text_match_${suffix} then break end`);
          lines.push(`  if text_try_${suffix} < ${attempts} then sleep(${intervalSeconds}) end`);
          lines.push("end");
          lines.push(`if not text_match_${suffix} then`);
          appendTimeoutLines(lines, params, `${block.type}_timeout:${text || block.id}`, suffix);
          lines.push("end");
          lines.push(`local text_x_${suffix}, text_y_${suffix} = text_match_${suffix}.x, text_match_${suffix}.y`);
          lines.push(`local text_tap_ok_${suffix} = false`);
          lines.push(`if text_match_${suffix}.norm_x ~= nil and text_match_${suffix}.norm_y ~= nil then`);
          lines.push(`  text_tap_ok_${suffix} = tapNorm(text_match_${suffix}.norm_x, text_match_${suffix}.norm_y)`);
          lines.push("else");
          lines.push(`  text_tap_ok_${suffix} = tap(text_x_${suffix}, text_y_${suffix})`);
          lines.push("end");
          lines.push(`reportStep("text_tap:${escapeLuaString(text)}:ok=" .. tostring(text_tap_ok_${suffix}) .. ":label=" .. tostring(text_match_label_${suffix}) .. ":x=" .. tostring(text_x_${suffix}) .. ":y=" .. tostring(text_y_${suffix}))`);
          lines.push(`if not text_tap_ok_${suffix} then fail("tap_text_failed:${escapeLuaString(text)}") end`);
        } else {
          lines.push(`local text_match_${suffix} = nil`);
          lines.push(`local text_match_label_${suffix} = nil`);
          lines.push(`local text_variants_${suffix} = ${variantTable}`);
          lines.push(`for text_try_${suffix} = 1, ${attempts} do`);
          lines.push(`  for _, text_candidate_${suffix} in ipairs(text_variants_${suffix}) do`);
          lines.push(`    text_match_${suffix} = ocrFind(text_candidate_${suffix})`);
          lines.push(`    reportStep("text_probe:${escapeLuaString(text)}:try=" .. tostring(text_try_${suffix}) .. ":candidate=" .. tostring(text_candidate_${suffix}) .. ":found=" .. tostring(text_match_${suffix} ~= nil))`);
          lines.push(`    if text_match_${suffix} then`);
          lines.push(`      text_match_label_${suffix} = text_candidate_${suffix}`);
          lines.push("      break");
          lines.push("    end");
          lines.push("  end");
          lines.push(`  if text_match_${suffix} then break end`);
          lines.push(`  if text_try_${suffix} < ${attempts} then sleep(${intervalSeconds}) end`);
          lines.push("end");
          lines.push(`if not text_match_${suffix} then`);
          appendTimeoutLines(lines, params, `${block.type}_timeout:${text || block.id}`, suffix);
          lines.push("end");
          lines.push(`reportStep("text_found:${escapeLuaString(text)}:label=" .. tostring(text_match_label_${suffix}) .. ":x=" .. tostring(text_match_${suffix}.x) .. ":y=" .. tostring(text_match_${suffix}.y))`);
        }
      } else {
        const intervalMs = positiveInt(params.interval_ms, 1000, 100, 60000);
        lines.push(`local text_x_${suffix}, text_y_${suffix} = waitForText("${escapeLuaString(text)}", ${timeoutMs}, ${intervalMs})`);
        lines.push(`if text_x_${suffix} == -1 then`);
        appendTimeoutLines(lines, params, `${block.type}_timeout:${text || block.id}`, suffix);
        lines.push("end");
        if (block.type === "tap_text") {
          lines.push(`tapNorm(text_x_${suffix}, text_y_${suffix})`);
        }
      }
      return;
    }
    if (block.type === "tap_image_state_pair") {
      const suffix = luaSuffix(block);
      const firstImage = String(params.first_image || "").trim();
      const secondImage = String(params.second_image || "").trim();
      const timeoutMs = positiveInt(params.timeout_ms, 5000, 1, 3600000);
      const intervalMs = positiveInt(params.interval_ms, 500, 100, 60000);
      const attempts = Math.max(1, Math.ceil(timeoutMs / intervalMs));
      const firstScore = imageThresholdForParam(params, "first_image", params.threshold, context, 0.95).toFixed(3);
      const secondScore = imageThresholdForParam(params, "second_image", params.second_threshold, context, 0.95).toFixed(3);
      const afterFirstWaitMs = positiveInt(params.after_first_wait_ms, 1000, 0, 60000);
      const afterFirstWaitSeconds = luaNumber(afterFirstWaitMs / 1000, 3);
      const afterFirstSecondTimeoutMs = positiveInt(params.after_first_second_timeout_ms, 5000, 1, 3600000);
      const timeoutMode = String(params.on_timeout || "fail").trim().toLowerCase();
      const skipOnTimeout = ["skip", "ignore", "continue", "bỏ qua", "bo qua"].includes(timeoutMode);
      const imageSearchOptionVars = {};
      imageSearchOptionVars.first = appendImageSearchOptionsVar(lines, suffix, "state_pair_first", imageSearchOptions(params, "first", context));
      imageSearchOptionVars.second = appendImageSearchOptionsVar(lines, suffix, "state_pair_second", imageSearchOptions(params, "second", context));
      imageSearchOptionVars.first_target = appendImageSearchOptionsVar(lines, suffix, "state_pair_first_target", imageSearchOptions(params, "first_target", context));
      imageSearchOptionVars.second_target = appendImageSearchOptionsVar(lines, suffix, "state_pair_second_target", imageSearchOptions(params, "second_target", context));
      const statePairContext = { ...context, imageSearchOptionVars };
      if (isIOSControl) {
        const scanSeconds = luaNumber(Math.max(0.1, Math.min(0.75, intervalMs / 1000)), 3);
        const intervalSeconds = luaNumber(intervalMs / 1000, 3);
        const afterFirstSecondSeconds = luaNumber(afterFirstSecondTimeoutMs / 1000, 3);
        lines.push(`local state_pair_handled_${suffix} = false`);
        lines.push(`for state_pair_try_${suffix} = 1, ${attempts} do`);
        lines.push(`  local first_match_${suffix} = waitForImage("${escapeLuaString(firstImage)}", ${scanSeconds}, ${firstScore}${imageOptionsArg(imageSearchOptionVars.first)})`);
        lines.push(`  if first_match_${suffix} then`);
        appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "first_image", context), suffix, firstImage, "first_match", "state_pair_first_anchor_mismatch_skip", false);
        lines.push("  end");
        lines.push(`  if first_match_${suffix} then`);
        lines.push(`    reportStep("state_pair_first_seen:${escapeLuaString(firstImage)}")`);
        appendStatePairFirstActionLines(lines, params, suffix, firstImage, statePairContext);
        lines.push(`    state_pair_handled_${suffix} = true`);
        if (truthy(params.check_second_after_first)) {
          lines.push(`    if ${afterFirstWaitMs} > 0 then sleep(${afterFirstWaitSeconds}) end`);
          lines.push(`    local second_after_match_${suffix} = waitForImage("${escapeLuaString(secondImage)}", ${afterFirstSecondSeconds}, ${secondScore}${imageOptionsArg(imageSearchOptionVars.second)})`);
          lines.push(`    if second_after_match_${suffix} then`);
          appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "second_image", context), suffix, secondImage, "second_after_match", "state_pair_second_after_first_anchor_mismatch", true);
          lines.push("    end");
          lines.push(`    if not second_after_match_${suffix} then fail("state_pair_second_after_first_timeout:${escapeLuaString(secondImage)}") end`);
          lines.push(`    reportStep("state_pair_second_after_first_seen:${escapeLuaString(secondImage)}")`);
          appendStatePairSecondActionLines(lines, params, suffix, secondImage, statePairContext);
        }
        lines.push("    break");
        lines.push("  end");
        lines.push(`  local second_match_${suffix} = waitForImage("${escapeLuaString(secondImage)}", ${scanSeconds}, ${secondScore}${imageOptionsArg(imageSearchOptionVars.second)})`);
        lines.push(`  if second_match_${suffix} then`);
        appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "second_image", context), suffix, secondImage, "second_match", "state_pair_second_anchor_mismatch_skip", false);
        lines.push("  end");
        lines.push(`  if second_match_${suffix} then`);
        lines.push(`    reportStep("state_pair_second_seen:${escapeLuaString(secondImage)}")`);
        appendStatePairSecondActionLines(lines, params, suffix, secondImage, statePairContext);
        lines.push(`    state_pair_handled_${suffix} = true`);
        lines.push("    break");
        lines.push("  end");
        lines.push(`  if state_pair_try_${suffix} < ${attempts} then sleep(${intervalSeconds}) end`);
        lines.push("end");
        lines.push(`if not state_pair_handled_${suffix} then`);
        if (skipOnTimeout) {
          lines.push(`  reportStep("state_pair_timeout_skip:${escapeLuaString(firstImage)}|${escapeLuaString(secondImage)}")`);
        } else {
          appendTimeoutLines(lines, params, `state_pair_timeout:${firstImage}|${secondImage}`, suffix);
        }
        lines.push("end");
      } else {
        const afterAttempts = Math.max(1, Math.ceil(afterFirstSecondTimeoutMs / intervalMs));
        lines.push(`local state_pair_handled_${suffix} = false`);
        lines.push(`for state_pair_try_${suffix} = 1, ${attempts} do`);
        const firstFindArgs = imageSearchOptionVars.first ? `1, ${firstScore}${imageOptionsArg(imageSearchOptionVars.first)}` : firstScore;
        lines.push(`  local first_x_${suffix}, first_y_${suffix} = findImage("${escapeLuaString(firstImage)}", ${firstFindArgs})`);
        lines.push(`  if first_x_${suffix} ~= nil and first_y_${suffix} ~= nil and first_x_${suffix} >= 0 and first_y_${suffix} >= 0 then`);
        const firstMode = String(params.first_action_mode || "self").trim().toLowerCase();
        if (firstMode === "image") {
          const targetImage = String(params.first_target_image || "").trim();
          const targetScore = threshold(params.first_target_threshold, 0.9).toFixed(3);
          const targetFindArgs = imageSearchOptionVars.first_target ? `1, ${targetScore}${imageOptionsArg(imageSearchOptionVars.first_target)}` : targetScore;
          lines.push(`    local first_target_x_${suffix}, first_target_y_${suffix} = findImage("${escapeLuaString(targetImage)}", ${targetFindArgs})`);
          lines.push(`    if first_target_x_${suffix} == nil or first_target_y_${suffix} == nil or first_target_x_${suffix} < 0 or first_target_y_${suffix} < 0 then fail("state_pair_first_target_timeout:${escapeLuaString(targetImage)}") end`);
          lines.push(`    local first_tap_ok_${suffix} = tapNorm(first_target_x_${suffix}, first_target_y_${suffix})`);
          lines.push(`    reportStep("state_pair_first_target_tap:${escapeLuaString(firstImage)}->${escapeLuaString(targetImage)}:ok=" .. tostring(first_tap_ok_${suffix}))`);
          lines.push(`    if not first_tap_ok_${suffix} then fail("state_pair_first_target_tap_failed:${escapeLuaString(targetImage)}") end`);
        } else if (firstMode === "coordinate") {
          lines.push(`    local first_tap_ok_${suffix} = tapNorm(${number(params.first_x).toFixed(6)}, ${number(params.first_y).toFixed(6)})`);
          lines.push(`    reportStep("state_pair_first_coord_tap:${escapeLuaString(firstImage)}:ok=" .. tostring(first_tap_ok_${suffix}))`);
          lines.push(`    if not first_tap_ok_${suffix} then fail("state_pair_first_coord_tap_failed:${escapeLuaString(firstImage)}") end`);
        } else {
          lines.push(`    local first_tap_ok_${suffix} = tapNorm(first_x_${suffix}, first_y_${suffix})`);
          lines.push(`    reportStep("state_pair_first_tap:${escapeLuaString(firstImage)}:ok=" .. tostring(first_tap_ok_${suffix}))`);
          lines.push(`    if not first_tap_ok_${suffix} then fail("state_pair_first_tap_failed:${escapeLuaString(firstImage)}") end`);
        }
        lines.push(`    state_pair_handled_${suffix} = true`);
        if (truthy(params.check_second_after_first)) {
          lines.push(`    if ${afterFirstWaitMs} > 0 then sleep(${afterFirstWaitMs}) end`);
          lines.push(`    local second_after_x_${suffix}, second_after_y_${suffix} = -1, -1`);
          lines.push(`    for second_after_try_${suffix} = 1, ${afterAttempts} do`);
          const secondFindArgs = imageSearchOptionVars.second ? `1, ${secondScore}${imageOptionsArg(imageSearchOptionVars.second)}` : secondScore;
          lines.push(`      second_after_x_${suffix}, second_after_y_${suffix} = findImage("${escapeLuaString(secondImage)}", ${secondFindArgs})`);
          lines.push(`      if second_after_x_${suffix} ~= nil and second_after_y_${suffix} ~= nil and second_after_x_${suffix} >= 0 and second_after_y_${suffix} >= 0 then break end`);
          lines.push(`      if second_after_try_${suffix} < ${afterAttempts} then sleep(${intervalMs}) end`);
          lines.push("    end");
          lines.push(`    if second_after_x_${suffix} == nil or second_after_y_${suffix} == nil or second_after_x_${suffix} < 0 or second_after_y_${suffix} < 0 then fail("state_pair_second_after_first_timeout:${escapeLuaString(secondImage)}") end`);
          if (String(params.second_action_mode || "coordinate").trim().toLowerCase() === "image") {
            const targetImage = String(params.second_target_image || "").trim();
            const targetScore = threshold(params.second_target_threshold, 0.9).toFixed(3);
            const targetFindArgs = imageSearchOptionVars.second_target ? `1, ${targetScore}${imageOptionsArg(imageSearchOptionVars.second_target)}` : targetScore;
            lines.push(`    local second_target_x_${suffix}, second_target_y_${suffix} = findImage("${escapeLuaString(targetImage)}", ${targetFindArgs})`);
            lines.push(`    if second_target_x_${suffix} == nil or second_target_y_${suffix} == nil or second_target_x_${suffix} < 0 or second_target_y_${suffix} < 0 then fail("state_pair_second_target_timeout:${escapeLuaString(targetImage)}") end`);
            lines.push(`    tapNorm(second_target_x_${suffix}, second_target_y_${suffix})`);
          } else {
            lines.push(`    tapNorm(${number(params.second_x).toFixed(6)}, ${number(params.second_y).toFixed(6)})`);
          }
        }
        lines.push("    break");
        lines.push("  end");
        const secondFindArgs = imageSearchOptionVars.second ? `1, ${secondScore}${imageOptionsArg(imageSearchOptionVars.second)}` : secondScore;
        lines.push(`  local second_x_${suffix}, second_y_${suffix} = findImage("${escapeLuaString(secondImage)}", ${secondFindArgs})`);
        lines.push(`  if second_x_${suffix} ~= nil and second_y_${suffix} ~= nil and second_x_${suffix} >= 0 and second_y_${suffix} >= 0 then`);
        if (String(params.second_action_mode || "coordinate").trim().toLowerCase() === "image") {
          const targetImage = String(params.second_target_image || "").trim();
          const targetScore = threshold(params.second_target_threshold, 0.9).toFixed(3);
          const targetFindArgs = imageSearchOptionVars.second_target ? `1, ${targetScore}${imageOptionsArg(imageSearchOptionVars.second_target)}` : targetScore;
          lines.push(`    local second_target_x_${suffix}, second_target_y_${suffix} = findImage("${escapeLuaString(targetImage)}", ${targetFindArgs})`);
          lines.push(`    if second_target_x_${suffix} == nil or second_target_y_${suffix} == nil or second_target_x_${suffix} < 0 or second_target_y_${suffix} < 0 then fail("state_pair_second_target_timeout:${escapeLuaString(targetImage)}") end`);
          lines.push(`    tapNorm(second_target_x_${suffix}, second_target_y_${suffix})`);
        } else {
          lines.push(`    tapNorm(${number(params.second_x).toFixed(6)}, ${number(params.second_y).toFixed(6)})`);
        }
        lines.push(`    state_pair_handled_${suffix} = true`);
        lines.push("    break");
        lines.push("  end");
        lines.push(`  if state_pair_try_${suffix} < ${attempts} then sleep(${intervalMs}) end`);
        lines.push("end");
        lines.push(`if not state_pair_handled_${suffix} then`);
        if (skipOnTimeout) {
          lines.push(`  reportStep("state_pair_timeout_skip:${escapeLuaString(firstImage)}|${escapeLuaString(secondImage)}")`);
        } else {
          appendTimeoutLines(lines, params, `state_pair_timeout:${firstImage}|${secondImage}`, suffix);
        }
        lines.push("end");
      }
      return;
    }
    if (block.type === "tap_if_image") {
      const suffix = luaSuffix(block);
      const conditionImages = conditionImagePaths(params);
      const conditionImage = conditionImages[0] || String(params.condition_image || "").trim();
      const conditionLabel = conditionImages.join("|") || conditionImage;
      const mode = String(params.action_mode || "coordinate").trim().toLowerCase() === "image" ? "image" : "coordinate";
      const timeoutMs = positiveInt(params.timeout_ms, 3000, 1, 3600000);
      const intervalMs = positiveInt(params.interval_ms, 500, 100, 60000);
      const conditionOptionsVar = appendImageSearchOptionsVar(lines, suffix, "conditional_condition", imageSearchOptions(params, "condition", context));
      const targetOptionsVar = appendImageSearchOptionsVar(lines, suffix, "conditional_target", imageSearchOptions(params, "target", context));
      const conditionSpecs = conditionImages.map((path) => {
        const primaryAnchor = path === conditionImage ? imageAnchorFor(params, "condition_image", context) : null;
        return {
          path,
          score: imageThresholdForPath(path, params.threshold, context, 0.95).toFixed(3),
          anchor: imageAnchorForPath(path, context) || primaryAnchor,
        };
      });
      if (!conditionSpecs.length) {
        lines.push('fail("conditional_image_missing")');
        return;
      }
      if (isIOSControl) {
        const timeoutSeconds = luaNumber(timeoutMs / 1000, 3);
        const perProbeMs = Math.max(150, Math.min(600, Math.floor(intervalMs / Math.max(1, conditionSpecs.length))));
        const perProbeSeconds = luaNumber(perProbeMs / 1000, 3);
        const attempts = Math.max(1, Math.ceil(timeoutMs / Math.max(1, perProbeMs * conditionSpecs.length)));
        lines.push(`local condition_specs_${suffix} = {`);
        for (const spec of conditionSpecs) {
          const anchorFields = spec.anchor
            ? `, anchor_x = ${luaNumber(spec.anchor.x, 6)}, anchor_y = ${luaNumber(spec.anchor.y, 6)}, anchor_radius = ${luaNumber(spec.anchor.radius, 6)}`
            : "";
          lines.push(`  { path = "${escapeLuaString(spec.path)}", threshold = ${spec.score}${anchorFields} },`);
        }
        lines.push("}");
        lines.push(`local condition_match_${suffix} = nil`);
        lines.push(`local condition_image_path_${suffix} = nil`);
        lines.push(`local condition_spec_${suffix} = nil`);
        appendBlockHUDReport(lines, block, context, "running", "", "tìm ảnh A");
        lines.push(`reportStep("conditional_image_probe_start:${escapeLuaString(conditionLabel)}:count=${conditionSpecs.length}:mode=${escapeLuaString(mode)}:timeout_ms=${timeoutMs}:interval_ms=${intervalMs}")`);
        if (conditionSpecs.length === 1) {
          lines.push(`condition_spec_${suffix} = condition_specs_${suffix}[1]`);
          lines.push(`condition_image_path_${suffix} = condition_spec_${suffix}.path`);
          lines.push(`condition_match_${suffix} = waitForImage(condition_spec_${suffix}.path, ${timeoutSeconds}, condition_spec_${suffix}.threshold${imageOptionsArg(conditionOptionsVar)})`);
        } else {
          lines.push(`for condition_try_${suffix} = 1, ${attempts} do`);
          lines.push(`  for _, condition_probe_${suffix} in ipairs(condition_specs_${suffix}) do`);
          lines.push(`    local condition_candidate_${suffix} = waitForImage(condition_probe_${suffix}.path, ${perProbeSeconds}, condition_probe_${suffix}.threshold${imageOptionsArg(conditionOptionsVar)})`);
          lines.push(`    if condition_candidate_${suffix} then`);
          lines.push(`      condition_match_${suffix} = condition_candidate_${suffix}`);
          lines.push(`      condition_image_path_${suffix} = condition_probe_${suffix}.path`);
          lines.push(`      condition_spec_${suffix} = condition_probe_${suffix}`);
          lines.push("      break");
          lines.push("    end");
          lines.push("  end");
          lines.push(`  if condition_match_${suffix} then break end`);
          lines.push("end");
        }
        lines.push(`if condition_match_${suffix} then`);
        lines.push(`  reportStep("conditional_image_probe_hit:" .. tostring(condition_image_path_${suffix}) .. ":x=" .. tostring(condition_match_${suffix}.x) .. ":y=" .. tostring(condition_match_${suffix}.y) .. ":norm_x=" .. tostring(condition_match_${suffix}.norm_x) .. ":norm_y=" .. tostring(condition_match_${suffix}.norm_y) .. ":score=" .. tostring(condition_match_${suffix}.score or condition_match_${suffix}.confidence or condition_match_${suffix}.similarity) .. ":reason=" .. tostring(condition_match_${suffix}.reason) .. ":debug=" .. tostring(condition_match_${suffix}.debug_path) .. ":diagnostic=" .. tostring(condition_match_${suffix}.diagnostic))`);
        lines.push("else");
        lines.push(`  reportStep("conditional_image_probe_miss:${escapeLuaString(conditionLabel)}")`);
        lines.push("end");
        lines.push(`if condition_match_${suffix} and condition_spec_${suffix} and condition_spec_${suffix}.anchor_x ~= nil and condition_match_${suffix}.norm_x ~= nil and condition_match_${suffix}.norm_y ~= nil then`);
        lines.push(`  local condition_dx_${suffix} = math.abs(condition_match_${suffix}.norm_x - condition_spec_${suffix}.anchor_x)`);
        lines.push(`  local condition_dy_${suffix} = math.abs(condition_match_${suffix}.norm_y - condition_spec_${suffix}.anchor_y)`);
        lines.push(`  if condition_dx_${suffix} > condition_spec_${suffix}.anchor_radius or condition_dy_${suffix} > condition_spec_${suffix}.anchor_radius then`);
        lines.push(`    reportStep("conditional_image_anchor_mismatch:" .. tostring(condition_image_path_${suffix}) .. ":x=" .. tostring(condition_match_${suffix}.norm_x) .. ":y=" .. tostring(condition_match_${suffix}.norm_y) .. ":anchor=" .. tostring(condition_spec_${suffix}.anchor_x) .. "," .. tostring(condition_spec_${suffix}.anchor_y) .. ":radius=" .. tostring(condition_spec_${suffix}.anchor_radius))`);
        lines.push(`    fail("conditional_image_anchor_mismatch:" .. tostring(condition_image_path_${suffix}))`);
        lines.push("  end");
        lines.push("end");
        lines.push(`if condition_match_${suffix} then`);
        lines.push(`  reportStep("conditional_image_seen:" .. tostring(condition_image_path_${suffix}) .. ":x=" .. tostring(condition_match_${suffix}.x) .. ":y=" .. tostring(condition_match_${suffix}.y) .. ":norm_x=" .. tostring(condition_match_${suffix}.norm_x) .. ":norm_y=" .. tostring(condition_match_${suffix}.norm_y))`);
        if (mode === "image") {
          const targetImage = String(params.target_image || "").trim();
          const targetTimeoutMs = positiveInt(params.target_timeout_ms, 3000, 1, 3600000);
          const targetSeconds = luaNumber(targetTimeoutMs / 1000, 3);
          const targetScore = imageThresholdForParam(params, "target_image", params.target_threshold, context, 0.95, false).toFixed(3);
          appendBlockHUDReport(lines, block, context, "running", "  ", "tìm ảnh B");
          lines.push(`  reportStep("conditional_target_probe_start:" .. tostring(condition_image_path_${suffix}) .. "->${escapeLuaString(targetImage)}:threshold=${targetScore}:timeout_ms=${targetTimeoutMs}")`);
          lines.push(`  local target_match_${suffix} = waitForImage("${escapeLuaString(targetImage)}", ${targetSeconds}, ${targetScore}${imageOptionsArg(targetOptionsVar)})`);
          lines.push(`  if target_match_${suffix} then`);
          lines.push(`    reportStep("conditional_target_probe_hit:${escapeLuaString(targetImage)}:x=" .. tostring(target_match_${suffix}.x) .. ":y=" .. tostring(target_match_${suffix}.y) .. ":norm_x=" .. tostring(target_match_${suffix}.norm_x) .. ":norm_y=" .. tostring(target_match_${suffix}.norm_y) .. ":score=" .. tostring(target_match_${suffix}.score or target_match_${suffix}.confidence or target_match_${suffix}.similarity) .. ":reason=" .. tostring(target_match_${suffix}.reason) .. ":debug=" .. tostring(target_match_${suffix}.debug_path) .. ":diagnostic=" .. tostring(target_match_${suffix}.diagnostic))`);
          lines.push("  else");
          lines.push(`    reportStep("conditional_target_probe_miss:${escapeLuaString(targetImage)}")`);
          lines.push("  end");
          lines.push(`  if not target_match_${suffix} then fail("conditional_target_image_timeout:${escapeLuaString(targetImage)}") end`);
          appendNamedImageAnchorGuard(lines, imageAnchorFor(params, "target_image", context), suffix, targetImage, "target_match", "conditional_target_image_anchor_mismatch", true);
          lines.push(`  local target_x_${suffix}, target_y_${suffix} = target_match_${suffix}.x, target_match_${suffix}.y`);
          lines.push(`  reportStep("conditional_target_tap_method:${escapeLuaString(targetImage)}:method=pre_match_coordinate:pre_x=" .. tostring(target_x_${suffix}) .. ":pre_y=" .. tostring(target_y_${suffix}) .. ":pre_norm_x=" .. tostring(target_match_${suffix}.norm_x) .. ":pre_norm_y=" .. tostring(target_match_${suffix}.norm_y))`);
          appendBlockHUDReport(lines, block, context, "running", "  ", "nhấn ảnh B");
          lines.push(`  local conditional_tap_ok_${suffix} = false`);
          lines.push(`  local conditional_tap_x_${suffix}, conditional_tap_y_${suffix} = target_x_${suffix}, target_y_${suffix}`);
          lines.push(`  if target_match_${suffix}.norm_x ~= nil and target_match_${suffix}.norm_y ~= nil then`);
          lines.push(`    conditional_tap_ok_${suffix} = tapNorm(target_match_${suffix}.norm_x, target_match_${suffix}.norm_y)`);
          lines.push("  else");
          lines.push(`    conditional_tap_ok_${suffix} = tap(target_x_${suffix}, target_y_${suffix})`);
          lines.push("  end");
          lines.push(`  reportStep("conditional_image_target_tap:" .. tostring(condition_image_path_${suffix}) .. "->${escapeLuaString(targetImage)}:ok=" .. tostring(conditional_tap_ok_${suffix}) .. ":x=" .. tostring(conditional_tap_x_${suffix}) .. ":y=" .. tostring(conditional_tap_y_${suffix}) .. ":pre_x=" .. tostring(target_x_${suffix}) .. ":pre_y=" .. tostring(target_y_${suffix}) .. ":verify=pre_match_coordinate")`);
          lines.push(`  if not conditional_tap_ok_${suffix} then fail("conditional_target_image_tap_failed:${escapeLuaString(targetImage)}") end`);
        } else {
          const x = number(params.x).toFixed(6);
          const y = number(params.y).toFixed(6);
          lines.push(`  reportStep("conditional_action_mode:" .. tostring(condition_image_path_${suffix}) .. ":mode=coordinate:x=${x}:y=${y}")`);
          lines.push(`  local conditional_tap_ok_${suffix} = tapNorm(${x}, ${y})`);
          lines.push(`  reportStep("conditional_coord_tap:" .. tostring(condition_image_path_${suffix}) .. ":ok=" .. tostring(conditional_tap_ok_${suffix}) .. ":x=${x}:y=${y}")`);
          lines.push(`  if not conditional_tap_ok_${suffix} then fail("conditional_coord_tap_failed:" .. tostring(condition_image_path_${suffix})) end`);
        }
        lines.push("else");
        lines.push(`  reportStep("conditional_image_not_seen_skip:${escapeLuaString(conditionLabel)}")`);
        lines.push("end");
      } else {
        const attempts = Math.max(1, Math.ceil(timeoutMs / intervalMs));
        const legacyScore = threshold(params.threshold, 0.95).toFixed(3);
        lines.push(`local condition_x_${suffix}, condition_y_${suffix} = -1, -1`);
        lines.push(`local condition_image_path_${suffix} = ""`);
        lines.push(`local condition_images_${suffix} = {`);
        for (const spec of conditionSpecs) lines.push(`  "${escapeLuaString(spec.path)}",`);
        lines.push("}");
        appendBlockHUDReport(lines, block, context, "running", "", "tìm ảnh A");
        lines.push(`reportStep("conditional_image_probe_start:${escapeLuaString(conditionLabel)}:mode=${escapeLuaString(mode)}:threshold=${legacyScore}:timeout_ms=${timeoutMs}:attempts=${attempts}")`);
        lines.push(`for condition_try_${suffix} = 1, ${attempts} do`);
        lines.push(`  for _, condition_image_${suffix} in ipairs(condition_images_${suffix}) do`);
        const conditionFindArgs = conditionOptionsVar ? `1, ${legacyScore}${imageOptionsArg(conditionOptionsVar)}` : legacyScore;
        lines.push(`    condition_x_${suffix}, condition_y_${suffix} = findImage(condition_image_${suffix}, ${conditionFindArgs})`);
        lines.push(`    reportStep("conditional_image_probe_try:" .. tostring(condition_image_${suffix}) .. ":try=" .. tostring(condition_try_${suffix}) .. ":x=" .. tostring(condition_x_${suffix}) .. ":y=" .. tostring(condition_y_${suffix}))`);
        lines.push(`    if condition_x_${suffix} ~= nil and condition_y_${suffix} ~= nil and condition_x_${suffix} >= 0 and condition_y_${suffix} >= 0 then`);
        lines.push(`      condition_image_path_${suffix} = condition_image_${suffix}`);
        lines.push("      break");
        lines.push("    end");
        lines.push("  end");
        lines.push(`  if condition_image_path_${suffix} ~= "" then break end`);
        lines.push(`  if condition_try_${suffix} < ${attempts} then if msleep then msleep(${intervalMs}) elseif sleep then sleep(${luaNumber(intervalMs / 1000, 3)}) end end`);
        lines.push("end");
        lines.push(`if condition_x_${suffix} == nil or condition_y_${suffix} == nil or condition_x_${suffix} < 0 or condition_y_${suffix} < 0 then`);
        lines.push(`  reportStep("conditional_image_not_seen_skip:${escapeLuaString(conditionLabel)}")`);
        lines.push("else");
        lines.push(`  reportStep("conditional_image_seen:" .. tostring(condition_image_path_${suffix}) .. ":x=" .. tostring(condition_x_${suffix}) .. ":y=" .. tostring(condition_y_${suffix}))`);
        if (mode === "image") {
          const targetImage = String(params.target_image || "").trim();
          const targetScore = threshold(params.target_threshold, 0.95).toFixed(3);
          appendBlockHUDReport(lines, block, context, "running", "  ", "tìm ảnh B");
          lines.push(`  reportStep("conditional_target_probe_start:" .. tostring(condition_image_path_${suffix}) .. "->${escapeLuaString(targetImage)}:threshold=${targetScore}")`);
          const targetFindArgs = targetOptionsVar ? `1, ${targetScore}${imageOptionsArg(targetOptionsVar)}` : targetScore;
          lines.push(`  local target_x_${suffix}, target_y_${suffix} = findImage("${escapeLuaString(targetImage)}", ${targetFindArgs})`);
          lines.push(`  reportStep("conditional_target_probe_result:${escapeLuaString(targetImage)}:x=" .. tostring(target_x_${suffix}) .. ":y=" .. tostring(target_y_${suffix}))`);
          lines.push(`  if target_x_${suffix} == nil or target_y_${suffix} == nil or target_x_${suffix} < 0 or target_y_${suffix} < 0 then fail("conditional_target_image_timeout:${escapeLuaString(targetImage)}") end`);
          appendBlockHUDReport(lines, block, context, "running", "  ", "nhấn ảnh B");
          lines.push(`  local conditional_tap_ok_${suffix} = tapNorm(target_x_${suffix}, target_y_${suffix})`);
          lines.push(`  reportStep("conditional_image_target_tap:" .. tostring(condition_image_path_${suffix}) .. "->${escapeLuaString(targetImage)}:ok=" .. tostring(conditional_tap_ok_${suffix}) .. ":x=" .. tostring(target_x_${suffix}) .. ":y=" .. tostring(target_y_${suffix}))`);
        } else {
          const x = number(params.x).toFixed(6);
          const y = number(params.y).toFixed(6);
          lines.push(`  reportStep("conditional_action_mode:" .. tostring(condition_image_path_${suffix}) .. ":mode=coordinate:x=${x}:y=${y}")`);
          lines.push(`  local conditional_tap_ok_${suffix} = tapNorm(${x}, ${y})`);
          lines.push(`  reportStep("conditional_coord_tap:" .. tostring(condition_image_path_${suffix}) .. ":ok=" .. tostring(conditional_tap_ok_${suffix}) .. ":x=${x}:y=${y}")`);
        }
        lines.push("end");
      }
      return;
    }
    if (block.type === "wait_image" || block.type === "tap_image" || block.type === "tap_image_optional") {
      const suffix = luaSuffix(block);
      const image = String(params.image || "").trim();
      const timeoutMs = positiveInt(params.timeout_ms, 300000, 1, 3600000);
      const score = imageThresholdForParam(params, "image", params.threshold, context, 0.95).toFixed(3);
      const imageOptionsVar = appendImageSearchOptionsVar(lines, suffix, block.type, imageSearchOptions(params, "image", context));
      if (isIOSControl) {
        const timeoutSeconds = luaNumber(timeoutMs / 1000, 3);
        if (block.type === "tap_image_optional") {
          lines.push(`local image_match_${suffix} = waitForImage("${escapeLuaString(image)}", ${timeoutSeconds}, ${score}${imageOptionsArg(imageOptionsVar)})`);
          const anchor = imageAnchor(params, context);
          if (anchor) {
            lines.push(`if image_match_${suffix} then`);
            lines.push(`  if image_match_${suffix}.norm_x ~= nil and image_match_${suffix}.norm_y ~= nil then`);
            lines.push(`    local image_dx_${suffix} = math.abs(image_match_${suffix}.norm_x - ${luaNumber(anchor.x, 6)})`);
            lines.push(`    local image_dy_${suffix} = math.abs(image_match_${suffix}.norm_y - ${luaNumber(anchor.y, 6)})`);
            lines.push(`    if image_dx_${suffix} > ${luaNumber(anchor.radius, 6)} or image_dy_${suffix} > ${luaNumber(anchor.radius, 6)} then`);
            lines.push(`    reportStep("optional_image_anchor_mismatch_skip:${escapeLuaString(image)}:x=" .. tostring(image_match_${suffix}.norm_x) .. ":y=" .. tostring(image_match_${suffix}.norm_y) .. ":anchor=${luaNumber(anchor.x, 6)},${luaNumber(anchor.y, 6)}")`);
            lines.push(`    image_match_${suffix} = nil`);
            lines.push("    end");
            lines.push("  end");
            lines.push("end");
          }
          lines.push(`if image_match_${suffix} then`);
          lines.push(`  local image_x_${suffix}, image_y_${suffix} = image_match_${suffix}.x, image_match_${suffix}.y`);
          lines.push(`  local image_tap_ok_${suffix} = tapNorm(image_x_${suffix}, image_y_${suffix})`);
          lines.push(`  reportStep("optional_image_tap:${escapeLuaString(image)}:ok=" .. tostring(image_tap_ok_${suffix}) .. ":x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}) .. ":source=pre_matched")`);
          lines.push(`  if not image_tap_ok_${suffix} then fail("optional_image_tap_failed:${escapeLuaString(image)}") end`);
          lines.push("else");
          lines.push(`  reportStep("optional_image_not_seen_skip:${escapeLuaString(image)}")`);
          lines.push("end");
        } else if (block.type === "tap_image") {
          lines.push(`local image_match_${suffix} = waitForImage("${escapeLuaString(image)}", ${timeoutSeconds}, ${score}${imageOptionsArg(imageOptionsVar)})`);
          lines.push(`if not image_match_${suffix} then`);
          appendTimeoutLines(lines, params, `${block.type}_timeout:${image || block.id}`, suffix);
          lines.push("end");
          appendImageAnchorGuard(lines, params, suffix, image, context);
          lines.push(`local image_x_${suffix}, image_y_${suffix} = image_match_${suffix}.x, image_match_${suffix}.y`);
          lines.push(`local image_tap_ok_${suffix} = tapNorm(image_x_${suffix}, image_y_${suffix})`);
          lines.push(`reportStep("image_tap:${escapeLuaString(image)}:ok=" .. tostring(image_tap_ok_${suffix}) .. ":x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}) .. ":source=pre_matched")`);
          lines.push(`if not image_tap_ok_${suffix} then fail("tap_image_failed:${escapeLuaString(image)}") end`);
        } else {
          lines.push(`local image_match_${suffix} = waitForImage("${escapeLuaString(image)}", ${timeoutSeconds}, ${score}${imageOptionsArg(imageOptionsVar)})`);
          lines.push(`if not image_match_${suffix} then`);
          appendTimeoutLines(lines, params, `${block.type}_timeout:${image || block.id}`, suffix);
          lines.push("end");
          appendImageAnchorGuard(lines, params, suffix, image, context);
          lines.push(`reportStep("image_found:${escapeLuaString(image)}:x=" .. tostring(image_match_${suffix}.x) .. ":y=" .. tostring(image_match_${suffix}.y))`);
        }
      } else {
        const intervalMs = positiveInt(params.interval_ms, 1000, 100, 60000);
        const attempts = Math.max(1, Math.ceil(timeoutMs / intervalMs));
        lines.push(`local image_x_${suffix}, image_y_${suffix} = -1, -1`);
        lines.push(`for image_try_${suffix} = 1, ${attempts} do`);
        const findArgs = imageOptionsVar ? `1, ${score}${imageOptionsArg(imageOptionsVar)}` : score;
        lines.push(`  image_x_${suffix}, image_y_${suffix} = findImage("${escapeLuaString(image)}", ${findArgs})`);
        lines.push(`  reportStep("image_probe:${escapeLuaString(image)}:try=" .. tostring(image_try_${suffix}) .. ":x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}))`);
        lines.push(`  if image_x_${suffix} ~= nil and image_y_${suffix} ~= nil and image_x_${suffix} >= 0 and image_y_${suffix} >= 0 then break end`);
        lines.push(`  if image_try_${suffix} < ${attempts} then sleep(${intervalMs}) end`);
        lines.push("end");
        if (block.type === "tap_image_optional") {
          lines.push(`if image_x_${suffix} == nil or image_y_${suffix} == nil or image_x_${suffix} < 0 or image_y_${suffix} < 0 then`);
          lines.push(`  reportStep("optional_image_not_seen_skip:${escapeLuaString(image)}")`);
          lines.push("else");
          lines.push(`  local image_tap_ok_${suffix} = tapNorm(image_x_${suffix}, image_y_${suffix})`);
          lines.push(`  reportStep("optional_image_tap:${escapeLuaString(image)}:ok=" .. tostring(image_tap_ok_${suffix}) .. ":x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}))`);
          lines.push(`  if not image_tap_ok_${suffix} then fail("optional_image_tap_failed:${escapeLuaString(image)}") end`);
          lines.push("end");
        } else {
          lines.push(`if image_x_${suffix} == nil or image_y_${suffix} == nil or image_x_${suffix} < 0 or image_y_${suffix} < 0 then`);
          appendTimeoutLines(lines, params, `${block.type}_timeout:${image || block.id}`, suffix);
          lines.push("end");
          lines.push(`reportStep("image_found:${escapeLuaString(image)}:x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}))`);
        }
        if (block.type === "tap_image") {
          lines.push(`local image_tap_ok_${suffix} = tapNorm(image_x_${suffix}, image_y_${suffix})`);
          lines.push(`reportStep("image_tap:${escapeLuaString(image)}:ok=" .. tostring(image_tap_ok_${suffix}) .. ":x=" .. tostring(image_x_${suffix}) .. ":y=" .. tostring(image_y_${suffix}))`);
          lines.push(`if not image_tap_ok_${suffix} then fail("tap_image_failed:${escapeLuaString(image)}") end`);
        }
      }
      return;
    }
    if (block.type === "notify") {
      lines.push(`reportStep("${escapeLuaString(params.message || "notify")}")`);
      return;
    }
    if (block.type === "set_variable") {
      lines.push(`reportStep("setVar:${escapeLuaString(params.name || "value")}")`);
      return;
    }
    lines.push(`reportStep("unsupported_block:${escapeLuaString(block.type)}")`);
  }

  function collectRequiredCapabilities(workflow) {
    const capabilities = new Set(["touch"]);
    function visit(block) {
      if (!block) return;
      if (block.type === "hardware_home") capabilities.add("hardware_home");
      if (block.type === "open_app") capabilities.add("open_app");
      if (block.type === "open_url") {
        capabilities.add("open_url");
        capabilities.add("open_app");
        capabilities.add("text_input");
      }
      if (block.type === "extok_tiktok_job") {
        capabilities.add("http");
        capabilities.add("open_url");
        capabilities.add("vision_text");
      }
      if (block.type === "kill_app") capabilities.add("app_kill");
      if (block.type === "screenshot") capabilities.add("screenshot");
      if (block.type === "input_text") capabilities.add("text_input");
      if (["wait_text", "tap_text"].includes(block.type)) capabilities.add("vision_text");
      if (["wait_image", "tap_image", "tap_image_optional", "tap_if_image", "tap_image_state_pair"].includes(block.type)) capabilities.add("vision_image");
      if (wantsTelegramOnTimeout(block.params || {})) {
        capabilities.add("screenshot");
        capabilities.add("telegram");
      }
      for (const child of block.body || []) visit(child);
    }
    for (const block of workflow.blocks || []) visit(block);
    return Array.from(capabilities);
  }

  async function sha256Hex(text) {
    if (global.crypto?.subtle) {
      const bytes = new TextEncoder().encode(text);
      const digest = await global.crypto.subtle.digest("SHA-256", bytes);
      return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
    }
    let hash = 2166136261;
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `fnv1a-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  async function exportWorkflowPackage(workflow, options = {}) {
    const normalized = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
    const targetDeviceIds = Array.isArray(options.targetDeviceIds) ? options.targetDeviceIds.filter(Boolean) : [];
    const rawLua = String(normalized.raw_lua || "").trim();
    const apiProfile = profileName(options.apiProfile || normalized.api_profile || (rawLua ? "ioscontrol-v1" : "hidprobe-v1"));
    const content = orderedLines(normalized, { apiProfile }).join("\n");
    const version = stableVersion(normalized);
    return {
      script_id: options.scriptId || `${rawLua ? "lua" : "workflow"}-${normalized.id}`,
      name: normalized.name || "Workflow",
      version,
      target_device_id: targetDeviceIds[0] || options.targetDeviceId || "",
      target_device_ids: targetDeviceIds,
      language: "lua",
      api_profile: apiProfile,
      entrypoint: "main.lua",
      content,
      checksum_sha256: await sha256Hex(content),
      created_at: new Date().toISOString(),
      workflow_source_id: normalized.id,
      debug_default: options.debugDefault !== false,
      required_capabilities: collectRequiredCapabilities(normalized),
      assets: packageAssets(normalized, content),
    };
  }

  function workflowToLua(workflow, options = {}) {
    const normalized = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
    const rawLua = String(normalized.raw_lua || "").trim();
    const apiProfile = profileName(options.apiProfile || normalized.api_profile || (rawLua ? "ioscontrol-v1" : "hidprobe-v1"));
    return orderedLines(normalized, { apiProfile }).join("\n");
  }

  global.HidWorkflowScriptExport = {
    exportWorkflowPackage,
    workflowToLua,
    sha256Hex,
  };
})(window);
