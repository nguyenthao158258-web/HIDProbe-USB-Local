"use strict";

(function attachSettings(global) {
  let modal = null;

  function ensureModal() {
    if (modal) return modal;
    modal = document.createElement("div");
    modal.className = "workflow-modal hidden";
    modal.innerHTML = `
      <div class="workflow-backdrop" data-settings-close="1"></div>
      <section class="workflow-panel settings-panel" role="dialog" aria-modal="true">
        <header class="workflow-panel-head">
          <strong>⚙️ Settings — AI Configuration</strong>
          <button class="hbtn" data-settings-close="1" type="button">Đóng</button>
        </header>
        <div class="settings-grid">
          <label>Provider
            <select id="ai-provider">
              <option value="local">Local fallback</option>
              <option value="openai">OpenAI</option>
              <option value="anthropic">Claude / Anthropic</option>
              <option value="gemini">Gemini</option>
            </select>
          </label>
          <label>Model <input id="ai-model" autocomplete="off" placeholder="gpt-4o-mini / claude-3-5-sonnet-latest"></label>
          <label>API Key <input id="ai-key" autocomplete="off" type="password" placeholder="sk-..."></label>
          <label>Temperature <input id="ai-temp" type="number" step="0.1" min="0" max="1" value="0.3"></label>
          <label>Max tokens <input id="ai-max" type="number" min="512" max="16000" value="4096"></label>
          <label class="wide">Custom prompt template
            <textarea id="ai-template" rows="8" placeholder="Để trống để dùng template mặc định"></textarea>
          </label>
        </div>
        <div class="workflow-toolbar">
          <button class="hbtn" id="ai-test" type="button">Test Connection</button>
          <button class="hbtn" id="ai-save" type="button">Lưu</button>
          <span id="ai-settings-status" class="workflow-status">—</span>
        </div>
      </section>`;
    document.body.appendChild(modal);
    modal.addEventListener("click", (event) => {
      if (event.target instanceof HTMLElement && event.target.dataset.settingsClose) close();
    });
    modal.querySelector("#ai-save").addEventListener("click", save);
    modal.querySelector("#ai-test").addEventListener("click", testConnection);
    return modal;
  }

  function fill() {
    const settings = global.HidWorkflowStorage.loadAiSettings();
    ensureModal().querySelector("#ai-provider").value = settings.provider;
    modal.querySelector("#ai-model").value = settings.model;
    modal.querySelector("#ai-key").value = settings.apiKey;
    modal.querySelector("#ai-temp").value = String(settings.temperature);
    modal.querySelector("#ai-max").value = String(settings.maxTokens);
    modal.querySelector("#ai-template").value = settings.promptTemplate;
    modal.querySelector("#ai-settings-status").textContent = `Token usage: ${Math.round(settings.tokenUsage || 0)}`;
  }

  function read() {
    return {
      provider: modal.querySelector("#ai-provider").value,
      model: modal.querySelector("#ai-model").value.trim(),
      apiKey: modal.querySelector("#ai-key").value.trim(),
      temperature: Number(modal.querySelector("#ai-temp").value) || 0.3,
      maxTokens: Number(modal.querySelector("#ai-max").value) || 4096,
      promptTemplate: modal.querySelector("#ai-template").value,
      tokenUsage: global.HidWorkflowStorage.loadAiSettings().tokenUsage || 0,
    };
  }

  function save() {
    global.HidWorkflowStorage.saveAiSettings(read());
    modal.querySelector("#ai-settings-status").textContent = "Đã lưu settings";
  }

  async function testConnection() {
    const status = modal.querySelector("#ai-settings-status");
    save();
    status.textContent = "Đang test...";
    const result = await new global.HidAiClient.AIClient(read()).testConnection();
    status.textContent = result.ok ? "✓ Kết nối OK" : `✗ ${result.error}`;
  }

  function open() {
    ensureModal();
    fill();
    modal.classList.remove("hidden");
  }

  function close() {
    if (modal) modal.classList.add("hidden");
  }

  global.HidSettings = { open, close };
})(window);
