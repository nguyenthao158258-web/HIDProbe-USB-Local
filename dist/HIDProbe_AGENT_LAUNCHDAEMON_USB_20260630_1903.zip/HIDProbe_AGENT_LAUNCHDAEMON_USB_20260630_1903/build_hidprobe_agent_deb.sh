#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
AGENT="$ROOT_DIR/HIDProbeApp/Resources/Agent/hidprobe_agent"
PLIST="$ROOT_DIR/HIDProbeApp/Resources/Agent/com.hidprobe.agent.plist"
OUT_DIR="$ROOT_DIR/dist"
PKG="$OUT_DIR/hidprobe-agent-deb-rootless"
VERSION="${VERSION:-1.0.0}"

if [ ! -f "$AGENT" ] || [ ! -f "$PLIST" ]; then
    echo "Missing agent/plist. Run: bash HIDProbeApp/Sources/Agent/helper/build_hidprobe_agent.sh"
    exit 1
fi

rm -rf "$PKG"
mkdir -p "$PKG/DEBIAN" "$PKG/var/jb/usr/local/bin" "$PKG/var/jb/Library/LaunchDaemons" "$OUT_DIR"
cp "$AGENT" "$PKG/var/jb/usr/local/bin/hidprobe_agent"
cp "$PLIST" "$PKG/var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist"
chmod 755 "$PKG/var/jb/usr/local/bin/hidprobe_agent"
chmod 644 "$PKG/var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist"

cat > "$PKG/DEBIAN/control" <<EOF
Package: com.hidprobe.agent
Name: HIDProbe Agent
Version: $VERSION
Architecture: iphoneos-arm64
Description: HIDProbe USB background command agent
Maintainer: HIDProbe Maintainer
Author: HIDProbe Maintainer
Section: Utilities
Priority: optional
EOF

cat > "$PKG/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e
chmod 755 /var/jb/usr/local/bin/hidprobe_agent
chmod 644 /var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist
chown root:wheel /var/jb/usr/local/bin/hidprobe_agent /var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist 2>/dev/null || true
launchctl bootout system /var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist 2>/dev/null || true
launchctl bootstrap system /var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist 2>/dev/null || launchctl load -w /var/jb/Library/LaunchDaemons/com.hidprobe.agent.plist 2>/dev/null || true
exit 0
EOF
chmod 755 "$PKG/DEBIAN/postinst"

DEB_OUT="$OUT_DIR/hidprobe-agent_${VERSION}_iphoneos-arm64.deb"
if command -v dpkg-deb >/dev/null 2>&1; then
    dpkg-deb --build "$PKG" "$DEB_OUT"
else
    echo "[deb] dpkg-deb not found; using ar/tar fallback"
    TMP="$OUT_DIR/hidprobe-agent-deb-tmp"
    rm -rf "$TMP"
    mkdir -p "$TMP/control" "$TMP/data"
    cp -R "$PKG/DEBIAN/." "$TMP/control/"
    (cd "$TMP/control" && tar -czf "$TMP/control.tar.gz" .)
    rsync -a --exclude DEBIAN "$PKG/." "$TMP/data/"
    (cd "$TMP/data" && tar -czf "$TMP/data.tar.gz" .)
    printf '2.0\n' > "$TMP/debian-binary"
    python3 - "$TMP" "$DEB_OUT" <<'PY'
import os
import sys
tmp, out = sys.argv[1], sys.argv[2]
members = ["debian-binary", "control.tar.gz", "data.tar.gz"]
with open(out, "wb") as fh:
    fh.write(b"!<arch>\n")
    for name in members:
        path = os.path.join(tmp, name)
        data = open(path, "rb").read()
        header = (
            f"{name}/".ljust(16) +
            f"{int(os.path.getmtime(path)):<12}" +
            f"{0:<6}" +
            f"{0:<6}" +
            f"{0o100644:<8}" +
            f"{len(data):<10}" +
            "`\n"
        ).encode("ascii")
        fh.write(header)
        fh.write(data)
        if len(data) % 2:
            fh.write(b"\n")
PY
    rm -rf "$TMP"
fi
echo "$DEB_OUT"
