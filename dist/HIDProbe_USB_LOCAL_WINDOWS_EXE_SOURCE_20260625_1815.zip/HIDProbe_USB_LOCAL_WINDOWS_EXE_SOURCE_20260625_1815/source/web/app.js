"use strict";

const NsPerMs = 1000000n;
const NsPerUs = 1000n;
const MaxLogLines = 220;
const MaxDecodeBackpressureDepth = 3;
const MaxRecentFrameAcks = 512;
const TilePayloadMagic = "HPTL1";
const StorageKeys = {
  devices: "hid_probe_farm_devices_v1",
  settings: "hid_probe_farm_settings_v2",
};

const els = {
  relayInput: document.getElementById("relay-input"),
  fitModeSelect: document.getElementById("fit-mode-select"),
  rotationSelect: document.getElementById("rotation-select"),
  zoomRange: document.getElementById("zoom-range"),
  zoomLabel: document.getElementById("zoom-label"),
  addDeviceButton: document.getElementById("add-device-button"),
  connectAllButton: document.getElementById("connect-all-button"),
  disconnectAllButton: document.getElementById("disconnect-all-button"),
  exportButton: document.getElementById("export-button"),
  importButton: document.getElementById("import-button"),
  fileImport: document.getElementById("file-import"),
  clearLogButton: document.getElementById("clear-log-button"),
  deviceGrid: document.getElementById("device-grid"),
  emptyState: document.getElementById("empty-state"),
  statOnline: document.getElementById("stat-online"),
  statOffline: document.getElementById("stat-offline"),
  statTotal: document.getElementById("stat-total"),
  selectedName: document.getElementById("selected-name"),
  selectedId: document.getElementById("selected-id"),
  selectedRelay: document.getElementById("selected-relay"),
  selectedHand: document.getElementById("selected-hand"),
  selectedStream: document.getElementById("selected-stream"),
  selectedLatency: document.getElementById("selected-latency"),
  selectedVideoRect: document.getElementById("selected-video-rect"),
  selectedFrameSeq: document.getElementById("selected-frame-seq"),
  selectedNote: document.getElementById("selected-note"),
  selectedConnectButton: document.getElementById("selected-connect-button"),
  selectedDisconnectButton: document.getElementById("selected-disconnect-button"),
  logOutput: document.getElementById("log-output"),
  addModal: document.getElementById("add-modal"),
  addDeviceForm: document.getElementById("add-device-form"),
  modalCloseButton: document.getElementById("modal-close-button"),
  modalCancelButton: document.getElementById("modal-cancel-button"),
  addDeviceId: document.getElementById("add-device-id"),
  addDeviceName: document.getElementById("add-device-name"),
  addDeviceNote: document.getElementById("add-device-note"),
  addDeviceSession: document.getElementById("add-device-session"),
  addDeviceToken: document.getElementById("add-device-token"),
};

const appState = {
  relayUrl: "",
  fitMode: "contain",
  rotation: 0,
  cardWidth: 160,
  devices: [],
  controllers: new Map(),
  selectedDeviceId: null,
  logs: [],
};

function defaultRelayUrl() {
  if (location.origin && location.origin !== "null") {
    return location.origin;
  }
  return "https://signal.hethongtudong.store:8443";
}

function normalizeRelayUrl(raw) {
  const value = (raw || "").trim();
  if (!value) {
    return defaultRelayUrl();
  }
  if (!value.includes("://")) {
    return `${location.protocol === "https:" ? "https" : "http"}://${value}`;
  }
  if (value.startsWith("wss://")) {
    return `https://${value.slice("wss://".length)}`;
  }
  if (value.startsWith("ws://")) {
    return `http://${value.slice("ws://".length)}`;
  }
  return value;
}

function toWebSocketUrl(baseUrl) {
  const normalized = normalizeRelayUrl(baseUrl);
  if (normalized.startsWith("https://")) {
    return `wss://${normalized.slice("https://".length)}`;
  }
  if (normalized.startsWith("http://")) {
    return `ws://${normalized.slice("http://".length)}`;
  }
  return normalized;
}

function buildApiUrl(path) {
  return new URL(path, `${normalizeRelayUrl(appState.relayUrl).replace(/\/+$/, "")}/`).toString();
}

function canonicalDeviceKey(rawId) {
  const value = String(rawId || "").trim();
  if (!value) {
    return "";
  }
  const match = value.match(/^(?:chung-iphone-)?0*([0-9]+)$/i);
  if (!match) {
    return value.toLowerCase();
  }
  return `chung-iphone-${String(Number(match[1] || "0")).padStart(2, "0")}`;
}

function normalizePhoneStatus(rawStatus) {
  return String(rawStatus || "").trim().toLowerCase();
}

function isPhoneRuntimeStatus(rawStatus) {
  const status = normalizePhoneStatus(rawStatus);
  return status === "registered" || status === "online" || status === "active" || status === "legacy_connected";
}

function preferCanonicalRecord(currentRecord, nextRecord) {
  if (!currentRecord) {
    return { ...nextRecord };
  }
  const currentIsCanonical = String(currentRecord.id || "").startsWith("chung-iphone-");
  const nextIsCanonical = String(nextRecord.id || "").startsWith("chung-iphone-");
  const base = nextIsCanonical && !currentIsCanonical ? nextRecord : currentRecord;
  const overlay = nextIsCanonical && !currentIsCanonical ? currentRecord : nextRecord;
  return {
    ...base,
    ...overlay,
    id: base.id || overlay.id,
    name: base.name || overlay.name || base.id || overlay.id,
    status: base.status || overlay.status || "",
    sessionId: base.sessionId || overlay.sessionId || "",
    authToken: base.authToken || overlay.authToken || "",
    connectUrl: base.connectUrl || overlay.connectUrl || "",
    signalUrl: base.signalUrl || overlay.signalUrl || "",
    transportKind: base.transportKind || overlay.transportKind || "",
    note: base.note || overlay.note || "",
  };
}

function epochNsNow() {
  return BigInt(Math.round((performance.timeOrigin + performance.now()) * 1000000));
}

function isValidEpochNs(value) {
  return typeof value === "bigint" && value > 1500000000000000000n;
}

function deltaMs(later, earlier) {
  if (!isValidEpochNs(later) || !isValidEpochNs(earlier) || later < earlier) {
    return null;
  }
  return Number((later - earlier) / NsPerMs);
}

function fmtMs(value) {
  return value == null ? "-" : `${Math.round(value)}ms`;
}

function fmtNs(value) {
  return isValidEpochNs(value) ? value.toString() : "-";
}

function computeVideoRectCss(containerWidth, containerHeight, sourceWidth, sourceHeight, fitMode, rotation) {
  const rotated = rotation === 90 || rotation === 270;
  const layoutWidth = rotated ? sourceHeight : sourceWidth;
  const layoutHeight = rotated ? sourceWidth : sourceHeight;
  const safeWidth = Math.max(1, layoutWidth);
  const safeHeight = Math.max(1, layoutHeight);
  if (fitMode === "fill") {
    return {
      x: 0,
      y: 0,
      width: containerWidth,
      height: containerHeight,
    };
  }
  const scale = fitMode === "cover"
    ? Math.max(containerWidth / safeWidth, containerHeight / safeHeight)
    : Math.min(containerWidth / safeWidth, containerHeight / safeHeight);
  const width = safeWidth * scale;
  const height = safeHeight * scale;
  return {
    x: (containerWidth - width) / 2,
    y: (containerHeight - height) / 2,
    width,
    height,
  };
}

function normalizeRotation(value) {
  const normalized = ((Number(value) || 0) % 360 + 360) % 360;
  if (normalized === 90 || normalized === 180 || normalized === 270) {
    return normalized;
  }
  return 0;
}

function rotateNormalizedInverse(x, y, rotation) {
  switch (rotation) {
    case 90:
      return { x: y, y: 1 - x };
    case 180:
      return { x: 1 - x, y: 1 - y };
    case 270:
      return { x: 1 - y, y: x };
    default:
      return { x, y };
  }
}

function makeCodecStringFromSps(nal) {
  if (!(nal instanceof Uint8Array) || nal.length < 8) {
    return null;
  }
  const headerLength = nal[2] === 1 ? 3 : 4;
  if (nal.length < headerLength + 4) {
    return null;
  }
  const profile = nal[headerLength + 1];
  const constraints = nal[headerLength + 2];
  const level = nal[headerLength + 3];
  return `avc1.${profile.toString(16).padStart(2, "0")}${constraints.toString(16).padStart(2, "0")}${level.toString(16).padStart(2, "0")}`;
}

function splitAnnexBNals(data) {
  if (!(data instanceof Uint8Array) || data.length === 0) {
    return [];
  }
  const starts = [];
  for (let i = 0; i < data.length - 3;) {
    if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 1) {
      starts.push([i, 4]);
      i += 4;
      continue;
    }
    if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 1) {
      starts.push([i, 3]);
      i += 3;
      continue;
    }
    i += 1;
  }
  if (!starts.length) {
    return [data];
  }
  const out = [];
  for (let index = 0; index < starts.length; index += 1) {
    const start = starts[index][0];
    const end = index + 1 < starts.length ? starts[index + 1][0] : data.length;
    if (end > start) {
      out.push(data.slice(start, end));
    }
  }
  return out;
}

function nalTypeOfAnnexB(data) {
  if (!(data instanceof Uint8Array) || data.length < 4) {
    return { type: 0, headerLength: 0 };
  }
  let headerLength = 0;
  if (data[0] === 0 && data[1] === 0 && data[2] === 0 && data[3] === 1) {
    headerLength = 4;
  } else if (data[0] === 0 && data[1] === 0 && data[2] === 1) {
    headerLength = 3;
  }
  if (!headerLength || data.length <= headerLength) {
    return { type: 0, headerLength };
  }
  return { type: data[headerLength] & 0x1f, headerLength };
}

function concatUint8Arrays(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function convertAvccToAnnexB(data) {
  if (!(data instanceof Uint8Array) || data.length < 4) {
    return null;
  }
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const parts = [];
  let offset = 0;
  while (offset + 4 <= data.length) {
    const nalLength = view.getUint32(offset);
    offset += 4;
    if (nalLength <= 0 || offset + nalLength > data.length) {
      return null;
    }
    parts.push(new Uint8Array([0, 0, 0, 1]));
    parts.push(data.slice(offset, offset + nalLength));
    offset += nalLength;
  }
  if (offset !== data.length || !parts.length) {
    return null;
  }
  return concatUint8Arrays(parts);
}

function normalizeH264Payload(data) {
  if (!(data instanceof Uint8Array) || data.length === 0) {
    return data;
  }
  const probableStartCode =
    (data.length >= 4 && data[0] === 0 && data[1] === 0 && data[2] === 0 && data[3] === 1) ||
    (data.length >= 3 && data[0] === 0 && data[1] === 0 && data[2] === 1);
  if (probableStartCode) {
    return data;
  }
  const avcc = convertAvccToAnnexB(data);
  if (avcc) {
    return avcc;
  }
  const nalType = data[0] & 0x1f;
  const forbiddenZeroBit = (data[0] >> 7) & 0x1;
  if (forbiddenZeroBit === 0 && nalType >= 1 && nalType <= 31) {
    const out = new Uint8Array(4 + data.length);
    out.set([0, 0, 0, 1], 0);
    out.set(data, 4);
    return out;
  }
  return data;
}

function decodeTracePacket(buffer) {
  const bytes = new Uint8Array(buffer);
  if (bytes.length < 4) {
    return { payload: bytes, trace: null };
  }
  const view = new DataView(buffer, bytes.byteOffset, bytes.byteLength);
  const beLength = view.getUint32(0);
  if (beLength === bytes.length - 44) {
    const payload = bytes.slice(4, 4 + beLength);
    const base = 4 + beLength;
    return {
      payload,
      trace: {
        ptsNs: view.getBigUint64(base),
        captureNs: view.getBigUint64(base + 8),
        encodeDoneNs: view.getBigUint64(base + 16),
        sendNs: view.getBigUint64(base + 24),
        frameSeq: view.getUint32(base + 32),
        flags: view.getUint32(base + 36),
      },
    };
  }
  if (beLength === bytes.length - 12) {
    return {
      payload: bytes.slice(4, 4 + beLength),
      trace: {
        ptsNs: view.getBigUint64(4 + beLength),
        captureNs: null,
        encodeDoneNs: null,
        sendNs: null,
        frameSeq: null,
        flags: 0,
      },
    };
  }
  if (beLength === bytes.length - 4) {
    return { payload: bytes.slice(4), trace: null };
  }
  return { payload: bytes, trace: null };
}

function decodeTilePayload(payload) {
  if (!(payload instanceof Uint8Array) || payload.length < 9) {
    return null;
  }
  for (let i = 0; i < TilePayloadMagic.length; i += 1) {
    if (payload[i] !== TilePayloadMagic.charCodeAt(i)) {
      return null;
    }
  }
  const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
  const headerLength = view.getUint32(TilePayloadMagic.length);
  const headerStart = TilePayloadMagic.length + 4;
  const imageStart = headerStart + headerLength;
  if (!(headerLength > 0) || imageStart >= payload.length) {
    return null;
  }
  try {
    const headerBytes = payload.slice(headerStart, imageStart);
    const header = JSON.parse(new TextDecoder().decode(headerBytes));
    return {
      header,
      imageBytes: payload.slice(imageStart),
    };
  } catch (_error) {
    return null;
  }
}

async function binaryToArrayBuffer(data) {
  if (data instanceof ArrayBuffer) {
    return data;
  }
  if (ArrayBuffer.isView(data)) {
    return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  }
  if (data instanceof Blob) {
    return data.arrayBuffer();
  }
  throw new Error("unsupported_binary_type");
}

function parseSocketText(raw) {
  try {
    return JSON.parse(raw);
  } catch (_error) {
    return null;
  }
}

function makeDefaultDevices() {
  return [];
}

function normalizeDeviceRecord(raw) {
  const id = String(raw?.id || raw?.device_id || raw?.deviceId || "").trim();
  if (!id) {
    return null;
  }
  const name = String(raw?.name || raw?.label || id).trim() || id;
  const note = String(raw?.note || raw?.description || "").trim();
  const sessionId = String(raw?.sessionId || raw?.session_id || "").trim();
  const authToken = String(raw?.authToken || raw?.auth_token || "").trim();
  const connectUrl = String(raw?.connectUrl || raw?.connect_url || "").trim();
  const signalUrl = String(raw?.signalUrl || raw?.signal_url || "").trim();
  const transportKind = String(raw?.transportKind || raw?.transport_kind || "").trim();
  const status = String(raw?.status || "").trim();
  const lastSeen = String(raw?.lastSeen || raw?.last_seen || "").trim();
  return { id, name, note, sessionId, authToken, connectUrl, signalUrl, transportKind, status, lastSeen };
}

function coerceImportedDevices(parsed) {
  if (Array.isArray(parsed)) {
    return parsed.map(normalizeDeviceRecord).filter(Boolean);
  }
  if (parsed && typeof parsed === "object") {
    return Object.entries(parsed)
      .map(([key, value]) => normalizeDeviceRecord({
        id: value?.id || key,
        name: value?.name,
        note: value?.note,
        sessionId: value?.sessionId || value?.session_id,
        authToken: value?.authToken || value?.auth_token,
        connectUrl: value?.connectUrl || value?.connect_url,
        signalUrl: value?.signalUrl || value?.signal_url,
        transportKind: value?.transportKind || value?.transport_kind,
        status: value?.status,
        lastSeen: value?.lastSeen || value?.last_seen,
      }))
      .filter(Boolean);
  }
  return [];
}

function loadDevices() {
  try {
    const parsed = JSON.parse(localStorage.getItem(StorageKeys.devices) || "null");
    const devices = coerceImportedDevices(parsed);
    return devices.length ? devices : makeDefaultDevices();
  } catch (_error) {
    return makeDefaultDevices();
  }
}

function saveDevices() {
  localStorage.setItem(StorageKeys.devices, JSON.stringify(appState.devices));
}

function loadSettings() {
  try {
    const parsed = JSON.parse(localStorage.getItem(StorageKeys.settings) || "null");
    return {
      relayUrl: normalizeRelayUrl(parsed?.relayUrl || defaultRelayUrl()),
      fitMode: ["contain", "cover", "fill"].includes(parsed?.fitMode) ? parsed.fitMode : "contain",
      rotation: [0, 90, 180, 270].includes(Number(parsed?.rotation)) ? Number(parsed.rotation) : 0,
      cardWidth: Math.min(320, Math.max(100, Number(parsed?.cardWidth) || 160)),
    };
  } catch (_error) {
    return {
      relayUrl: defaultRelayUrl(),
      fitMode: "contain",
      rotation: 0,
      cardWidth: 160,
    };
  }
}

function saveSettings() {
  localStorage.setItem(
    StorageKeys.settings,
    JSON.stringify({
      relayUrl: appState.relayUrl,
      fitMode: appState.fitMode,
      rotation: appState.rotation,
      cardWidth: appState.cardWidth,
    })
  );
}

function appendLog(text) {
  const line = `[${new Date().toLocaleTimeString("vi-VN", { hour12: false })}] ${text}`;
  appState.logs.push(line);
  if (appState.logs.length > MaxLogLines) {
    appState.logs.splice(0, appState.logs.length - MaxLogLines);
  }
  els.logOutput.textContent = appState.logs.join("\n");
  els.logOutput.scrollTop = els.logOutput.scrollHeight;
}

function statusText(value) {
  switch (value) {
    case "connecting":
      return "Đang nối";
    case "connected":
      return "Đã nối";
    case "error":
      return "Lỗi";
    default:
      return "Chưa nối";
  }
}

function toast(message) {
  const host = document.getElementById("tc");
  if (!host) {
    return;
  }
  const item = document.createElement("div");
  item.className = "tst";
  item.textContent = message;
  host.appendChild(item);
  setTimeout(() => item.remove(), 3200);
}

function applyCardWidth() {
  document.documentElement.style.setProperty("--card-w", `${appState.cardWidth}px`);
  els.zoomRange.value = String(appState.cardWidth);
  els.zoomLabel.textContent = `${appState.cardWidth}px`;
}

function updateStats() {
  const total = appState.devices.length;
  const online = Array.from(appState.controllers.values()).filter((controller) => controller.isOnline()).length;
  els.statTotal.textContent = String(total);
  els.statOnline.textContent = String(online);
  els.statOffline.textContent = String(Math.max(0, total - online));
  els.emptyState.classList.toggle("hidden", total > 0);
}

function selectDevice(deviceId) {
  appState.selectedDeviceId = deviceId || null;
  for (const controller of appState.controllers.values()) {
    controller.syncSelection();
  }
  renderSelectedDevicePanel();
}

function getSelectedController() {
  return appState.selectedDeviceId ? appState.controllers.get(appState.selectedDeviceId) || null : null;
}

function renderSelectedDevicePanel() {
  const controller = getSelectedController();
  if (!controller) {
    els.selectedName.textContent = "Chưa chọn máy";
    els.selectedId.textContent = "-";
    els.selectedRelay.textContent = appState.relayUrl || "-";
    els.selectedHand.textContent = "-";
    els.selectedStream.textContent = "-";
    els.selectedLatency.textContent = "-";
    els.selectedVideoRect.textContent = "-";
    els.selectedFrameSeq.textContent = "-";
    els.selectedNote.textContent = "-";
    return;
  }
  const details = controller.snapshotForPanel();
  els.selectedName.textContent = details.name;
  els.selectedId.textContent = details.id;
  els.selectedRelay.textContent = details.relay;
  els.selectedHand.textContent = details.hand;
  els.selectedStream.textContent = details.stream;
  els.selectedLatency.textContent = details.latency;
  els.selectedVideoRect.textContent = details.videoRect;
  els.selectedFrameSeq.textContent = details.frameSeq;
  els.selectedNote.textContent = details.note;
}

function openAddModal(prefill = null) {
  els.addDeviceId.value = prefill?.id || "";
  els.addDeviceName.value = prefill?.name || "";
  els.addDeviceNote.value = prefill?.note || "";
  els.addDeviceSession.value = prefill?.sessionId || prefill?.session_id || "";
  els.addDeviceToken.value = prefill?.authToken || prefill?.auth_token || "";
  els.addModal.classList.remove("hidden");
  els.addModal.setAttribute("aria-hidden", "false");
  queueMicrotask(() => els.addDeviceId.focus());
}

function closeAddModal() {
  els.addModal.classList.add("hidden");
  els.addModal.setAttribute("aria-hidden", "true");
}

function upsertDeviceRecord(record) {
  const existingIndex = appState.devices.findIndex((device) => device.id === record.id);
  if (existingIndex >= 0) {
    appState.devices[existingIndex] = record;
  } else {
    appState.devices.push(record);
  }
  saveDevices();
  renderDevices();
  selectDevice(record.id);
  toast(`✅ Đã lưu ${record.name}`);
}

function removeDevice(deviceId) {
  const controller = appState.controllers.get(deviceId);
  if (controller) {
    controller.destroy();
    appState.controllers.delete(deviceId);
  }
  appState.devices = appState.devices.filter((device) => device.id !== deviceId);
  saveDevices();
  renderDevices();
  if (appState.selectedDeviceId === deviceId) {
    selectDevice(appState.devices[0]?.id || null);
  }
  appendLog(`Đã xóa thiết bị ${deviceId}`);
  toast("🗑️ Đã xoá thiết bị");
}

function exportDevices() {
  const blob = new Blob([JSON.stringify(appState.devices, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "hid_probe_devices.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("📤 Đã export JSON");
}

async function importDevicesFromFile(file) {
  const text = await file.text();
  const parsed = JSON.parse(text);
  const devices = coerceImportedDevices(parsed);
  if (!devices.length) {
    throw new Error("Danh sách nhập vào không hợp lệ");
  }
  appState.devices = devices;
  saveDevices();
  renderDevices();
  selectDevice(appState.devices[0].id);
  appendLog(`Đã nhập ${devices.length} thiết bị từ tệp JSON`);
  toast(`📥 Đã import ${devices.length} thiết bị`);
}

async function fetchRegistryDevices() {
  const response = await fetch(buildApiUrl("/api/v1/transport/devices"), { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Registry HTTP ${response.status}`);
  }
  const payload = await response.json();
  return Array.isArray(payload?.devices) ? payload.devices.map(normalizeDeviceRecord).filter(Boolean) : [];
}

async function fetchDeviceBootstrap(deviceId) {
  const response = await fetch(buildApiUrl(`/api/v1/transport/bootstrap/${encodeURIComponent(deviceId)}`), { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Bootstrap HTTP ${response.status}`);
  }
  return response.json();
}

async function refreshDevicesFromRegistry() {
  const devices = await fetchRegistryDevices();
  const existingByCanonical = new Map(
    appState.devices
      .map((device) => [canonicalDeviceKey(device.id), { ...device }])
      .filter(([key]) => Boolean(key))
  );
  const liveByCanonical = new Map();

  for (const device of devices) {
    if (!isPhoneRuntimeStatus(device.status)) {
      continue;
    }
    const canonicalKey = canonicalDeviceKey(device.id);
    if (!canonicalKey) {
      continue;
    }
    const existing = existingByCanonical.get(canonicalKey) || {};
    const merged = {
      ...existing,
      ...device,
      authToken: device.authToken || existing.authToken || "",
      note: device.note || existing.note || "",
      name: device.name || existing.name || device.id,
    };
    liveByCanonical.set(canonicalKey, preferCanonicalRecord(liveByCanonical.get(canonicalKey), merged));
  }

  appState.devices = Array.from(liveByCanonical.values());
  saveDevices();
  renderDevices();
  if (!appState.devices.length) {
    appendLog("Registry không có iPhone online runtime (đã xóa máy stale khỏi dashboard)");
    return;
  }
  appendLog(`Đã đồng bộ ${appState.devices.length} iPhone online từ domain gốc`);
}

class DeviceController {
  constructor(device) {
    this.device = { ...device };
    this.signalingSocket = null;
    this.transportProbeOfferID = "";
    this.transportProbeSentAtMs = 0;
    this.transportProbeAcked = false;
    this.transportMediaReady = null;
    this.foundationMediaStarted = false;
    this.latestBootstrap = null;
    this.streamSocket = null;
    this.handSocket = null;
    this.streamState = "idle";
    this.handState = "idle";
    this.lastError = "";
    this.overlayMessage = "Chưa kết nối";
    this.canvasRectCss = { x: 0, y: 0, width: 0, height: 0 };
    this.videoRectCss = { x: 0, y: 0, width: 0, height: 0 };
    this.lastSourceSize = { width: 750, height: 1334 };
    this.sourceMeta = null;
    this.decoder = null;
    this.decoderConfigured = false;
    this.decoderConfigPromise = null;
    this.decoderCodec = "";
    this.cachedSps = null;
    this.cachedPps = null;
    this.lastKnownSps = null;
    this.lastKnownPps = null;
    this.seenFirstGoodKeyframe = false;
    this.activeFrame = null;
    this.pendingFrame = null;
    this.pendingAnimationFrame = 0;
    this.currentPresentedMeta = null;
    this.pendingDecodeMetaQueue = [];
    this.decoderFailureReason = "";
    this.streamFirstPacketSeen = false;
    this.decoderBackpressureDrops = 0;
    this.ackedFrameSeqSet = new Set();
    this.ackedFrameSeqOrder = [];
    this.noFrameHintTimer = 0;
    this.gesture = {
      active: false,
      pointerId: null,
      gestureId: "",
      startedAtMs: 0,
      lastMoveAtMs: 0,
      lastPoint: null,
    };
    this.hidSeq = 0;
    this.touchDownSent = 0;
    this.touchMoveSent = 0;
    this.touchUpSent = 0;
    this.touchCancelSent = 0;
    this.touchAckDown = 0;
    this.touchAckUp = 0;
    this.touchAckCancel = 0;
    this.touchAckDrop = 0;
    this.touchDroppedMove = 0;
    this.touchForcedCancel = 0;
    this.pendingGestureCancelReason = "";
    this.frameStoreCanvas = document.createElement("canvas");
    this.frameStoreCtx = this.frameStoreCanvas.getContext("2d", { alpha: false });
    this.buildDom();
    this.updateOverlay("Chưa kết nối", false, "message");
    this.drawNoSignalFrame();
    this.updateVisualState();
  }

  buildDom() {
    this.card = document.createElement("article");
    this.card.className = "phone-card";
    this.card.dataset.deviceId = this.device.id;

    this.stage = document.createElement("div");
    this.stage.className = "vs";
    this.card.appendChild(this.stage);

    this.canvas = document.createElement("canvas");
    this.stage.appendChild(this.canvas);
    this.ctx = this.canvas.getContext("2d", { alpha: false });
    this.bufferCanvas = document.createElement("canvas");
    this.bufferCtx = this.bufferCanvas.getContext("2d", { alpha: false });

    this.overlay = document.createElement("div");
    this.overlay.className = "covl";
    this.overlaySpinner = document.createElement("div");
    this.overlaySpinner.className = "spinner";
    this.overlayText = document.createElement("div");
    this.overlayText.className = "covl-txt";
    this.overlay.append(this.overlaySpinner, this.overlayText);
    this.stage.appendChild(this.overlay);

    this.pausedBadge = document.createElement("div");
    this.pausedBadge.className = "paused-badge";
    this.pausedBadge.textContent = "⏸ Paused";
    this.stage.appendChild(this.pausedBadge);

    this.labelBar = document.createElement("div");
    this.labelBar.className = "clbl";
    this.card.appendChild(this.labelBar);

    this.dotEl = document.createElement("div");
    this.dotEl.className = "ldot ing";
    this.labelBar.appendChild(this.dotEl);

    this.nameEl = document.createElement("span");
    this.nameEl.className = "cname";
    this.nameEl.textContent = this.device.name;
    this.labelBar.appendChild(this.nameEl);

    this.idEl = document.createElement("span");
    this.idEl.className = "cip";
    this.idEl.textContent = this.device.id;
    this.labelBar.appendChild(this.idEl);

    this.deleteButton = document.createElement("button");
    this.deleteButton.className = "btn-del";
    this.deleteButton.type = "button";
    this.deleteButton.title = "Xóa máy khỏi danh sách";
    this.deleteButton.textContent = "✕";
    this.labelBar.appendChild(this.deleteButton);

    this.card.addEventListener("click", (event) => {
      if (event.target.closest("button")) {
        return;
      }
      selectDevice(this.device.id);
    });
    this.deleteButton.addEventListener("click", (event) => {
      event.stopPropagation();
      removeDevice(this.device.id);
    });

    this.canvas.addEventListener("pointerdown", (event) => this.beginPointerGesture(event));
    this.canvas.addEventListener("pointermove", (event) => this.movePointerGesture(event));
    this.canvas.addEventListener("pointerup", (event) => this.endPointerGesture(event, false));
    this.canvas.addEventListener("pointercancel", (event) => this.endPointerGesture(event, true));
    this.canvas.addEventListener("lostpointercapture", () => {
      if (this.gesture.active) {
        this.forceEndGesture();
      }
    });
    window.addEventListener("blur", () => this.finalizeActiveGesture("window.blur", "gesture_cancel"));
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) this.finalizeActiveGesture("visibilitychange", "gesture_cancel");
    });
    window.addEventListener("beforeunload", () => this.finalizeActiveGesture("beforeunload", "gesture_cancel"));
  }

  mount(parent) {
    parent.appendChild(this.card);
  }

  updateDevice(device) {
    this.device = { ...device };
    this.nameEl.textContent = this.device.name;
    this.idEl.textContent = this.device.id;
    if (appState.selectedDeviceId === this.device.id) {
      renderSelectedDevicePanel();
    }
  }

  destroy() {
    this.disconnect("destroy");
    this.clearNoFrameHintTimer();
    if (this.pendingAnimationFrame) {
      cancelAnimationFrame(this.pendingAnimationFrame);
      this.pendingAnimationFrame = 0;
    }
    this.card.remove();
  }

  isSelected() {
    return appState.selectedDeviceId === this.device.id;
  }

  hasRemoteMediaEvidence() {
    return Boolean(this.sourceMeta) || this.streamFirstPacketSeen || Boolean(this.currentPresentedMeta);
  }

  isOnline() {
    return this.streamState === "connected" && this.hasRemoteMediaEvidence();
  }

  log(message) {
    appendLog(`[${this.device.name}] ${message}`);
  }

  failWith(message) {
    this.lastError = message;
    this.streamState = "error";
    this.updateOverlay(message, false, "message");
    this.updateVisualState();
    this.log(message);
  }

  syncSelection() {
    this.card.classList.toggle("is-selected", this.isSelected());
  }

  snapshotForPanel() {
    const latency = this.currentPresentedMeta && isValidEpochNs(this.currentPresentedMeta.captureNs)
      ? fmtMs(deltaMs(epochNsNow(), this.currentPresentedMeta.captureNs))
      : "-";
    const rect = this.videoRectCss.width > 0
      ? `x=${this.videoRectCss.x.toFixed(1)} y=${this.videoRectCss.y.toFixed(1)} w=${this.videoRectCss.width.toFixed(1)} h=${this.videoRectCss.height.toFixed(1)}`
      : "-";
    return {
      name: this.device.name,
      id: this.device.id,
      relay: this.device.connectUrl || appState.relayUrl,
      hand: statusText(this.handState),
      stream: statusText(this.streamState),
      latency,
      videoRect: rect,
      frameSeq: this.currentPresentedMeta?.frameSeq ?? "-",
      note: this.device.note || "-",
    };
  }

  updateOverlay(message, hidden, variant = "spinner") {
    this.overlayMessage = message;
    this.overlayText.textContent = message;
    this.overlay.classList.toggle("gone", hidden);
    this.overlaySpinner.style.display = hidden || variant !== "spinner" ? "none" : "";
  }

  clearNoFrameHintTimer() {
    if (!this.noFrameHintTimer) {
      return;
    }
    clearTimeout(this.noFrameHintTimer);
    this.noFrameHintTimer = 0;
  }

  scheduleNoFrameHint(contextTag) {
    this.clearNoFrameHintTimer();
    this.streamFirstPacketSeen = false;
    this.noFrameHintTimer = setTimeout(() => {
      this.noFrameHintTimer = 0;
      if (!this.streamSocket || this.streamSocket.readyState !== WebSocket.OPEN) {
        return;
      }
      if (this.streamState !== "connected" || this.streamFirstPacketSeen) {
        return;
      }
      this.updateOverlay(
        "Da ket noi socket nhung iPhone chua publish frame. Tren iPhone hay Start Unified Session / bat stream publisher.",
        false,
        "message"
      );
      this.log(`STREAM no_frame_timeout context=${contextTag || "-"}`);
    }, 5000);
  }

  markFirstStreamPacketSeen() {
    if (this.streamFirstPacketSeen) {
      return;
    }
    this.streamFirstPacketSeen = true;
    this.clearNoFrameHintTimer();
    this.updateVisualState();
  }

  ackFrameSeqOnce(seq) {
    if (!Number.isInteger(seq)) {
      return;
    }
    if (this.ackedFrameSeqSet.has(seq)) {
      return;
    }
    this.ackedFrameSeqSet.add(seq);
    this.ackedFrameSeqOrder.push(seq);
    if (this.ackedFrameSeqOrder.length > MaxRecentFrameAcks) {
      const evicted = this.ackedFrameSeqOrder.shift();
      if (evicted != null) {
        this.ackedFrameSeqSet.delete(evicted);
      }
    }
    this.sendFrameAck(seq);
  }

  updateVisualState() {
    this.dotEl.className = `ldot ${this.dotClassForState()}`;
    this.card.classList.remove("connected", "error", "paused");
    if (this.streamState === "error" || this.handState === "error") {
      this.card.classList.add("error");
    } else if (this.isOnline()) {
      this.card.classList.add("connected");
    }
    this.syncSelection();
    updateStats();
    if (this.isSelected()) {
      renderSelectedDevicePanel();
    }
  }

  dotClassForState() {
    if (this.streamState === "error" || this.handState === "error") {
      return "off";
    }
    if (this.streamState === "connecting" || this.handState === "connecting") {
      return "ing";
    }
    if (this.isOnline()) {
      return "on";
    }
    return "off";
  }

  ensureCanvasSize() {
    const rect = this.stage.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    this.canvasRectCss = { x: 0, y: 0, width, height };
    const pixelWidth = Math.round(width * dpr);
    const pixelHeight = Math.round(height * dpr);
    if (this.canvas.width !== pixelWidth || this.canvas.height !== pixelHeight) {
      this.canvas.width = pixelWidth;
      this.canvas.height = pixelHeight;
      this.bufferCanvas.width = pixelWidth;
      this.bufferCanvas.height = pixelHeight;
      this.canvas.style.width = `${width}px`;
      this.canvas.style.height = `${height}px`;
    }
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.bufferCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  flushBufferToCanvas() {
    this.ctx.drawImage(this.bufferCanvas, 0, 0, this.canvasRectCss.width, this.canvasRectCss.height);
  }

  drawNoSignalFrame() {
    this.ensureCanvasSize();
    this.updateVideoRectFromCurrentSource();
    this.bufferCtx.fillStyle = "#03060d";
    this.bufferCtx.fillRect(0, 0, this.canvasRectCss.width, this.canvasRectCss.height);
    this.bufferCtx.strokeStyle = "rgba(93, 116, 255, 0.18)";
    this.bufferCtx.lineWidth = 1;
    this.bufferCtx.strokeRect(10, 10, this.canvasRectCss.width - 20, this.canvasRectCss.height - 20);
    this.flushBufferToCanvas();
  }

  updateMetricPills() {
    if (this.isSelected()) {
      renderSelectedDevicePanel();
    }
  }

  resolveSourceLayout() {
    const meta = this.sourceMeta && this.sourceMeta.width > 0 && this.sourceMeta.height > 0
      ? this.sourceMeta
      : null;
    const width = Math.max(1, Number(meta?.width || this.lastSourceSize.width || 750));
    const height = Math.max(1, Number(meta?.height || this.lastSourceSize.height || 1334));
    const sourceRotation = normalizeRotation(meta?.rotation ?? 0);
    const effectiveRotation = normalizeRotation(sourceRotation + appState.rotation);
    return {
      width,
      height,
      sourceRotation,
      effectiveRotation,
      orientation: meta?.orientation || "",
      sessionId: meta?.sessionId || this.device.sessionId || "",
    };
  }

  updateVideoRectFromCurrentSource() {
    const layout = this.resolveSourceLayout();
    this.videoRectCss = computeVideoRectCss(
      this.canvasRectCss.width,
      this.canvasRectCss.height,
      layout.width,
      layout.height,
      appState.fitMode,
      layout.effectiveRotation
    );
    return layout;
  }

  redrawCurrentFrame(meta = this.currentPresentedMeta) {
    this.ensureCanvasSize();
    const layout = this.updateVideoRectFromCurrentSource();
    this.bufferCtx.fillStyle = "#05080d";
    this.bufferCtx.fillRect(0, 0, this.canvasRectCss.width, this.canvasRectCss.height);

    if (this.frameStoreCanvas.width > 0 && this.frameStoreCanvas.height > 0) {
      const rect = this.videoRectCss;
      const drawWidth = layout.effectiveRotation === 90 || layout.effectiveRotation === 270 ? rect.height : rect.width;
      const drawHeight = layout.effectiveRotation === 90 || layout.effectiveRotation === 270 ? rect.width : rect.height;
      this.bufferCtx.save();
      this.bufferCtx.translate(rect.x + rect.width / 2, rect.y + rect.height / 2);
      this.bufferCtx.rotate((layout.effectiveRotation * Math.PI) / 180);
      this.bufferCtx.drawImage(this.frameStoreCanvas, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
      this.bufferCtx.restore();
    }
    this.flushBufferToCanvas();

    if (meta) {
      this.currentPresentedMeta = meta;
      this.currentPresentedMeta.presentNs = epochNsNow();
    }
    this.updateMetricPills();
    this.updateOverlay(this.frameStoreCanvas.width > 0 ? "Khung hình đang hiển thị" : this.overlayMessage, this.frameStoreCanvas.width > 0);
  }

  updateSourceInfo(payload) {
    const width = Number(payload?.width || 0);
    const height = Number(payload?.height || 0);
    if (!(width > 0 && height > 0)) {
      return;
    }
    this.sourceMeta = {
      width,
      height,
      rotation: normalizeRotation(payload?.rotation || 0),
      orientation: String(payload?.orientation || "").trim(),
      sessionId: String(payload?.session_id || "").trim(),
    };
    this.lastSourceSize = { width, height };
    this.redrawCurrentFrame();
    this.updateVisualState();
  }

  renderVideoFrame(videoFrame, meta) {
    const sourceWidth = videoFrame.displayWidth || videoFrame.codedWidth || this.lastSourceSize.width;
    const sourceHeight = videoFrame.displayHeight || videoFrame.codedHeight || this.lastSourceSize.height;
    this.lastSourceSize = { width: sourceWidth, height: sourceHeight };
    if (this.frameStoreCanvas.width !== sourceWidth || this.frameStoreCanvas.height !== sourceHeight) {
      this.frameStoreCanvas.width = sourceWidth;
      this.frameStoreCanvas.height = sourceHeight;
    }
    this.frameStoreCtx.drawImage(videoFrame, 0, 0, sourceWidth, sourceHeight);
    this.redrawCurrentFrame(meta);
  }

  schedulePresent() {
    if (this.pendingAnimationFrame) {
      return;
    }
    this.pendingAnimationFrame = requestAnimationFrame(() => {
      this.pendingAnimationFrame = 0;
      const pending = this.pendingFrame;
      this.pendingFrame = null;
      if (!pending) {
        return;
      }
      this.renderVideoFrame(pending.videoFrame, pending.meta);
      pending.videoFrame.close();
    });
  }

  queueDecodedFrame(videoFrame, meta) {
    if (this.pendingFrame) {
      this.pendingFrame.videoFrame.close();
    }
    this.pendingFrame = { videoFrame, meta };
    this.schedulePresent();
  }

  resetDecoderState() {
    this.clearNoFrameHintTimer();
    this.streamFirstPacketSeen = false;
    if (this.decoder) {
      try {
        this.decoder.close();
      } catch (_error) {
        // Ignore close failures.
      }
    }
    this.decoder = null;
    this.decoderConfigured = false;
    this.decoderConfigPromise = null;
    this.decoderCodec = "";
    this.cachedSps = null;
    this.cachedPps = null;
    this.lastKnownSps = null;
    this.lastKnownPps = null;
    this.seenFirstGoodKeyframe = false;
    this.activeFrame = null;
    this.currentPresentedMeta = null;
    this.pendingFrame = null;
    this.pendingDecodeMetaQueue = [];
    this.decoderFailureReason = "";
    this.decoderBackpressureDrops = 0;
    this.ackedFrameSeqSet.clear();
    this.ackedFrameSeqOrder.length = 0;
    this.videoRectCss = { x: 0, y: 0, width: 0, height: 0 };
    this.frameStoreCanvas.width = 0;
    this.frameStoreCanvas.height = 0;
    if (this.pendingAnimationFrame) {
      cancelAnimationFrame(this.pendingAnimationFrame);
      this.pendingAnimationFrame = 0;
    }
    this.drawNoSignalFrame();
    this.updateMetricPills();
  }

  processH264ForDecoder(annexb) {
    const parts = splitAnnexBNals(annexb);
    const parsedParts = [];
    for (const part of parts) {
      const parsed = nalTypeOfAnnexB(part);
      parsedParts.push({ part, type: parsed.type, headerLength: parsed.headerLength });
      if (parsed.headerLength <= 0) {
        continue;
      }
      if (parsed.type === 7) {
        this.cachedSps = part;
        this.lastKnownSps = part;
      } else if (parsed.type === 8) {
        this.cachedPps = part;
        this.lastKnownPps = part;
      }
    }

    if (!this.cachedSps) {
      this.cachedSps = this.lastKnownSps;
    }
    if (!this.cachedPps) {
      this.cachedPps = this.lastKnownPps;
    }

    const out = [];
    let hasKeyframe = false;
    let droppedReason = "";
    for (const entry of parsedParts) {
      if (entry.headerLength <= 0) {
        out.push(entry.part);
        continue;
      }
      if (entry.type === 7 || entry.type === 8) {
        out.push(entry.part);
        continue;
      }
      if (entry.type === 5) {
        if (this.cachedSps && this.cachedPps) {
          this.seenFirstGoodKeyframe = true;
          hasKeyframe = true;
          out.push(this.cachedSps, this.cachedPps, entry.part);
          continue;
        }
        droppedReason = "drop_idr_no_params";
        continue;
      }
      if (entry.type === 1 && !this.seenFirstGoodKeyframe) {
        droppedReason = "drop_slice_pre_keyframe";
        continue;
      }
      out.push(entry.part);
    }
    return {
      data: out.length ? concatUint8Arrays(out) : null,
      hasKeyframe,
      droppedReason,
    };
  }

  async ensureDecoderConfigured() {
    if (this.decoderFailureReason) {
      return false;
    }
    if (this.decoderConfigured) {
      return true;
    }
    if (this.decoderConfigPromise) {
      return this.decoderConfigPromise;
    }
    this.decoderConfigPromise = (async () => {
      if (!("VideoDecoder" in window) || !this.lastKnownSps) {
        return false;
      }
      const codec = makeCodecStringFromSps(this.lastKnownSps);
      if (!codec) {
        return false;
      }
      const config = {
        codec,
        optimizeForLatency: true,
        hardwareAcceleration: "prefer-hardware",
      };
      const support = await VideoDecoder.isConfigSupported(config);
      if (!support.supported) {
        this.decoderFailureReason = `Trình duyệt không hỗ trợ H264 (${codec})`;
        this.log(this.decoderFailureReason);
        this.updateOverlay(this.decoderFailureReason, false, "message");
        return false;
      }
      this.decoder = new VideoDecoder({
        output: (videoFrame) => {
          const meta = this.pendingDecodeMetaQueue.shift();
          if (!meta) {
            videoFrame.close();
            return;
          }
          meta.decodeNs = epochNsNow();
          this.queueDecodedFrame(videoFrame, meta);
        },
        error: (error) => {
          this.log(`Decoder lỗi: ${error.message || error}`);
          this.updateOverlay("Decoder lỗi", false, "message");
        },
      });
      this.decoder.configure(support.config);
      this.decoderCodec = codec;
      this.decoderConfigured = true;
      this.log(`Decoder đã cấu hình ${codec}`);
      return true;
    })();
    try {
      return await this.decoderConfigPromise;
    } catch (error) {
      this.decoderFailureReason = `Decoder lỗi khởi tạo: ${error.message || error}`;
      this.log(this.decoderFailureReason);
      this.updateOverlay(this.decoderFailureReason, false, "message");
      return false;
    } finally {
      this.decoderConfigPromise = null;
    }
  }

  async finalizeActiveFrame(reason) {
    const frame = this.activeFrame;
    if (!frame) {
      return;
    }
    this.activeFrame = null;
    if ((!frame.payload || frame.payload.length === 0) && frame.chunkParts.length > 0) {
      frame.payload = frame.chunkParts.length === 1 ? frame.chunkParts[0] : concatUint8Arrays(frame.chunkParts);
    }
    if (!frame.payload || frame.payload.length === 0) {
      return;
    }
    const configured = await this.ensureDecoderConfigured();
    if (!configured || !this.decoder) {
      this.updateOverlay("Đang chờ keyframe...", false, "spinner");
      return;
    }
    const decoderQueueSize = Number(this.decoder.decodeQueueSize || 0);
    const decodeDepth = Math.max(this.pendingDecodeMetaQueue.length, decoderQueueSize);
    if (!frame.isKeyframe && decodeDepth >= MaxDecodeBackpressureDepth) {
      this.decoderBackpressureDrops += 1;
      if (this.decoderBackpressureDrops <= 3 || this.decoderBackpressureDrops % 60 === 0) {
        this.log(`STREAM drop_decode_backpressure total=${this.decoderBackpressureDrops} depth=${decodeDepth} seq=${frame.frameSeq ?? "-"} reason=${reason}`);
      }
      return;
    }
    const timestampUs = isValidEpochNs(frame.captureNs)
      ? Number(frame.captureNs / NsPerUs)
      : Math.round(performance.now() * 1000);
    this.pendingDecodeMetaQueue.push(frame);
    try {
      this.decoder.decode(
        new EncodedVideoChunk({
          type: frame.isKeyframe ? "key" : "delta",
          timestamp: timestampUs,
          data: frame.payload,
        })
      );
    } catch (error) {
      this.pendingDecodeMetaQueue.pop();
      this.log(`Không giải mã được frame seq=${frame.frameSeq ?? "-"} reason=${reason} error=${error.message || error}`);
    }
  }

  mergeFrameTrace(frame, trace, receiveNs, payloadBytes, chunkBytes, hasKeyframe) {
    if (isValidEpochNs(trace.captureNs) && (!isValidEpochNs(frame.captureNs) || trace.captureNs < frame.captureNs)) {
      frame.captureNs = trace.captureNs;
    }
    if (isValidEpochNs(trace.sendNs) && (!isValidEpochNs(frame.sendNs) || trace.sendNs > frame.sendNs)) {
      frame.sendNs = trace.sendNs;
    }
    if (!isValidEpochNs(frame.receiveDoneNs) || receiveNs > frame.receiveDoneNs) {
      frame.receiveDoneNs = receiveNs;
    }
    frame.packetCount += 1;
    frame.payloadBytes += payloadBytes;
    frame.chunkParts.push(chunkBytes);
    frame.isKeyframe = frame.isKeyframe || hasKeyframe;
  }

  async renderTilePayload(tile, trace, receiveNs) {
    const header = tile.header || {};
    const canvasWidth = Math.max(1, Number(header.canvas_width || this.lastSourceSize.width || 1));
    const canvasHeight = Math.max(1, Number(header.canvas_height || this.lastSourceSize.height || 1));
    const x = Math.max(0, Number(header.x || 0));
    const y = Math.max(0, Number(header.y || 0));
    const width = Math.max(1, Number(header.width || 1));
    const height = Math.max(1, Number(header.height || 1));
    const frameSeq = Number.isFinite(Number(header.frame_seq)) ? Number(header.frame_seq) : (trace?.frameSeq ?? null);
    const captureNs = header.capture_ns ? BigInt(String(header.capture_ns)) : (trace?.captureNs ?? null);

    if (this.activeFrame) {
      await this.finalizeActiveFrame("tile_payload_flush_h264");
    }
    if (this.frameStoreCanvas.width !== canvasWidth || this.frameStoreCanvas.height !== canvasHeight || header.full) {
      this.frameStoreCanvas.width = canvasWidth;
      this.frameStoreCanvas.height = canvasHeight;
      this.frameStoreCtx.fillStyle = "#000";
      this.frameStoreCtx.fillRect(0, 0, canvasWidth, canvasHeight);
      this.lastSourceSize = { width: canvasWidth, height: canvasHeight };
    }

    const imageBitmap = await createImageBitmap(new Blob([tile.imageBytes], { type: "image/jpeg" }));
    try {
      this.frameStoreCtx.drawImage(imageBitmap, x, y, width, height);
    } finally {
      imageBitmap.close();
    }

    const meta = {
      frameSeq,
      captureNs,
      sendNs: trace?.sendNs ?? null,
      receiveDoneNs: receiveNs,
      decodeNs: epochNsNow(),
      presentNs: null,
      packetCount: 1,
      payloadBytes: tile.imageBytes.length,
      chunkParts: [],
      payload: null,
      isKeyframe: Boolean(header.full),
    };
    this.redrawCurrentFrame(meta);
  }

  async handleStreamBinaryMessage(buffer) {
    const receiveNs = epochNsNow();
    const { payload, trace } = decodeTracePacket(buffer);
    const traceFrameSeq = trace && Number.isInteger(trace.frameSeq) ? trace.frameSeq : null;
    if (traceFrameSeq != null) {
      this.ackFrameSeqOnce(traceFrameSeq);
    }
    this.markFirstStreamPacketSeen();
    const tile = decodeTilePayload(payload);
    if (tile) {
      await this.renderTilePayload(tile, trace, receiveNs);
      return;
    }
    const annexb = normalizeH264Payload(payload);
    const processed = this.processH264ForDecoder(annexb);
    if (!processed.data) {
      if (processed.droppedReason) {
        this.updateOverlay("Đang chờ keyframe...", false, "spinner");
      }
      return;
    }

    const fallbackSeqFromPts = trace && isValidEpochNs(trace.ptsNs)
      ? Number(trace.ptsNs % 4294967296n)
      : null;
    const frameSeq = traceFrameSeq != null ? traceFrameSeq : fallbackSeqFromPts;
    const captureNs = trace && isValidEpochNs(trace.captureNs)
      ? trace.captureNs
      : (trace && isValidEpochNs(trace.ptsNs) ? trace.ptsNs : null);
    const sendNs = trace && isValidEpochNs(trace.sendNs) ? trace.sendNs : null;

    if (frameSeq == null) {
      if (this.activeFrame) {
        await this.finalizeActiveFrame("trace_missing_flush");
      }
      this.activeFrame = {
        frameSeq: null,
        captureNs,
        sendNs,
        receiveDoneNs: receiveNs,
        decodeNs: null,
        presentNs: null,
        packetCount: 1,
        payloadBytes: payload.length,
        chunkParts: [processed.data],
        payload: processed.data,
        isKeyframe: processed.hasKeyframe,
      };
      await this.finalizeActiveFrame("trace_missing_single");
      return;
    }

    if (!this.activeFrame || this.activeFrame.frameSeq !== frameSeq) {
      if (this.activeFrame) {
        await this.finalizeActiveFrame("frame_seq_advance");
      }
      this.activeFrame = {
        frameSeq,
        captureNs,
        sendNs,
        receiveDoneNs: receiveNs,
        decodeNs: null,
        presentNs: null,
        packetCount: 0,
        payloadBytes: 0,
        chunkParts: [],
        payload: null,
        isKeyframe: false,
      };
    }

    if (trace && traceFrameSeq != null) {
      this.mergeFrameTrace(this.activeFrame, trace, receiveNs, payload.length, processed.data, processed.hasKeyframe);
      return;
    }

    // Legacy packet fallback (trace without frame_seq): group by synthetic seq from pts.
    this.activeFrame.receiveDoneNs = receiveNs;
    this.activeFrame.packetCount += 1;
    this.activeFrame.payloadBytes += payload.length;
    this.activeFrame.chunkParts.push(processed.data);
    this.activeFrame.isKeyframe = this.activeFrame.isKeyframe || processed.hasKeyframe;
  }

  sendJson(socket, payload) {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      return false;
    }
    socket.send(JSON.stringify(payload));
    return true;
  }

  sendTransportSignal(targetRole, signalType, payload = {}) {
    return this.sendJson(this.signalingSocket, {
      type: "transport_signal",
      device_id: this.device.id,
      target_role: targetRole,
      signal_type: signalType,
      payload,
      ts: new Date().toISOString(),
    });
  }

  sendTransportProbeOffer(reason) {
    if (this.transportProbeAcked) {
      return;
    }
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN) {
      return;
    }
    const offerID = crypto.randomUUID();
    const sentAtISO = new Date().toISOString();
    const sent = this.sendTransportSignal("phone", "probe_offer", {
      offer_id: offerID,
      reason: reason || "presence_ready",
      sent_at: sentAtISO,
    });
    if (!sent) {
      return;
    }
    this.transportProbeOfferID = offerID;
    this.transportProbeSentAtMs = performance.now();
    this.log(`SIGNAL probe_offer sent offer_id=${offerID} reason=${reason || "-"}`);
    this.updateOverlay("Đã gửi probe_offer. Đang đợi probe_answer từ iPhone...", false, "spinner");
  }

  connectFoundationMediaStream(signalUrl) {
    if (!signalUrl) {
      return;
    }
    if (this.streamSocket && this.streamSocket.readyState <= WebSocket.OPEN) {
      return;
    }
    if (this.foundationMediaStarted) {
      return;
    }
    this.foundationMediaStarted = true;
    this.streamState = "connecting";
    this.updateVisualState();
    this.updateOverlay("Handshake xong. Đang nối media stream...", false, "spinner");

    const streamSocket = new WebSocket(signalUrl);
    streamSocket.binaryType = "arraybuffer";
    this.streamSocket = streamSocket;

    streamSocket.addEventListener("open", () => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      this.sendJson(streamSocket, {
        type: "register",
        role: "mac",
        device_id: this.device.id,
        subchannel: "stream",
        codec: "h264",
        client: "hid_probe_farm_web_phase6_stream",
        session_id: this.device.sessionId || "",
        auth_token: this.device.authToken || "",
        ts: new Date().toISOString(),
      });
    });

    streamSocket.addEventListener("close", async () => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      this.clearNoFrameHintTimer();
      this.streamSocket = null;
      this.foundationMediaStarted = false;
      this.streamState = "idle";
      this.updateVisualState();
      this.updateOverlay("Media stream đã ngắt", false, "message");
      await this.finalizeActiveFrame("foundation_stream_socket_close");
    });

    streamSocket.addEventListener("error", () => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      this.clearNoFrameHintTimer();
      this.foundationMediaStarted = false;
      this.streamState = "error";
      this.updateVisualState();
      this.updateOverlay("Media stream lỗi", false, "message");
      this.log("STREAM foundation socket_error");
    });

    streamSocket.addEventListener("message", async (event) => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      try {
        if (typeof event.data === "string") {
          const payload = parseSocketText(event.data);
          if (!payload) {
            return;
          }
          if (payload.type === "register_ack") {
            this.streamState = "connected";
            this.updateVisualState();
            this.updateOverlay("Đã nối media stream. Đang chờ frame từ iPhone...", false, "spinner");
            this.scheduleNoFrameHint("foundation");
            this.log("STREAM foundation register_ack");
          } else if (payload.type === "source_info") {
            this.updateSourceInfo(payload);
          } else if (payload.type === "error") {
            this.foundationMediaStarted = false;
            this.streamState = "error";
            this.updateVisualState();
            this.updateOverlay(`STREAM lỗi: ${payload.reason}`, false, "message");
            this.log(`STREAM foundation error=${payload.reason}`);
          }
          return;
        }
        const buffer = await binaryToArrayBuffer(event.data);
        await this.handleStreamBinaryMessage(buffer);
      } catch (error) {
        this.log(`Lỗi xử lý foundation stream: ${error.message || error}`);
        this.updateOverlay("Lỗi xử lý frame foundation", false, "message");
      }
    });
  }

  ensureHandLaneAttached(signalUrl) {
    if (!signalUrl) {
      return;
    }
    const sendHandRegister = (socket) => {
      this.sendJson(socket, {
        type: "register",
        role: "mac",
        device_id: this.device.id,
        subchannel: "hand",
        client: "hid_probe_farm_web_phase6_hand",
        session_id: this.device.sessionId || "",
        auth_token: this.device.authToken || "",
        ts: new Date().toISOString(),
      });
    };

    if (this.handSocket) {
      if (this.handSocket.readyState === WebSocket.CONNECTING) {
        return;
      }
      if (this.handSocket.readyState === WebSocket.OPEN) {
        if (this.handState !== "connected") {
          sendHandRegister(this.handSocket);
          this.log("HAND ensure re-register");
        }
        return;
      }
    }

    this.handState = "connecting";
    this.updateVisualState();

    const handSocket = new WebSocket(signalUrl);
    this.handSocket = handSocket;

    handSocket.addEventListener("open", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      sendHandRegister(handSocket);
      this.log("HAND ensure attach");
    });

    handSocket.addEventListener("close", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      this.armPendingGestureCancel("foundation_hand_socket_closed");
      this.resetGesture();
      this.handSocket = null;
      this.handState = "idle";
      this.updateVisualState();
    });

    handSocket.addEventListener("error", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      this.armPendingGestureCancel("foundation_hand_socket_error");
      this.resetGesture();
      this.handState = "error";
      this.updateVisualState();
      this.log("HAND foundation socket_error");
    });

    handSocket.addEventListener("message", (event) => {
      if (this.handSocket !== handSocket || typeof event.data !== "string") {
        return;
      }
      const payload = parseSocketText(event.data);
      if (!payload) {
        return;
      }
      if (payload.type === "register_ack") {
        this.handState = "connected";
        this.updateVisualState();
        this.log("HAND foundation register_ack");
        this.flushPendingGestureCancel();
      } else if (payload.type === "hid_ack") {
        this.handleHIDAck(payload);
      } else if (payload.type === "ack") {
        this.log(`HAND ack stage=${payload.stage || "-"} ok=${payload.ok !== false} reason=${payload.reason || "-"}`);
      } else if (payload.type === "error") {
        this.handState = "error";
        this.updateVisualState();
        this.log(`HAND foundation error=${payload.reason}`);
      }
    });
  }

  sendFrameAck(seq) {
    this.sendJson(this.streamSocket, {
      type: "frame_ack",
      seq,
      device_id: this.device.id,
      subchannel: "stream",
      session_id: this.device.sessionId || "",
    });
  }

  sendGesture(kind, point, gestureMs) {
    if (kind === "gesture_move" && this.handSocket?.bufferedAmount > 262144) {
      this.touchDroppedMove += 1;
      return false;
    }
    const seq = ++this.hidSeq;
    const payload = {
      type: "command",
      device_id: this.device.id,
      subchannel: "hand",
      session_id: this.device.sessionId || "",
      auth_token: this.device.authToken || "",
      kind,
      command_id: crypto.randomUUID(),
      sent_at: new Date().toISOString(),
      payload: {
        gesture_id: this.gesture.gestureId,
        seq,
        sent_at_ms: Math.round(performance.now()),
        phase: kind,
        x: Number(point.x.toFixed(6)),
        y: Number(point.y.toFixed(6)),
        gesture_t_ms: Number(gestureMs.toFixed(3)),
        wall_ts_ms: Number(performance.now().toFixed(3)),
      },
    };
    if (!this.sendJson(this.handSocket, payload)) {
      this.log("HAND chưa nối, bỏ gesture");
      return false;
    }
    if (kind === "gesture_down") this.touchDownSent += 1;
    else if (kind === "gesture_move") this.touchMoveSent += 1;
    else if (kind === "gesture_up") this.touchUpSent += 1;
    else if (kind === "gesture_cancel") this.touchCancelSent += 1;
    if (kind !== "gesture_move") {
      this.log(`HAND gửi ${kind} x=${payload.payload.x} y=${payload.payload.y}`);
    }
    return true;
  }

  sendGestureCancel(reason) {
    const point = this.gesture.lastPoint || { x: 0.5, y: 0.5 };
    const payload = {
      type: "command",
      device_id: this.device.id,
      subchannel: "hand",
      session_id: this.device.sessionId || "",
      auth_token: this.device.authToken || "",
      kind: "gesture_cancel",
      command_id: crypto.randomUUID(),
      sent_at: new Date().toISOString(),
      payload: {
        gesture_id: this.gesture.gestureId || crypto.randomUUID(),
        seq: ++this.hidSeq,
        sent_at_ms: Math.round(performance.now()),
        phase: "gesture_cancel",
        x: Number(point.x.toFixed(6)),
        y: Number(point.y.toFixed(6)),
        reason: reason || "web_disconnect",
      },
    };
    if (!this.sendJson(this.handSocket, payload)) {
      return false;
    }
    this.touchCancelSent += 1;
    this.pendingGestureCancelReason = "";
    this.log(`HAND gửi gesture_cancel reason=${payload.payload.reason}`);
    return true;
  }

  handleHIDAck(payload) {
    if (!payload || payload.type !== "hid_ack") {
      return;
    }
    const phase = String(payload.phase || "");
    const ok = payload.ok !== false;
    if (phase === "gesture_down") this.touchAckDown += 1;
    else if (phase === "gesture_up") this.touchAckUp += 1;
    else if (phase === "gesture_cancel") this.touchAckCancel += 1;
    else if (phase === "drop" || !ok) this.touchAckDrop += 1;
    if (phase !== "gesture_move") {
      this.log(`hid_ack phase=${phase} ok=${ok ? 1 : 0} reason=${payload.reason || "ok"}`);
    }
  }

  armPendingGestureCancel(reason) {
    this.pendingGestureCancelReason = reason || this.pendingGestureCancelReason || "web_disconnect";
  }

  flushPendingGestureCancel() {
    if (!this.pendingGestureCancelReason) {
      return;
    }
    if (!this.sendGestureCancel(this.pendingGestureCancelReason)) {
      return;
    }
    this.pendingGestureCancelReason = "";
  }

  pointFromPointerEvent(event, allowOutside) {
    const rect = this.canvas.getBoundingClientRect();
    const localX = event.clientX - rect.left;
    const localY = event.clientY - rect.top;
    const videoRect = this.videoRectCss;
    if (videoRect.width <= 0 || videoRect.height <= 0) {
      return null;
    }

    const insideX = localX >= videoRect.x && localX <= videoRect.x + videoRect.width;
    const insideY = localY >= videoRect.y && localY <= videoRect.y + videoRect.height;
    if (appState.fitMode === "contain" && !allowOutside && (!insideX || !insideY)) {
      return null;
    }

    const rawX = (localX - videoRect.x) / Math.max(1, videoRect.width);
    const rawY = (localY - videoRect.y) / Math.max(1, videoRect.height);
    const clampedX = Math.min(Math.max(rawX, 0), 1);
    const clampedY = Math.min(Math.max(rawY, 0), 1);
    return rotateNormalizedInverse(clampedX, clampedY, this.resolveSourceLayout().effectiveRotation);
  }

  beginPointerGesture(event) {
    if (event.button !== 0 && event.pointerType !== "touch") {
      return;
    }
    if (this.handState !== "connected") {
      return;
    }
    const point = this.pointFromPointerEvent(event, false);
    if (!point) {
      return;
    }
    selectDevice(this.device.id);
    this.canvas.setPointerCapture(event.pointerId);
    this.gesture.active = true;
    this.gesture.pointerId = event.pointerId;
    this.gesture.gestureId = crypto.randomUUID();
    this.gesture.startedAtMs = performance.now();
    this.gesture.lastMoveAtMs = 0;
    this.gesture.lastPoint = point;
    this.sendGesture("gesture_down", point, 0);
  }

  movePointerGesture(event) {
    if (!this.gesture.active || this.gesture.pointerId !== event.pointerId) {
      return;
    }
    const nowMs = performance.now();
    if (nowMs - this.gesture.lastMoveAtMs < 16) {
      return;
    }
    const point = this.pointFromPointerEvent(event, true);
    if (!point) {
      return;
    }
    this.gesture.lastMoveAtMs = nowMs;
    this.gesture.lastPoint = point;
    this.sendGesture("gesture_move", point, nowMs - this.gesture.startedAtMs);
  }

  endPointerGesture(event, cancelled) {
    if (!this.gesture.active || this.gesture.pointerId !== event.pointerId) {
      return;
    }
    this.finalizeActiveGesture(cancelled ? "pointercancel" : "pointerup", cancelled ? "gesture_cancel" : "gesture_up", event);
  }

  finalizeActiveGesture(reason, finalPhase, event = null) {
    if (!this.gesture.active) {
      return;
    }
    const nowMs = performance.now();
    const point = (event ? this.pointFromPointerEvent(event, true) : null) || this.gesture.lastPoint;
    if (point && finalPhase === "gesture_up") {
      this.sendGesture("gesture_up", point, nowMs - this.gesture.startedAtMs);
    } else if (point) {
      this.touchForcedCancel += 1;
      this.sendGestureCancel(reason || "finalize_cancel");
    }
    try {
      if (this.canvas.hasPointerCapture?.(this.gesture.pointerId)) this.canvas.releasePointerCapture(this.gesture.pointerId);
    } catch (_error) {
      // Ignore release failures.
    }
    this.resetGesture();
  }

  forceEndGesture() {
    if (!this.gesture.active) {
      return;
    }
    this.finalizeActiveGesture("web_force_cancel", "gesture_cancel");
  }

  resetGesture() {
    this.gesture.active = false;
    this.gesture.pointerId = null;
    this.gesture.gestureId = "";
    this.gesture.startedAtMs = 0;
    this.gesture.lastMoveAtMs = 0;
    this.gesture.lastPoint = null;
  }

  async connect() {
    let bootstrap;
    try {
      bootstrap = await fetchDeviceBootstrap(this.device.id);
    } catch (error) {
      const reason = String(error?.message || error);
      if (reason.includes("Bootstrap HTTP 404")) {
        this.failWith("Thiết bị không còn có trong registry runtime. Hãy tải lại danh sách máy.");
        return;
      }
      this.failWith(`Không lấy được bootstrap: ${reason}`);
      return;
    }

    const devicePayload = normalizeDeviceRecord(bootstrap?.device || { id: this.device.id }) || this.device;
    const transport = bootstrap?.transport || {};
    this.device = {
      ...this.device,
      ...devicePayload,
      connectUrl: transport.connect_url || devicePayload.connectUrl || this.device.connectUrl || "",
      signalUrl: transport.signal_url || devicePayload.signalUrl || this.device.signalUrl || "",
      transportKind: transport.kind || devicePayload.transportKind || this.device.transportKind || "",
    };
    this.latestBootstrap = bootstrap;
    appState.devices = appState.devices.map((item) => item.id === this.device.id ? { ...this.device } : item);
    saveDevices();
    this.updateDevice(this.device);

    if (transport.kind === "webrtc_foundation" || transport.kind === "webrtc") {
      return this.connectTransportFoundation(bootstrap);
    }
    return this.connectLegacyRelay();
  }

  async connectTransportFoundation(bootstrap) {
    this.disconnect("reconnect");
    this.resetDecoderState();
    this.transportProbeOfferID = "";
    this.transportProbeSentAtMs = 0;
    this.transportProbeAcked = false;
    this.transportMediaReady = null;
    this.foundationMediaStarted = false;
    this.streamState = "connecting";
    this.handState = "connecting";
    this.lastError = "";
    this.updateOverlay("Đang nối signaling từ domain gốc...", false, "spinner");
    this.updateVisualState();

    const signalUrl = String(bootstrap?.transport?.signal_url || this.device.signalUrl || "").trim();
    if (!signalUrl) {
      this.failWith("Bootstrap thiếu signal_url");
      return;
    }

    this.log(`Bootstrap OK cho ${this.device.id} kind=${bootstrap.transport.kind}`);
    const signalingSocket = new WebSocket(signalUrl);
    this.signalingSocket = signalingSocket;

    signalingSocket.addEventListener("open", () => {
      if (this.signalingSocket !== signalingSocket) {
        return;
      }
      this.sendJson(signalingSocket, {
        type: "transport_register",
        participant_role: "viewer",
        device_id: this.device.id,
        session_id: this.device.sessionId || "",
        transport_kind: bootstrap?.transport?.kind || "webrtc_foundation",
        client: "hid_probe_farm_web",
        connect_url: this.device.connectUrl || "",
        signal_url: signalUrl,
        ts: new Date().toISOString(),
      });
      this.ensureHandLaneAttached(signalUrl);
    });

    signalingSocket.addEventListener("message", (event) => {
      if (this.signalingSocket !== signalingSocket || typeof event.data !== "string") {
        return;
      }
      const payload = parseSocketText(event.data);
      if (!payload) {
        return;
      }
      if (payload.type === "transport_register_ack") {
        this.updateVisualState();
        this.updateOverlay("Bootstrap/signaling đã sẵn sàng. Đang đợi iPhone xuất hiện trên runtime.", false, "spinner");
        this.log(`SIGNAL register_ack phone=${payload.phone_count || 0} viewer=${payload.viewer_count || 0}`);
        if (Number(payload.phone_count || 0) > 0) {
          this.sendTransportProbeOffer("register_ack_phone_present");
        }
      } else if (payload.type === "transport_presence") {
        const phoneCount = Number(payload.phone_count || 0);
        const viewerCount = Number(payload.viewer_count || 0);
        const mediaUnavailable = this.transportMediaReady === false;
        if (this.streamState !== "error") {
          this.streamState = "connecting";
        }
        this.updateVisualState();
        this.updateOverlay(
          phoneCount > 0
            ? mediaUnavailable
              ? "iPhone đã có mặt trên signaling nhưng chưa publish media lane."
              : "iPhone đã có mặt trên signaling. Sẵn sàng nối direct transport."
            : "Viewer đã vào signaling. Đang đợi iPhone publish transport mới.",
          false,
          phoneCount > 0 ? "message" : "spinner"
        );
        this.log(`SIGNAL presence phone=${phoneCount} viewer=${viewerCount}`);
        if (phoneCount > 0) {
          this.ensureHandLaneAttached(signalUrl);
          this.sendTransportProbeOffer("presence_phone_ready");
          if (this.transportProbeAcked && this.transportMediaReady !== false) {
            this.connectFoundationMediaStream(signalUrl);
          }
        }
      } else if (payload.type === "transport_signal") {
        const signalType = String(payload.signal_type || "opaque").toLowerCase();
        const sourceRole = String(payload.source_role || "").toLowerCase();
        if (signalType === "probe_answer" && sourceRole === "phone") {
          const answerOfferID = String(payload?.payload?.offer_id || "");
          if (answerOfferID && answerOfferID === this.transportProbeOfferID) {
            this.transportProbeAcked = true;
            const answerPayload = payload && typeof payload.payload === "object" && payload.payload
              ? payload.payload
              : {};
            const mediaReady = answerPayload.media_ready;
            const mediaReason = String(answerPayload.media_reason || "").trim();
            const rttMs = this.transportProbeSentAtMs > 0
              ? Math.round(performance.now() - this.transportProbeSentAtMs)
              : null;
            if (mediaReady === false) {
              this.transportMediaReady = false;
              this.streamState = "connecting";
              this.updateVisualState();
              this.updateOverlay(
                mediaReason
                  ? `Realtime handshake OK, nhưng media chưa sẵn sàng (${mediaReason}).`
                  : "Realtime handshake OK, nhưng media chưa sẵn sàng.",
                false,
                "message"
              );
              this.log(`SIGNAL probe_answer ok offer_id=${answerOfferID} rtt_ms=${rttMs ?? "-"} media_ready=0 reason=${mediaReason || "-"}`);
              return;
            }
            this.transportMediaReady = true;
            this.streamState = "connecting";
            this.updateVisualState();
            this.updateOverlay(
              rttMs == null
                ? "Realtime handshake OK (probe_answer)."
                : `Realtime handshake OK (probe RTT ${rttMs}ms).`,
              false,
              "message"
            );
            this.log(`SIGNAL probe_answer ok offer_id=${answerOfferID} rtt_ms=${rttMs ?? "-"} media_ready=1`);
            this.ensureHandLaneAttached(signalUrl);
            this.connectFoundationMediaStream(signalUrl);
          } else {
            this.log(`SIGNAL probe_answer mismatch offer_id=${answerOfferID || "-"}`);
          }
        } else {
          this.log(`SIGNAL ${payload.signal_type || "opaque"} từ ${payload.source_role || "-"}`);
        }
      } else if (payload.type === "error") {
        this.streamState = "error";
        this.updateVisualState();
        this.updateOverlay(`Signal lỗi: ${payload.reason}`, false, "message");
        this.log(`SIGNAL error=${payload.reason}`);
      }
    });

    signalingSocket.addEventListener("close", () => {
      if (this.signalingSocket !== signalingSocket) {
        return;
      }
      this.signalingSocket = null;
      this.streamState = "idle";
      this.updateVisualState();
      this.updateOverlay("Đã ngắt signaling", false, "message");
    });

    signalingSocket.addEventListener("error", () => {
      if (this.signalingSocket !== signalingSocket) {
        return;
      }
      this.streamState = "error";
      this.updateVisualState();
      this.updateOverlay("Signal bị lỗi", false, "message");
    });
  }

  async connectLegacyRelay() {
    this.disconnect("reconnect");
    this.resetDecoderState();
    this.streamState = "connecting";
    this.handState = "connecting";
    this.lastError = "";
    this.updateOverlay("Đang kết nối relay...", false, "spinner");
    this.updateVisualState();
    const relaySocketUrl = toWebSocketUrl(appState.relayUrl);
    this.log(`Kết nối fallback ${relaySocketUrl} cho máy ${this.device.id}`);

    const streamSocket = new WebSocket(relaySocketUrl);
    streamSocket.binaryType = "arraybuffer";
    this.streamSocket = streamSocket;

    streamSocket.addEventListener("open", () => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      this.sendJson(streamSocket, {
        type: "register",
        role: "mac",
        device_id: this.device.id,
        subchannel: "stream",
        codec: "h264",
        client: "hid_probe_farm_web",
        session_id: this.device.sessionId || "",
        auth_token: this.device.authToken || "",
        ts: new Date().toISOString(),
      });
    });

    streamSocket.addEventListener("close", async () => {
      if (this.streamSocket === streamSocket) {
        this.clearNoFrameHintTimer();
        this.streamSocket = null;
        this.streamState = "idle";
        this.updateVisualState();
        this.updateOverlay("Đã ngắt", false, "message");
      }
      this.armPendingGestureCancel("stream_socket_closed");
      await this.finalizeActiveFrame("stream_socket_close");
    });

    streamSocket.addEventListener("error", () => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      this.clearNoFrameHintTimer();
      this.streamState = "error";
      this.updateVisualState();
      this.updateOverlay("Mất kết nối", false, "message");
      this.armPendingGestureCancel("stream_socket_error");
    });

    streamSocket.addEventListener("message", async (event) => {
      if (this.streamSocket !== streamSocket) {
        return;
      }
      try {
        if (typeof event.data === "string") {
          const payload = parseSocketText(event.data);
          if (!payload) {
            return;
          }
          if (payload.type === "register_ack") {
            this.streamState = "connected";
            this.updateVisualState();
            this.updateOverlay("Đang chờ khung hình...", false, "spinner");
            this.scheduleNoFrameHint("legacy");
            this.log("STREAM đã xác nhận relay");
          } else if (payload.type === "source_info") {
            this.updateSourceInfo(payload);
          } else if (payload.type === "error") {
            this.streamState = "error";
            this.updateVisualState();
            this.updateOverlay(`STREAM lỗi: ${payload.reason}`, false, "message");
            this.log(`STREAM relay_error=${payload.reason}`);
          }
          return;
        }
        const buffer = await binaryToArrayBuffer(event.data);
        await this.handleStreamBinaryMessage(buffer);
      } catch (error) {
        this.log(`Lỗi xử lý stream binary: ${error.message || error}`);
        this.updateOverlay("Lỗi xử lý khung hình", false, "message");
      }
    });

    const handSocket = new WebSocket(relaySocketUrl);
    this.handSocket = handSocket;

    handSocket.addEventListener("open", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      this.sendJson(handSocket, {
        type: "register",
        role: "mac",
        device_id: this.device.id,
        subchannel: "hand",
        client: "hid_probe_farm_web",
        session_id: this.device.sessionId || "",
        auth_token: this.device.authToken || "",
        ts: new Date().toISOString(),
      });
    });

    handSocket.addEventListener("close", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      this.armPendingGestureCancel("hand_socket_closed");
      this.resetGesture();
      this.handSocket = null;
      this.handState = "idle";
      this.updateVisualState();
    });

    handSocket.addEventListener("error", () => {
      if (this.handSocket !== handSocket) {
        return;
      }
      this.armPendingGestureCancel("hand_socket_error");
      this.resetGesture();
      this.handState = "error";
      this.updateVisualState();
    });

    handSocket.addEventListener("message", (event) => {
      if (this.handSocket !== handSocket || typeof event.data !== "string") {
        return;
      }
      const payload = parseSocketText(event.data);
      if (!payload) {
        return;
      }
      if (payload.type === "register_ack") {
        this.handState = "connected";
        this.updateVisualState();
        this.log("HAND đã xác nhận relay");
        this.flushPendingGestureCancel();
      } else if (payload.type === "hid_ack") {
        this.handleHIDAck(payload);
      } else if (payload.type === "ack") {
        this.log(`HAND ack stage=${payload.stage || "-"} ok=${payload.ok !== false} reason=${payload.reason || "-"}`);
      } else if (payload.type === "error") {
        this.handState = "error";
        this.updateVisualState();
        this.log(`HAND relay_error=${payload.reason}`);
      }
    });
  }

  disconnect(reason) {
    if (this.gesture.active) {
      this.armPendingGestureCancel(reason || "manual_disconnect");
      this.flushPendingGestureCancel();
      this.resetGesture();
    }
    const signalingSocket = this.signalingSocket;
    const streamSocket = this.streamSocket;
    const handSocket = this.handSocket;
    this.signalingSocket = null;
    this.streamSocket = null;
    this.handSocket = null;
    this.transportProbeOfferID = "";
    this.transportProbeSentAtMs = 0;
    this.transportProbeAcked = false;
    this.transportMediaReady = null;
    this.foundationMediaStarted = false;
    this.clearNoFrameHintTimer();
    this.streamFirstPacketSeen = false;
    if (signalingSocket && signalingSocket.readyState <= WebSocket.OPEN) {
      signalingSocket.close(1000, reason);
    }
    if (streamSocket && streamSocket.readyState <= WebSocket.OPEN) {
      streamSocket.close(1000, reason);
    }
    if (handSocket && handSocket.readyState <= WebSocket.OPEN) {
      handSocket.close(1000, reason);
    }
    this.streamState = "idle";
    this.handState = "idle";
    this.resetDecoderState();
    this.updateOverlay(reason === "manual_disconnect" ? "Đã ngắt" : "Chưa kết nối", false, "message");
    this.updateVisualState();
  }
}

function renderDevices() {
  const desiredIds = new Set(appState.devices.map((device) => device.id));

  for (const [deviceId, controller] of appState.controllers) {
    if (!desiredIds.has(deviceId)) {
      controller.destroy();
      appState.controllers.delete(deviceId);
    }
  }

  for (const device of appState.devices) {
    let controller = appState.controllers.get(device.id);
    if (!controller) {
      controller = new DeviceController(device);
      controller.mount(els.deviceGrid);
      appState.controllers.set(device.id, controller);
    } else {
      controller.updateDevice(device);
    }
  }

  const ordered = appState.devices
    .map((device) => appState.controllers.get(device.id))
    .filter(Boolean);
  for (const controller of ordered) {
    els.deviceGrid.appendChild(controller.card);
  }

  if (!appState.selectedDeviceId || !appState.controllers.has(appState.selectedDeviceId)) {
    appState.selectedDeviceId = appState.devices[0]?.id || null;
  }

  updateStats();
  renderSelectedDevicePanel();
  for (const controller of appState.controllers.values()) {
    controller.syncSelection();
  }
}

function connectAll() {
  for (const controller of appState.controllers.values()) {
    controller.connect().catch((error) => controller.failWith(`Kết nối thất bại: ${error.message || error}`));
  }
  toast("⚡ Đang kết nối tất cả...");
}

function disconnectAll(reason = "manual_disconnect") {
  for (const controller of appState.controllers.values()) {
    controller.disconnect(reason);
  }
}

function updateRelayUrl(nextValue) {
  appState.relayUrl = normalizeRelayUrl(nextValue);
  els.relayInput.value = appState.relayUrl;
  saveSettings();
  renderSelectedDevicePanel();
  refreshDevicesFromRegistry().catch((error) => {
    appendLog(`Không đồng bộ được registry: ${error.message || error}`);
  });
}

function syncLiveMetrics() {
  const controller = getSelectedController();
  if (controller && controller.currentPresentedMeta) {
    controller.updateMetricPills();
  } else {
    renderSelectedDevicePanel();
  }
}

function redrawAllControllers() {
  for (const controller of appState.controllers.values()) {
    controller.redrawCurrentFrame();
    controller.updateMetricPills();
  }
}

function installBindings() {
  els.relayInput.addEventListener("change", () => updateRelayUrl(els.relayInput.value));
  els.fitModeSelect.addEventListener("change", () => {
    appState.fitMode = els.fitModeSelect.value;
    saveSettings();
    appendLog(`Đổi chế độ hiển thị sang ${appState.fitMode === "cover" ? "Phủ đầy" : "Vừa khung"}`);
    redrawAllControllers();
  });
  els.rotationSelect.addEventListener("change", () => {
    appState.rotation = Number(els.rotationSelect.value);
    saveSettings();
    appendLog(`Đổi góc xoay sang ${appState.rotation}°`);
    redrawAllControllers();
  });
  els.zoomRange.addEventListener("input", () => {
    appState.cardWidth = Number(els.zoomRange.value);
    applyCardWidth();
    saveSettings();
    redrawAllControllers();
  });
  els.addDeviceButton.addEventListener("click", () => openAddModal());
  els.connectAllButton.addEventListener("click", () => connectAll());
  els.disconnectAllButton.addEventListener("click", () => disconnectAll());
  els.exportButton.addEventListener("click", () => exportDevices());
  els.importButton.addEventListener("click", () => els.fileImport.click());
  els.fileImport.addEventListener("change", async () => {
    const file = els.fileImport.files?.[0];
    if (!file) {
      return;
    }
    try {
      await importDevicesFromFile(file);
    } catch (error) {
      appendLog(`Nhập JSON thất bại: ${error.message || error}`);
    } finally {
      els.fileImport.value = "";
    }
  });
  els.clearLogButton.addEventListener("click", () => {
    appState.logs = [];
    els.logOutput.textContent = "";
  });
  els.selectedConnectButton.addEventListener("click", () => {
    const controller = getSelectedController();
    if (!controller) {
      return;
    }
    controller.connect().catch((error) => controller.failWith(`Kết nối thất bại: ${error.message || error}`));
  });
  els.selectedDisconnectButton.addEventListener("click", () => {
    const controller = getSelectedController();
    if (!controller) {
      return;
    }
    controller.disconnect("manual_disconnect");
  });
  els.modalCloseButton.addEventListener("click", closeAddModal);
  els.modalCancelButton.addEventListener("click", closeAddModal);
  els.addModal.addEventListener("click", (event) => {
    if (event.target instanceof HTMLElement && event.target.dataset.closeModal === "true") {
      closeAddModal();
    }
  });
  els.addDeviceForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const record = normalizeDeviceRecord({
      id: els.addDeviceId.value,
      name: els.addDeviceName.value,
      note: els.addDeviceNote.value,
      sessionId: els.addDeviceSession.value,
      authToken: els.addDeviceToken.value,
    });
    if (!record) {
      appendLog("Không thể thêm máy: mã máy đang trống");
      return;
    }
    upsertDeviceRecord(record);
    appendLog(`Đã lưu thiết bị ${record.id}`);
    closeAddModal();
  });
  window.addEventListener("resize", () => {
    redrawAllControllers();
  });
  window.addEventListener("pagehide", () => disconnectAll("pagehide"));
  window.addEventListener("beforeunload", () => disconnectAll("beforeunload"));
  setInterval(syncLiveMetrics, 500);
}

function bootstrap() {
  const settings = loadSettings();
  appState.relayUrl = settings.relayUrl;
  appState.fitMode = settings.fitMode;
  appState.rotation = settings.rotation;
  appState.cardWidth = settings.cardWidth;
  appState.devices = loadDevices();

  els.relayInput.value = appState.relayUrl;
  els.fitModeSelect.value = appState.fitMode;
  els.rotationSelect.value = String(appState.rotation);
  applyCardWidth();
  renderDevices();
  installBindings();
  refreshDevicesFromRegistry().catch((error) => {
    appendLog(`Không đồng bộ được registry: ${error.message || error}`);
  });
  appendLog(`Dashboard đã sẵn sàng tại ${appState.relayUrl}`);
}

bootstrap();
