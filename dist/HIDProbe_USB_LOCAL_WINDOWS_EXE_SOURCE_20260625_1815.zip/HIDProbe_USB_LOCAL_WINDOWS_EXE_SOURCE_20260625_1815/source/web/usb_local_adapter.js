(function () {
  "use strict";

  const TAP_MS = 200;
  const TAP_MOVE_PX = 8;
  const MOVE_THROTTLE_MS = 16;

  const state = {
    devices: [],
    selectedDeviceId: "",
    selectedIds: new Set(),
    slaveIds: new Set(),
    syncEnabled: false,
    live: false,
    tunnelStatus: "USB tunnel: waiting",
    frameInFlight: false,
    frameCount: 0,
    lastFrameAt: 0,
    lastFpsAt: performance.now(),
    lastReconnectRequestAt: 0,
    fps: 0,
    gestureSeq: 0,
    hidSent: 0,
    hidDropped: 0,
    logLines: [],
    devicesSignature: "",
    lastRenderedSignature: "",
    lastTunnelStatus: "",
  };

  const $ = (id) => document.getElementById(id);
  const els = {
    grid: $("device-grid"),
    groupSidebar: $("group-sidebar"),
    emptyState: $("empty-state"),
    apiInput: $("api-input"),
    statStreaming: $("stat-streaming"),
    statWaiting: $("stat-waiting"),
    statTotal: $("stat-total"),
    statLimit: $("stat-limit"),
    syncPill: $("sync-dispatch-pill"),
    showingCount: $("showing-count"),
    bulkBar: $("bulk-bar"),
    bulkCount: $("bulk-count"),
  };

  function injectStyle() {
    const style = document.createElement("style");
    style.textContent = `
      body.usb-local-mode .logo::after { content:" USB"; color:#10b981; margin-left:6px; }
      body.usb-local-mode #api-input { min-width: 210px; }
      .vs img.usb-screen {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
        background: #000;
        user-select: none;
        -webkit-user-drag: none;
      }
      .vs canvas.usb-touch {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        cursor: crosshair;
        touch-action: none;
      }
      .usb-log-strip {
        position: fixed;
        left: 14px;
        bottom: 12px;
        z-index: 80;
        max-width: min(760px, calc(100vw - 28px));
        color: #d7e7ff;
        background: rgba(8, 15, 30, .88);
        border: 1px solid rgba(148, 163, 184, .25);
        border-radius: 12px;
        padding: 8px 10px;
        font: 11px/1.4 ui-monospace, SFMono-Regular, Menlo, monospace;
        box-shadow: 0 10px 30px rgba(0,0,0,.3);
        pointer-events: none;
      }
      .usb-local-mode .covl.hidden { opacity: 0; pointer-events: none; }
      .usb-local-mode .phone-card.connected .covl { opacity: 0; pointer-events: none; }
      .usb-local-mode .phone-card.error .covl,
      .usb-local-mode .phone-card.waiting .covl { opacity: 1; }
      body.usb-local-mode.usb-has-devices #empty-state {
        display: none !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
    `;
    document.head.appendChild(style);
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#39;",
    }[char]));
  }

  function native(type, payload = {}) {
    try {
      window.webkit?.messageHandlers?.hidprobe?.postMessage({ type, ...payload });
    } catch (error) {
      pushLog(`Native bridge error: ${error?.message || error}`);
    }
  }

  function pushLog(message) {
    const stamp = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    state.logLines.unshift(`[${stamp}] ${message}`);
    state.logLines = state.logLines.slice(0, 4);
    let strip = document.querySelector(".usb-log-strip");
    if (!strip) {
      strip = document.createElement("div");
      strip.className = "usb-log-strip";
      document.body.appendChild(strip);
    }
    strip.textContent = state.logLines.join("  |  ");
  }

  function toast(message) {
    pushLog(message);
    if (typeof window.toast === "function") {
      try { window.toast(message); } catch (_) {}
    }
  }

  function normalizeDevice(raw, index) {
    const id = String(raw.id || raw.Identifier || raw.UniqueDeviceID || raw.udid || `iphone-${index + 1}`);
    const name = String(raw.name || raw.DeviceName || raw.Name || `iPhone USB ${index + 1}`);
    return {
      id,
      name,
      productType: String(raw.productType || raw.ProductType || ""),
      productVersion: String(raw.productVersion || raw.ProductVersion || ""),
      connectionType: String(raw.connectionType || raw.ConnectionType || "USB"),
    };
  }

  function selectedDevice() {
    return state.devices.find((device) => device.id === state.selectedDeviceId) || state.devices[0] || null;
  }

  function shortId(id) {
    const text = String(id || "");
    return text.length > 14 ? `${text.slice(0, 7)}...${text.slice(-5)}` : text;
  }

  function deviceSignature(devices) {
    return devices.map((device) => [
      device.id,
      device.name,
      device.productType,
      device.productVersion,
      device.connectionType,
    ].join("|")).join(";");
  }

  function uiSignature() {
    return [
      state.devicesSignature,
      state.selectedDeviceId,
      Array.from(state.selectedIds).sort().join(","),
      Array.from(state.slaveIds).sort().join(","),
      state.syncEnabled ? "sync1" : "sync0",
      state.live ? "live1" : "live0",
    ].join("::");
  }

  function setStats() {
    const total = state.devices.length;
    const streaming = state.live && selectedDevice() ? 1 : 0;
    const waiting = Math.max(0, total - streaming);
    if (els.statTotal) els.statTotal.textContent = String(total);
    if (els.statStreaming) els.statStreaming.textContent = String(streaming);
    if (els.statWaiting) els.statWaiting.textContent = String(waiting);
    if (els.statLimit) els.statLimit.textContent = "USB";
    if (els.syncPill) {
      const master = selectedDevice();
      els.syncPill.textContent = state.syncEnabled
        ? `sync: ON · master ${master ? shortId(master.id) : "-"} · slave ${state.slaveIds.size}`
        : `sync: OFF · ${state.tunnelStatus}`;
    }
    if (els.showingCount) els.showingCount.textContent = `Showing ${total} of ${total}`;
    if (els.bulkCount) els.bulkCount.textContent = `${state.selectedIds.size} chọn`;
    if (els.bulkBar) els.bulkBar.classList.toggle("active", state.selectedIds.size > 0);
    forceUSBChrome();
  }

  function hasUSBDevices() {
    return state.devices.length > 0 || !!els.grid?.querySelector(".phone-card[data-device-id]");
  }

  function forceUSBChrome() {
    const hasDevices = hasUSBDevices();
    const cardCount = els.grid?.querySelectorAll(".phone-card[data-device-id]").length || 0;
    const total = Math.max(state.devices.length, cardCount);
    const streaming = state.live && total > 0 ? 1 : 0;
    const waiting = Math.max(0, total - streaming);
    document.body.classList.toggle("usb-has-devices", hasDevices);
    if (els.emptyState) {
      els.emptyState.classList.toggle("hidden", hasDevices);
      els.emptyState.setAttribute("aria-hidden", hasDevices ? "true" : "false");
      const nextDisplay = hasDevices ? "none" : "";
      if (els.emptyState.style.display !== nextDisplay) els.emptyState.style.display = nextDisplay;
    }
    if (hasDevices) {
      if (els.statTotal) els.statTotal.textContent = String(total);
      if (els.statStreaming) els.statStreaming.textContent = String(streaming);
      if (els.statWaiting) els.statWaiting.textContent = String(waiting);
      if (els.syncPill && !state.syncEnabled) els.syncPill.textContent = `sync: OFF · ${state.tunnelStatus}`;
    }
    if (els.statLimit && els.statLimit.textContent !== "USB") {
      els.statLimit.textContent = "USB";
    }
  }

  function installChromeGuard() {
    const originalUpdateStats = window.updateStats;
    if (typeof originalUpdateStats === "function" && !originalUpdateStats.__usbGuarded) {
      const guarded = function (...args) {
        const result = originalUpdateStats.apply(this, args);
        forceUSBChrome();
        return result;
      };
      guarded.__usbGuarded = true;
      window.updateStats = guarded;
    }
    const scheduleGuard = () => requestAnimationFrame(forceUSBChrome);
    if (els.emptyState) {
      new MutationObserver(scheduleGuard).observe(els.emptyState, {
        attributes: true,
        attributeFilter: ["class", "style", "aria-hidden"],
      });
    }
    if (els.statLimit) {
      new MutationObserver(scheduleGuard).observe(els.statLimit, {
        childList: true,
        characterData: true,
        subtree: true,
      });
    }
  }

  function renderSidebar() {
    if (!els.groupSidebar) return;
    els.groupSidebar.innerHTML = `
      <div class="group-item active" data-usb-group="all">
        <div>
          <strong>Tất cả USB</strong>
          <small>${state.devices.length} máy đã Trust</small>
        </div>
        <span>${state.devices.length}</span>
      </div>
      <div class="group-item" data-usb-group="local">
        <div>
          <strong>Máy chủ local</strong>
          <small>Mac -> USB -> iPhone</small>
        </div>
        <span>${state.live ? "ON" : "WAIT"}</span>
      </div>
      <div class="group-item" data-usb-group="sync">
        <div>
          <strong>Đồng bộ máy gốc</strong>
          <small>Master/Slave qua USB adapter</small>
        </div>
        <span>${state.syncEnabled ? "ON" : "OFF"}</span>
      </div>`;
  }

  function cardStatus(device) {
    if (device.id !== state.selectedDeviceId) return "waiting";
    return state.live ? "connected" : "waiting";
  }

  function renderCards() {
    if (!els.grid) return;
    const nextSignature = uiSignature();
    if (state.lastRenderedSignature === nextSignature) {
      updateMetrics();
      return;
    }
    state.lastRenderedSignature = nextSignature;
    document.body.classList.add("usb-local-mode");
    if (els.emptyState) els.emptyState.classList.toggle("hidden", state.devices.length > 0);
    if (!state.devices.length) {
      els.grid.innerHTML = "";
      setStats();
      renderSidebar();
      return;
    }

    els.grid.innerHTML = state.devices.map((device) => {
      const status = cardStatus(device);
      const selected = state.selectedIds.has(device.id);
      const isMaster = device.id === state.selectedDeviceId;
      const isSlave = state.slaveIds.has(device.id);
      const meta = [device.productType, device.productVersion ? `iOS ${device.productVersion}` : "", device.connectionType].filter(Boolean).join(" · ");
      return `
        <div class="phone-card ${status} ${selected ? "selected" : ""} ${isMaster ? "is-master" : ""} ${isSlave ? "is-slave" : ""}" data-device-id="${escapeHtml(device.id)}">
          <div class="phone-frame">
            <input class="card-select" type="checkbox" title="Chọn máy" ${selected ? "checked" : ""}>
            <div class="status-dot"></div>
            <div class="role-strip">
              <span class="role-badge master ${isMaster ? "" : "hidden"}">★ MASTER</span>
              <span class="role-badge slave ${isSlave ? "" : "hidden"}">SLAVE</span>
              <span class="role-badge muted hidden">MUTE</span>
              <span class="role-badge warn hidden">DEGRADED</span>
            </div>
            <div class="side-rail left" aria-label="Điều khiển nhanh">
              <button class="quick-btn icon-btn" data-quick-action="home" type="button" title="Home">⌂</button>
              <button class="quick-btn icon-btn" data-quick-action="swipe_up" type="button" title="Vuốt lên">↑</button>
              <button class="quick-btn icon-btn" data-quick-action="swipe_down" type="button" title="Vuốt xuống">↓</button>
              <button class="quick-btn icon-btn" data-quick-action="swipe_left" type="button" title="Vuốt trái">←</button>
              <button class="quick-btn icon-btn" data-quick-action="swipe_right" type="button" title="Vuốt phải">→</button>
              <button class="quick-btn icon-btn" data-quick-action="long_center" type="button" title="Giữ / Long press">●</button>
              <button class="quick-btn icon-btn" data-quick-action="screenshot" type="button" title="Chụp màn hình">▣</button>
              <button class="quick-btn icon-btn" data-quick-action="tap_center" type="button" title="Tap giữa">⏱</button>
            </div>
            <div class="iphone">
              <div class="screen">
                <div class="vs">
                  <img class="usb-screen" draggable="false" alt="USB screen ${escapeHtml(device.name)}">
                  <canvas class="usb-touch"></canvas>
                  <div class="covl ${status === "connected" ? "hidden" : ""}">
                    <div class="ov-title">${status === "connected" ? "Đang live USB" : "Chưa kết nối USB"}</div>
                    <div class="ov-sub">${escapeHtml(state.tunnelStatus)}</div>
                  </div>
                </div>
                <div class="home-indicator"></div>
              </div>
            </div>
            <div class="phone-id-strip" aria-hidden="true">
              <span class="phone-id-status"></span>
              <span class="phone-id-id">${escapeHtml(shortId(device.id))}</span>
            </div>
            <div class="side-rail right" aria-label="Kịch bản">
              <button class="mini-btn connect action-btn green" type="button"><span class="mark">⌘</span>Kết nối</button>
              <button class="mini-btn disconnect action-btn red" type="button"><span class="mark">■</span>Ngắt</button>
              <select class="workflow-card-select" title="Chọn kịch bản đã lưu"><option value="">Chọn kịch bản</option></select>
              <button class="quick-btn workflow-card-run action-btn green" type="button"><span class="mark">▶</span>Chạy KB</button>
              <button class="mini-btn role-mute action-btn red" type="button"><span class="mark">■</span>Dừng</button>
              <button class="mini-btn role-master action-btn gold" type="button"><span class="mark">M</span>${isMaster ? "Master" : "Master"}</button>
              <button class="mini-btn role-slave action-btn purple" type="button"><span class="mark">S</span>${isSlave ? "Bỏ slave" : "Slave"}</button>
            </div>
          </div>
          <div class="phone-meta"><div class="nm">${escapeHtml(device.name)}</div><div class="id">${escapeHtml(meta || device.id)}</div></div>
          <div class="hidden-runtime"><div class="info"><div class="metrics">${escapeHtml(status === "connected" ? `${state.fps} fps · hid ${state.hidSent}/${state.hidDropped}` : state.tunnelStatus)}</div></div></div>
        </div>`;
    }).join("");

    bindCards();
    setStats();
    renderSidebar();
  }

  function bindCards() {
    document.querySelectorAll(".phone-card[data-device-id]").forEach((card) => {
      const deviceId = card.dataset.deviceId;
      const img = card.querySelector("img.usb-screen");
      const canvas = card.querySelector("canvas.usb-touch");
      card.querySelector(".connect")?.addEventListener("click", () => connectDevice(deviceId));
      card.querySelector(".disconnect")?.addEventListener("click", () => disconnectDevice(deviceId));
      card.querySelector(".role-master")?.addEventListener("click", () => connectDevice(deviceId));
      card.querySelector(".role-slave")?.addEventListener("click", () => toggleSlave(deviceId));
      card.querySelector(".role-mute")?.addEventListener("click", () => sendQuickAction("home"));
      card.querySelector(".workflow-card-run")?.addEventListener("click", () => runDefaultLua());
      card.querySelector(".card-select")?.addEventListener("change", (event) => {
        if (event.target.checked) state.selectedIds.add(deviceId);
        else state.selectedIds.delete(deviceId);
        updateCardClasses();
        updateMetrics();
      });
      card.querySelectorAll("[data-quick-action]").forEach((button) => {
        button.addEventListener("click", () => sendQuickAction(button.dataset.quickAction));
      });
      if (img && canvas) installTouchOverlay(img, canvas);
    });
  }

  function connectDevice(deviceId) {
    const changed = state.selectedDeviceId !== deviceId || !state.live;
    state.selectedDeviceId = deviceId;
    state.selectedIds.add(deviceId);
    state.live = true;
    native("connectDevice", { device_id: deviceId });
    if (changed) renderCards();
    else updateMetrics();
    startLiveFrames();
    toast(`Kết nối USB: ${shortId(deviceId)}`);
  }

  function disconnectDevice(deviceId) {
    if (!deviceId || deviceId === state.selectedDeviceId) {
      state.live = false;
      native("disconnectAll");
      stopLiveFrames();
      toast("Đã ngắt stream USB local");
    }
    renderCards();
  }

  function toggleSlave(deviceId) {
    if (state.slaveIds.has(deviceId)) state.slaveIds.delete(deviceId);
    else state.slaveIds.add(deviceId);
    renderCards();
  }

  function startLiveFrames() {
    stopLiveFrames();
    state.live = true;
    native("ensureTunnel", { reason: "native_stream_start" });
  }

  function stopLiveFrames() {
    state.frameInFlight = false;
  }

  function pullFrame() {
    const device = selectedDevice();
    if (!device || !state.live) return;
    native("requestNativeFrame", { device_id: device.id, reason: "manual_frame_request" });
  }

  function renderNativeFrame(frame) {
    const device = selectedDevice();
    if (!device || !state.live) return;
    const img = document.querySelector(`.phone-card[data-device-id="${CSS.escape(device.id)}"] img.usb-screen`);
    const dataBase64 = frame && typeof frame === "object" ? frame.dataBase64 : frame;
    const mime = frame && typeof frame === "object" && frame.mime ? frame.mime : "image/jpeg";
    const jpegBase64 = String(dataBase64 || "").replace(/^data:image\/jpeg;base64,/, "");
    if (!img || !jpegBase64) return;
    img.onload = null;
    img.onerror = () => {
      state.tunnelStatus = "Frame native lỗi, đang nối lại USB";
      const now = performance.now();
      if (now - state.lastReconnectRequestAt >= 5000) {
        state.lastReconnectRequestAt = now;
        native("ensureTunnel", { reason: "native_frame_error" });
      }
      updateCardClasses();
      updateMetrics();
    };
    img.src = `data:${mime};base64,${jpegBase64}`;
    state.frameCount += 1;
    state.lastFrameAt = performance.now();
    if (state.tunnelStatus !== "USB native stream: receiving frames") {
      state.tunnelStatus = "USB native stream: receiving frames";
      updateCardClasses();
    }
    const now = performance.now();
    if (now - state.lastFpsAt >= 1000) {
      state.fps = Math.round((state.frameCount * 1000) / (now - state.lastFpsAt));
      state.frameCount = 0;
      state.lastFpsAt = now;
      updateMetrics();
    }
  }

  function updateMetrics() {
    document.querySelectorAll(".phone-card[data-device-id]").forEach((card) => {
      const id = card.dataset.deviceId;
      const metrics = card.querySelector(".metrics");
      if (!metrics) return;
      metrics.textContent = id === state.selectedDeviceId && state.live
        ? `${state.fps} fps · hid ${state.hidSent}/${state.hidDropped} · ${state.tunnelStatus}`
        : state.tunnelStatus;
    });
    setStats();
  }

  function updateCardClasses() {
    document.querySelectorAll(".phone-card[data-device-id]").forEach((card) => {
      const id = card.dataset.deviceId;
      const isSelected = state.selectedIds.has(id);
      const isMaster = id === state.selectedDeviceId;
      const isSlave = state.slaveIds.has(id);
      const isConnected = isMaster && state.live;
      card.classList.toggle("selected", isSelected);
      card.classList.toggle("is-master", isMaster);
      card.classList.toggle("is-slave", isSlave);
      card.classList.toggle("connected", isConnected);
      card.classList.toggle("waiting", !isConnected);
      card.querySelector(".role-badge.master")?.classList.toggle("hidden", !isMaster);
      card.querySelector(".role-badge.slave")?.classList.toggle("hidden", !isSlave);
      const checkbox = card.querySelector(".card-select");
      if (checkbox) checkbox.checked = isSelected;
      const overlay = card.querySelector(".covl");
      overlay?.classList.toggle("hidden", isConnected);
      const sub = card.querySelector(".ov-sub");
      if (sub) sub.textContent = state.tunnelStatus;
    });
  }

  function pointFromEvent(event, img, canvas, allowOutside) {
    const rect = img.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    canvas.width = Math.max(1, Math.round(rect.width));
    canvas.height = Math.max(1, Math.round(rect.height));
    const rawX = (event.clientX - rect.left) / rect.width;
    const rawY = (event.clientY - rect.top) / rect.height;
    if (!allowOutside && (rawX < 0 || rawX > 1 || rawY < 0 || rawY > 1)) return null;
    return { x: Math.min(Math.max(rawX, 0), 1), y: Math.min(Math.max(rawY, 0), 1) };
  }

  function installTouchOverlay(img, canvas) {
    const drag = { active: false };
    const cleanup = (reason, finalPhase, event) => {
      if (!drag.active) return;
      const point = event ? pointFromEvent(event, img, canvas, true) : drag.lastPoint;
      const elapsed = performance.now() - drag.startTs;
      const dx = Math.abs(((point || drag.startPoint).x - drag.startPoint.x) * canvas.width);
      const dy = Math.abs(((point || drag.startPoint).y - drag.startPoint.y) * canvas.height);
      const isTap = !drag.sentDown && finalPhase === "gesture_up" && elapsed <= TAP_MS && Math.max(dx, dy) <= TAP_MOVE_PX;
      if (isTap) {
        sendHID({ type: "tap", phase: "tap", x: drag.startPoint.x, y: drag.startPoint.y, gesture_id: drag.gestureId, reason });
      } else if (finalPhase === "gesture_up") {
        if (!drag.sentDown) {
          sendHID({ type: "gesture_down", phase: "gesture_down", x: drag.startPoint.x, y: drag.startPoint.y, gesture_id: drag.gestureId, reason: "late_down" });
          drag.sentDown = true;
        }
        if (point) sendHID({ type: "gesture_move", phase: "gesture_move", x: point.x, y: point.y, gesture_id: drag.gestureId, reason: "final_move" });
        sendHID({ type: "gesture_up", phase: "gesture_up", x: (point || drag.startPoint).x, y: (point || drag.startPoint).y, gesture_id: drag.gestureId, reason });
      } else if (drag.sentDown) {
        sendHID({ type: "gesture_cancel", phase: "gesture_cancel", x: (point || drag.startPoint).x, y: (point || drag.startPoint).y, gesture_id: drag.gestureId, reason });
      }
      try { if (canvas.hasPointerCapture?.(drag.pointerId)) canvas.releasePointerCapture(drag.pointerId); } catch (_) {}
      drag.active = false;
    };

    canvas.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 && event.pointerType !== "touch") return;
      const point = pointFromEvent(event, img, canvas, false);
      if (!point) return;
      if (drag.active) cleanup("new_pointerdown", "gesture_cancel");
      canvas.setPointerCapture(event.pointerId);
      Object.assign(drag, {
        active: true,
        pointerId: event.pointerId,
        gestureId: `usb-${Date.now()}-${++state.gestureSeq}`,
        startPoint: point,
        lastPoint: point,
        startTs: performance.now(),
        startedSwipe: false,
        sentDown: false,
        lastMoveAt: 0,
      });
    });
    canvas.addEventListener("pointermove", (event) => {
      if (!drag.active || drag.pointerId !== event.pointerId) return;
      const now = performance.now();
      const point = pointFromEvent(event, img, canvas, true);
      if (!point) return;
      const dx = Math.abs((point.x - drag.startPoint.x) * canvas.width);
      const dy = Math.abs((point.y - drag.startPoint.y) * canvas.height);
      if (!drag.startedSwipe && Math.max(dx, dy) > TAP_MOVE_PX) {
        drag.startedSwipe = true;
        drag.sentDown = true;
        sendHID({ type: "gesture_down", phase: "gesture_down", x: drag.startPoint.x, y: drag.startPoint.y, gesture_id: drag.gestureId });
      }
      if (!drag.startedSwipe || now - drag.lastMoveAt < MOVE_THROTTLE_MS) return;
      drag.lastMoveAt = now;
      drag.lastPoint = point;
      sendHID({ type: "gesture_move", phase: "gesture_move", x: point.x, y: point.y, gesture_id: drag.gestureId });
    });
    canvas.addEventListener("pointerup", (event) => cleanup("pointerup", "gesture_up", event));
    canvas.addEventListener("pointercancel", (event) => cleanup("pointercancel", "gesture_cancel", event));
    canvas.addEventListener("lostpointercapture", () => cleanup("lostpointercapture", "gesture_cancel"));
  }

  async function sendHID(payload) {
    try {
      const normalized = { ...payload, seq: ++state.gestureSeq, sent_at_ms: Math.round(performance.now()) };
      native("sendNativeHID", { payload: normalized });
      state.hidSent += 1;
      if (state.syncEnabled && selectedDevice() && state.slaveIds.size > 0) {
        document.querySelector(`.phone-card[data-device-id="${CSS.escape(state.selectedDeviceId)}"]`)?.classList.add("sync-flash");
        setTimeout(() => document.querySelectorAll(".sync-flash").forEach((node) => node.classList.remove("sync-flash")), 230);
      }
      updateMetrics();
      return true;
    } catch (error) {
      state.hidDropped += 1;
      state.tunnelStatus = "HID lỗi, đang tự nối lại USB";
      native("ensureTunnel", { reason: "hid_error" });
      updateMetrics();
      toast(`HID lỗi: ${error?.message || error}`);
      return false;
    }
  }

  async function sendSwipe(from, to, durationMs = 260, steps = 10) {
    const gestureId = `quick-${Date.now()}-${++state.gestureSeq}`;
    await sendHID({ type: "gesture_down", phase: "gesture_down", x: from.x, y: from.y, gesture_id: gestureId, reason: "quick_swipe" });
    for (let step = 1; step <= steps; step += 1) {
      const ratio = step / steps;
      await new Promise((resolve) => setTimeout(resolve, Math.max(12, durationMs / steps)));
      await sendHID({
        type: "gesture_move",
        phase: "gesture_move",
        x: from.x + (to.x - from.x) * ratio,
        y: from.y + (to.y - from.y) * ratio,
        gesture_id: gestureId,
        reason: "quick_swipe",
      });
    }
    await sendHID({ type: "gesture_up", phase: "gesture_up", x: to.x, y: to.y, gesture_id: gestureId, reason: "quick_swipe" });
  }

  async function sendQuickAction(action) {
    const map = {
      swipe_up: [{ x: 0.5, y: 0.76 }, { x: 0.5, y: 0.24 }],
      swipe_down: [{ x: 0.5, y: 0.24 }, { x: 0.5, y: 0.76 }],
      swipe_left: [{ x: 0.78, y: 0.5 }, { x: 0.22, y: 0.5 }],
      swipe_right: [{ x: 0.22, y: 0.5 }, { x: 0.78, y: 0.5 }],
    };
    if (action === "screenshot") {
      pullFrame();
      return;
    }
    if (action === "home") {
      await sendHID({ type: "hardware_home", phase: "hardware_home", reason: "quick_home" });
      return;
    }
    if (action === "tap_center") {
      await sendHID({ type: "tap", phase: "tap", x: 0.5, y: 0.5, gesture_id: `tap-${Date.now()}`, reason: "quick_tap" });
      return;
    }
    if (action === "long_center") {
      const gestureId = `long-${Date.now()}`;
      await sendHID({ type: "gesture_down", phase: "gesture_down", x: 0.5, y: 0.5, gesture_id: gestureId, reason: "quick_long" });
      await new Promise((resolve) => setTimeout(resolve, 750));
      await sendHID({ type: "gesture_up", phase: "gesture_up", x: 0.5, y: 0.5, gesture_id: gestureId, reason: "quick_long" });
      return;
    }
    if (map[action]) await sendSwipe(map[action][0], map[action][1]);
  }

  async function runDefaultLua() {
    const lua = [
      'reportStep("usb_web:start")',
      "sleep(300)",
      'reportStep("usb_web:done")',
    ].join("\n");
    try {
      native("runNativeLua", { lua, name: "USB Web quick script" });
      toast("Đã gửi và chạy Lua test qua USB");
    } catch (error) {
      toast(`Lua USB lỗi: ${error?.message || error}`);
    }
  }

  function bindHeader() {
    if (els.apiInput) {
      els.apiInput.value = "USB native bridge";
      els.apiInput.readOnly = true;
      els.apiInput.title = "USB mode dùng native bridge, không gọi HTTP screenshot/HID.";
    }
    $("sync-live-button")?.addEventListener("click", () => native("listDevices"));
    $("connect-batch-button")?.addEventListener("click", () => {
      const target = selectedDevice();
      if (target) connectDevice(target.id);
      else native("listDevices");
    });
    $("disconnect-all-button")?.addEventListener("click", () => disconnectDevice(state.selectedDeviceId));
    $("sync-toggle-button")?.addEventListener("click", () => {
      state.syncEnabled = !state.syncEnabled;
      $("sync-toggle-button").textContent = state.syncEnabled ? "Sync ON" : "Sync OFF";
      renderCards();
    });
    $("select-slaves-button")?.addEventListener("click", () => {
      state.devices.forEach((device) => {
        if (device.id !== state.selectedDeviceId) state.slaveIds.add(device.id);
      });
      renderCards();
    });
    $("clear-slaves-button")?.addEventListener("click", () => {
      state.slaveIds.clear();
      renderCards();
    });
    $("bulk-home-button")?.addEventListener("click", () => sendQuickAction("home"));
    $("bulk-disconnect-button")?.addEventListener("click", () => disconnectDevice(state.selectedDeviceId));
    $("bulk-clear-button")?.addEventListener("click", () => {
      state.selectedIds.clear();
      renderCards();
    });
    $("bulk-install-workflow-button")?.addEventListener("click", runDefaultLua);
    $("bulk-workflow-button")?.addEventListener("click", runDefaultLua);
  }

  window.HIDProbeUSB = {
    onDevices(devices) {
      const nextDevices = (Array.isArray(devices) ? devices : []).map(normalizeDevice);
      const nextSignature = deviceSignature(nextDevices);
      const devicesChanged = nextSignature !== state.devicesSignature;
      state.devices = nextDevices;
      state.devicesSignature = nextSignature;
      let needsRender = devicesChanged || !els.grid?.querySelector(".phone-card[data-device-id]");
      if (!state.devices.length) {
        needsRender = needsRender || !!state.selectedDeviceId || state.live;
        state.selectedDeviceId = "";
        state.live = false;
        stopLiveFrames();
      } else if (!state.selectedDeviceId || !state.devices.some((device) => device.id === state.selectedDeviceId)) {
        needsRender = true;
        state.selectedDeviceId = state.devices[0].id;
        state.selectedIds.add(state.selectedDeviceId);
        native("connectDevice", { device_id: state.selectedDeviceId });
        state.live = true;
        startLiveFrames();
      }
      if (needsRender) renderCards();
      else {
        setStats();
        updateMetrics();
      }
    },
    onTunnel(status) {
      state.tunnelStatus = String(status || "USB tunnel: ready");
      if (state.tunnelStatus === state.lastTunnelStatus) {
        updateMetrics();
        return;
      }
      state.lastTunnelStatus = state.tunnelStatus;
      if (/active|listening|ready|forward/i.test(state.tunnelStatus)) {
        state.live = !!selectedDevice();
        if (state.live) startLiveFrames();
      }
      updateCardClasses();
      updateMetrics();
    },
    onNativeFrame(dataBase64) {
      renderNativeFrame(dataBase64);
    },
    onLog(message) {
      pushLog(String(message || ""));
    },
  };

  function boot() {
    injectStyle();
    bindHeader();
    installChromeGuard();
    setStats();
    renderSidebar();
    renderCards();
    forceUSBChrome();
    native("listDevices");
    toast("USB local web UI đã nạp giao diện web gốc + adapter");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
