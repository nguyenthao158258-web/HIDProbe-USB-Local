"use strict";

(function attachWorkflowBlocks(global) {
  const SchemaVersion = "1.5";
  const AcceptedSchemaVersions = new Set(["1.0", "1.1", "1.2", "1.3", "1.4", "1.5"]);
  const ImageSearchModeValues = new Set(["full_screen", "prefer_regions_then_full", "regions_only"]);
  const ImageSearchDefaults = { image_search_mode: "full_screen", image_search_regions: [] };
  const ConditionalImageSearchDefaults = {
    condition_image_search_mode: "full_screen",
    condition_image_search_regions: [],
    target_image_search_mode: "full_screen",
    target_image_search_regions: [],
  };
  const BlockTypes = [
    { type: "tap", label: "👆 Nhấn", defaults: { x: 0.5, y: 0.5 } },
    { type: "long_press", label: "✋ Nhấn giữ", defaults: { x: 0.5, y: 0.5, hold_ms: 800 } },
    { type: "swipe", label: "↗️ Vuốt", defaults: { preset: "custom", from_x: 0.5, from_y: 0.7, to_x: 0.5, to_y: 0.3, duration_ms: 300, steps: 10 } },
    { type: "hardware_home", label: "🏠 Về Home", defaults: { reason: "workflow_home" } },
    { type: "wait", label: "⏱ Chờ", defaults: { ms: 1000 } },
    { type: "open_app", label: "📱 Mở ứng dụng", defaults: { app_name: "", bundle_id: "", url_scheme: "" } },
    { type: "open_url", label: "🌐 Mở URL", defaults: { url: "thuypp.fun" } },
    { type: "extok_tiktok_job", label: "🔗 Extok TikTok job", defaults: { api_key: "", unique_username: "", job_type: "follow", skip_type: "", lang: "vi", action_timeout_ms: 20000, complete_after_action: true, skip_unsupported: true, follow_texts: "Follow|Theo dõi|Follow back", note: "" } },
    { type: "kill_app", label: "🛑 Đóng app", defaults: { app_name: "", bundle_id: "" } },
    { type: "screenshot", label: "📸 Chụp màn hình", defaults: { save_as: "screenshot" } },
    { type: "input_text", label: "⌨️ Nhập chữ", defaults: { input_text: "", submit_after: false, delay_ms: 300 } },
    { type: "wait_text", label: "🔎 Chờ chữ", defaults: { text: "", timeout_ms: 300000, interval_ms: 1000, on_timeout: "fail", telegram_message: "Không thấy chữ sau 5 phút", telegram_chat_id: "", telegram_bot_token: "" } },
    { type: "tap_text", label: "👆 Nhấn đúng chữ", defaults: { text: "", timeout_ms: 300000, interval_ms: 1000, on_timeout: "fail", telegram_message: "Không thấy chữ để nhấn sau 5 phút", telegram_chat_id: "", telegram_bot_token: "" } },
    { type: "wait_image", label: "🖼 Chờ ảnh", defaults: { image: "target.png", timeout_ms: 300000, interval_ms: 1000, threshold: 0.95, on_timeout: "fail", telegram_message: "Không thấy ảnh sau 5 phút", telegram_chat_id: "", telegram_bot_token: "", ...ImageSearchDefaults } },
    { type: "tap_image", label: "👆 Nhấn ảnh", defaults: { image: "target.png", timeout_ms: 300000, interval_ms: 1000, threshold: 0.95, on_timeout: "fail", telegram_message: "Không thấy ảnh để nhấn sau 5 phút", telegram_chat_id: "", telegram_bot_token: "", ...ImageSearchDefaults } },
    { type: "tap_image_optional", label: "👆 Nhấn ảnh nếu thấy", defaults: { image: "target.png", timeout_ms: 3000, interval_ms: 500, threshold: 0.95, ...ImageSearchDefaults } },
    { type: "tap_if_image", label: "👆 Nếu ảnh thì nhấn", defaults: { condition_image: "condition.png", condition_images: "", action_mode: "coordinate", target_image: "target.png", x: 0.5, y: 0.5, timeout_ms: 3000, interval_ms: 500, threshold: 0.95, target_timeout_ms: 3000, target_threshold: 0.95, ...ConditionalImageSearchDefaults } },
    { type: "tap_image_state_pair", label: "👆 2 trạng thái ảnh", defaults: { first_image: "follow.png", first_action_mode: "self", first_target_image: "follow_tap.png", first_x: 0.5, first_y: 0.5, second_image: "message.png", second_action_mode: "image", second_target_image: "back.png", second_x: 0.5, second_y: 0.5, timeout_ms: 5000, interval_ms: 500, threshold: 0.95, first_target_timeout_ms: 3000, first_target_threshold: 0.95, second_threshold: 0.95, check_second_after_first: true, after_first_wait_ms: 1000, after_first_second_timeout_ms: 5000, second_target_timeout_ms: 3000, second_target_threshold: 0.95, on_timeout: "fail" } },
    { type: "loop", label: "🔁 Lặp lại", defaults: { iterations: 3, repeat_from_step: 0, repeat_to_step: 0 }, body: true },
    { type: "if_else", label: "🔀 Nếu / thì", defaults: { condition_type: "var_exists", variable: "", value: "" } },
    { type: "set_variable", label: "🏷 Gán biến", defaults: { name: "value", value: "" } },
    { type: "notify", label: "🔔 Báo trạng thái", defaults: { message: "Thông báo", level: "info" } },
  ];

  const BlockTypeMap = new Map(BlockTypes.map((block) => [block.type, block]));
  const ScriptOnlyBlockTypes = new Set(["open_url", "extok_tiktok_job", "kill_app", "input_text", "wait_text", "tap_text", "wait_image", "tap_image", "tap_image_optional", "tap_if_image", "tap_image_state_pair"]);

  function uuid() {
    if (global.crypto?.randomUUID) return global.crypto.randomUUID();
    return `wf-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function parseNumber(value) {
    if (typeof value === "number") return value;
    const text = String(value ?? "").trim();
    const normalized = text && !text.includes(".") && text.includes(",")
      ? text.replace(",", ".")
      : text;
    return Number(normalized);
  }

  function clamp01(value, fallback = 0.5) {
    const number = parseNumber(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(Math.max(number, 0), 1);
  }

  function asPositiveInt(value, fallback, min = 1, max = 600000) {
    const number = Math.round(parseNumber(value));
    if (!Number.isFinite(number)) return fallback;
    return Math.min(Math.max(number, min), max);
  }

  function validUnitNumber(value) {
    const number = parseNumber(value);
    return Number.isFinite(number) && number > 0 && number <= 1;
  }

  function truthy(value) {
    if (typeof value === "boolean") return value;
    const text = String(value ?? "").trim().toLowerCase();
    return ["1", "true", "yes", "on"].includes(text);
  }

  function imageListFromValue(value) {
    if (Array.isArray(value)) {
      return value.map((item) => String(item || "").trim()).filter(Boolean);
    }
    return String(value || "")
      .split(/[\n,|]+/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  function imageSearchRegionsFromValue(value) {
    if (Array.isArray(value)) return value;
    if (typeof value === "string" && value.trim()) {
      try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_error) {
        return [];
      }
    }
    return [];
  }

  function validateImageSearchParams(params, prefix, blockId, errors) {
    const modeKey = `${prefix}_search_mode`;
    const regionsKey = `${prefix}_search_regions`;
    const mode = String(params[modeKey] || "full_screen").trim().toLowerCase();
    if (!ImageSearchModeValues.has(mode)) {
      errors.push(`${blockId}: ${modeKey} phải là full_screen, prefer_regions_then_full hoặc regions_only`);
      return;
    }
    const regions = imageSearchRegionsFromValue(params[regionsKey]);
    if (mode !== "full_screen" && !regions.length) {
      errors.push(`${blockId}: ${regionsKey} cần ít nhất 1 điểm/ROI khi không quét full screen`);
    }
    regions.forEach((region, index) => {
      const label = `${blockId}: ${regionsKey}[${index}]`;
      const type = String(region?.type || "point").trim().toLowerCase();
      const x = parseNumber(region?.x);
      const y = parseNumber(region?.y);
      if (!["point", "roi"].includes(type)) errors.push(`${label}.type phải là point hoặc roi`);
      if (!Number.isFinite(x) || x < 0 || x > 1) errors.push(`${label}.x phải trong 0..1`);
      if (!Number.isFinite(y) || y < 0 || y > 1) errors.push(`${label}.y phải trong 0..1`);
      if (type === "roi") {
        const width = parseNumber(region?.width);
        const height = parseNumber(region?.height);
        if (!Number.isFinite(width) || width <= 0 || width > 1) errors.push(`${label}.width phải trong 0..1`);
        if (!Number.isFinite(height) || height <= 0 || height > 1) errors.push(`${label}.height phải trong 0..1`);
      } else {
        const radius = parseNumber(region?.radius ?? 0.16);
        if (!Number.isFinite(radius) || radius <= 0 || radius > 1) errors.push(`${label}.radius phải trong 0..1`);
      }
    });
  }

  function shouldRequireElementGuard(params = {}) {
    const source = String(params.element_source || "").trim().toLowerCase();
    const reason = String(params.reason || "").trim().toLowerCase();
    return truthy(params.strict_element)
      || source.includes("catalog")
      || reason.startsWith("catalog:");
  }

  function defaultParams(type) {
    return JSON.parse(JSON.stringify({ on_error: "fail", ...(BlockTypeMap.get(type)?.defaults || {}) }));
  }

  function createBlock(type, overrides = {}) {
    const spec = BlockTypeMap.get(type);
    if (!spec) throw new Error(`Unknown block type: ${type}`);
    const id = overrides.id || `block-${uuid().slice(0, 8)}`;
    const block = {
      id,
      type,
      position: overrides.position || { x: 120, y: 80 },
      params: { ...defaultParams(type), ...(overrides.params || {}) },
    };
    if (spec.body) block.body = Array.isArray(overrides.body) ? overrides.body : [];
    return block;
  }

  function createWorkflow(name = "Workflow mới") {
    const now = new Date().toISOString();
    return {
      schema_version: SchemaVersion,
      id: uuid(),
      name,
      description: "",
      created_at: now,
      updated_at: now,
      variables: {},
      assets: [],
      blocks: [],
      connections: [],
    };
  }

  function normalizeAsset(rawAsset, index = 0) {
    const path = String(rawAsset?.path || rawAsset?.name || `asset-${index + 1}.png`).trim();
    const asset = {
      id: String(rawAsset?.id || `asset-${index + 1}`).trim(),
      path,
      name: String(rawAsset?.name || path).trim(),
      mime: String(rawAsset?.mime || "image/png").trim(),
      size: Number(rawAsset?.size || 0) || 0,
      sha256: String(rawAsset?.sha256 || "").trim().toLowerCase(),
      data_base64: String(rawAsset?.data_base64 || ""),
      preview_data_url: String(rawAsset?.preview_data_url || ""),
      source: String(rawAsset?.source || "import").trim(),
      created_at: rawAsset?.created_at || new Date().toISOString(),
    };
    if (Number.isFinite(Number(rawAsset?.width))) asset.width = Number(rawAsset.width);
    if (Number.isFinite(Number(rawAsset?.height))) asset.height = Number(rawAsset.height);
    if (Number.isFinite(Number(rawAsset?.source_width))) asset.source_width = Number(rawAsset.source_width);
    if (Number.isFinite(Number(rawAsset?.source_height))) asset.source_height = Number(rawAsset.source_height);
    if (Array.isArray(rawAsset?.neighbor_texts)) asset.neighbor_texts = rawAsset.neighbor_texts.map((item) => String(item || "").trim()).filter(Boolean);
    if (rawAsset?.crop_norm && typeof rawAsset.crop_norm === "object") {
      asset.crop_norm = {
        x: Number(rawAsset.crop_norm.x) || 0,
        y: Number(rawAsset.crop_norm.y) || 0,
        width: Number(rawAsset.crop_norm.width) || 0,
        height: Number(rawAsset.crop_norm.height) || 0,
        center_x: Number(rawAsset.crop_norm.center_x) || 0,
        center_y: Number(rawAsset.crop_norm.center_y) || 0,
      };
    }
    return asset;
  }

  function normalizeBlock(rawBlock, index = 0) {
    const type = String(rawBlock?.type || "").trim();
    if (!BlockTypeMap.has(type)) throw new Error(`Block #${index + 1} unknown type: ${type || "<empty>"}`);
    const block = createBlock(type, {
      id: String(rawBlock?.id || `block-${index + 1}`).trim(),
      position: rawBlock?.position || { x: 120, y: 80 + index * 90 },
      params: rawBlock?.params || {},
      body: Array.isArray(rawBlock?.body) ? rawBlock.body.map(normalizeBlock) : [],
    });
    return block;
  }

  function normalizeWorkflow(rawWorkflow, options = {}) {
    const now = new Date().toISOString();
    const schemaVersion = AcceptedSchemaVersions.has(String(rawWorkflow?.schema_version || "")) ? SchemaVersion : SchemaVersion;
    const workflow = {
      schema_version: schemaVersion,
      id: String(rawWorkflow?.id || uuid()),
      name: String(rawWorkflow?.name || "Workflow chưa đặt tên").trim() || "Workflow chưa đặt tên",
      description: String(rawWorkflow?.description || ""),
      created_at: rawWorkflow?.created_at || now,
      updated_at: now,
      authoring: typeof rawWorkflow?.authoring === "object" && rawWorkflow.authoring ? { ...rawWorkflow.authoring } : {},
      api_profile: String(rawWorkflow?.api_profile || rawWorkflow?.apiProfile || "").trim(),
      raw_lua: String(rawWorkflow?.raw_lua || rawWorkflow?.rawLua || ""),
      raw_lua_filename: String(rawWorkflow?.raw_lua_filename || rawWorkflow?.rawLuaFilename || ""),
      test_metadata: typeof rawWorkflow?.test_metadata === "object" && rawWorkflow.test_metadata ? { ...rawWorkflow.test_metadata } : null,
      variables: typeof rawWorkflow?.variables === "object" && rawWorkflow.variables ? rawWorkflow.variables : {},
      assets: Array.isArray(rawWorkflow?.assets) ? rawWorkflow.assets.map(normalizeAsset) : [],
      blocks: Array.isArray(rawWorkflow?.blocks) ? rawWorkflow.blocks.map(normalizeBlock) : [],
      connections: Array.isArray(rawWorkflow?.connections) ? rawWorkflow.connections.map((connection) => ({
        from: String(connection?.from || ""),
        to: String(connection?.to || ""),
        port: String(connection?.port || "next"),
      })) : [],
    };
    if (!workflow.api_profile) workflow.api_profile = workflow.raw_lua.trim() ? "ioscontrol-v1" : "hidprobe-v1";
    if (options.validate !== false) validateWorkflow(workflow);
    return workflow;
  }

  function validateBlockParams(block, errors) {
    const params = block.params || {};
    const onError = String(params.on_error || "fail").trim().toLowerCase();
    if (!["fail", "continue"].includes(onError)) errors.push(`${block.id}: on_error phải là fail hoặc continue`);
    if (block.type === "tap") {
      if (!Number.isFinite(parseNumber(params.x)) || parseNumber(params.x) < 0 || parseNumber(params.x) > 1) errors.push(`${block.id}: x phải trong 0..1`);
      if (!Number.isFinite(parseNumber(params.y)) || parseNumber(params.y) < 0 || parseNumber(params.y) > 1) errors.push(`${block.id}: y phải trong 0..1`);
    }
    if (block.type === "long_press" && asPositiveInt(params.hold_ms, 0, 0) <= 0) errors.push(`${block.id}: hold_ms không hợp lệ`);
    if (block.type === "long_press") {
      if (!Number.isFinite(parseNumber(params.x)) || parseNumber(params.x) < 0 || parseNumber(params.x) > 1) errors.push(`${block.id}: x phải trong 0..1`);
      if (!Number.isFinite(parseNumber(params.y)) || parseNumber(params.y) < 0 || parseNumber(params.y) > 1) errors.push(`${block.id}: y phải trong 0..1`);
    }
    if (block.type === "swipe") {
      const points = swipePoints(params);
      for (const [label, point] of [["from", points.from], ["to", points.to]]) {
        if (!Number.isFinite(parseNumber(point.x)) || parseNumber(point.x) < 0 || parseNumber(point.x) > 1) errors.push(`${block.id}: ${label}.x phải trong 0..1`);
        if (!Number.isFinite(parseNumber(point.y)) || parseNumber(point.y) < 0 || parseNumber(point.y) > 1) errors.push(`${block.id}: ${label}.y phải trong 0..1`);
      }
    }
    if (block.type === "wait" && asPositiveInt(params.ms, 0, 0) <= 0) errors.push(`${block.id}: ms không hợp lệ`);
    if (block.type === "open_url" && !String(params.url || "").trim()) errors.push(`${block.id}: thiếu URL cần mở`);
    if (block.type === "extok_tiktok_job") {
      if (!String(params.api_key || "").trim()) errors.push(`${block.id}: thiếu Extok API key`);
      if (!String(params.unique_username || "").trim()) errors.push(`${block.id}: thiếu unique_username TikTok`);
      const jobType = String(params.job_type || "follow").trim().toLowerCase();
      if (jobType && !["follow", "like", "comment"].includes(jobType)) errors.push(`${block.id}: job_type phải là follow, like hoặc comment`);
      if (asPositiveInt(params.action_timeout_ms, 0, 0, 180000) <= 0) errors.push(`${block.id}: action_timeout_ms không hợp lệ`);
    }
    if (block.type === "kill_app" && !String(params.bundle_id || "").trim()) errors.push(`${block.id}: thiếu bundle_id để đóng app`);
    if (block.type === "input_text") {
      if (!String(params.input_text ?? params.text ?? "").trim()) errors.push(`${block.id}: thiếu chữ cần nhập`);
      if (asPositiveInt(params.delay_ms, 300, 0, 60000) < 0) errors.push(`${block.id}: delay_ms không hợp lệ`);
    }
    if (["wait_text", "tap_text"].includes(block.type)) {
      if (!String(params.text || "").trim()) errors.push(`${block.id}: thiếu chữ cần tìm`);
      if (asPositiveInt(params.timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: timeout_ms không hợp lệ`);
      if (asPositiveInt(params.interval_ms, 0, 0, 60000) <= 0) errors.push(`${block.id}: interval_ms không hợp lệ`);
    }
    if (["wait_image", "tap_image", "tap_image_optional"].includes(block.type)) {
      if (!String(params.image || "").trim()) errors.push(`${block.id}: thiếu tên ảnh cần tìm`);
      if (asPositiveInt(params.timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: timeout_ms không hợp lệ`);
      if (asPositiveInt(params.interval_ms, 0, 0, 60000) <= 0) errors.push(`${block.id}: interval_ms không hợp lệ`);
      if (!validUnitNumber(params.threshold)) errors.push(`${block.id}: threshold phải trong 0..1`);
      validateImageSearchParams(params, "image", block.id, errors);
    }
    if (block.type === "tap_if_image") {
      if (!String(params.condition_image || "").trim() && !imageListFromValue(params.condition_images).length) errors.push(`${block.id}: thiếu ảnh điều kiện`);
      if (asPositiveInt(params.timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: timeout_ms không hợp lệ`);
      if (asPositiveInt(params.interval_ms, 0, 0, 60000) <= 0) errors.push(`${block.id}: interval_ms không hợp lệ`);
      if (!validUnitNumber(params.threshold)) errors.push(`${block.id}: threshold phải trong 0..1`);
      validateImageSearchParams(params, "condition_image", block.id, errors);
      const mode = String(params.action_mode || "coordinate").trim().toLowerCase();
      if (!["coordinate", "image"].includes(mode)) errors.push(`${block.id}: action_mode phải là coordinate hoặc image`);
      if (mode === "image") {
        if (!String(params.target_image || "").trim()) errors.push(`${block.id}: thiếu ảnh cần nhấn`);
        if (!validUnitNumber(params.target_threshold)) errors.push(`${block.id}: target_threshold phải trong 0..1`);
        if (asPositiveInt(params.target_timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: target_timeout_ms không hợp lệ`);
        validateImageSearchParams(params, "target_image", block.id, errors);
      } else {
        if (!Number.isFinite(parseNumber(params.x)) || parseNumber(params.x) < 0 || parseNumber(params.x) > 1) errors.push(`${block.id}: x phải trong 0..1`);
        if (!Number.isFinite(parseNumber(params.y)) || parseNumber(params.y) < 0 || parseNumber(params.y) > 1) errors.push(`${block.id}: y phải trong 0..1`);
      }
    }
    if (block.type === "tap_image_state_pair") {
      if (!String(params.first_image || "").trim()) errors.push(`${block.id}: thiếu ảnh trạng thái 1`);
      if (!String(params.second_image || "").trim()) errors.push(`${block.id}: thiếu ảnh trạng thái 2`);
      if (asPositiveInt(params.timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: timeout_ms không hợp lệ`);
      if (asPositiveInt(params.interval_ms, 0, 0, 60000) <= 0) errors.push(`${block.id}: interval_ms không hợp lệ`);
      if (asPositiveInt(params.after_first_wait_ms, 0, 0, 60000) < 0) errors.push(`${block.id}: after_first_wait_ms không hợp lệ`);
      if (asPositiveInt(params.after_first_second_timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: after_first_second_timeout_ms không hợp lệ`);
      if (!validUnitNumber(params.threshold)) errors.push(`${block.id}: threshold phải trong 0..1`);
      if (!validUnitNumber(params.second_threshold)) errors.push(`${block.id}: second_threshold phải trong 0..1`);
      const firstMode = String(params.first_action_mode || "self").trim().toLowerCase();
      if (!["self", "coordinate", "image"].includes(firstMode)) errors.push(`${block.id}: first_action_mode phải là self, coordinate hoặc image`);
      if (firstMode === "image") {
        if (!String(params.first_target_image || "").trim()) errors.push(`${block.id}: thiếu ảnh cần nhấn cho trạng thái 1`);
        if (!validUnitNumber(params.first_target_threshold)) errors.push(`${block.id}: first_target_threshold phải trong 0..1`);
        if (asPositiveInt(params.first_target_timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: first_target_timeout_ms không hợp lệ`);
      } else if (firstMode === "coordinate") {
        if (!Number.isFinite(parseNumber(params.first_x)) || parseNumber(params.first_x) < 0 || parseNumber(params.first_x) > 1) errors.push(`${block.id}: first_x phải trong 0..1`);
        if (!Number.isFinite(parseNumber(params.first_y)) || parseNumber(params.first_y) < 0 || parseNumber(params.first_y) > 1) errors.push(`${block.id}: first_y phải trong 0..1`);
      }
      const mode = String(params.second_action_mode || "coordinate").trim().toLowerCase();
      if (!["coordinate", "image"].includes(mode)) errors.push(`${block.id}: second_action_mode phải là coordinate hoặc image`);
      if (mode === "image") {
        if (!String(params.second_target_image || "").trim()) errors.push(`${block.id}: thiếu ảnh cần nhấn cho trạng thái 2`);
        if (!validUnitNumber(params.second_target_threshold)) errors.push(`${block.id}: second_target_threshold phải trong 0..1`);
        if (asPositiveInt(params.second_target_timeout_ms, 0, 0, 3600000) <= 0) errors.push(`${block.id}: second_target_timeout_ms không hợp lệ`);
      } else {
        if (!Number.isFinite(parseNumber(params.second_x)) || parseNumber(params.second_x) < 0 || parseNumber(params.second_x) > 1) errors.push(`${block.id}: second_x phải trong 0..1`);
        if (!Number.isFinite(parseNumber(params.second_y)) || parseNumber(params.second_y) < 0 || parseNumber(params.second_y) > 1) errors.push(`${block.id}: second_y phải trong 0..1`);
      }
    }
    if (block.type === "loop") {
      if (asPositiveInt(params.iterations, 0, 0, 10000) <= 0) errors.push(`${block.id}: iterations không hợp lệ`);
      const repeatFrom = asPositiveInt(params.repeat_from_step, 0, 0, 10000);
      const repeatTo = asPositiveInt(params.repeat_to_step, 0, 0, 10000);
      if (repeatFrom > 0 && repeatTo > 0 && repeatFrom > repeatTo) errors.push(`${block.id}: Lặp từ bước phải <= Đến bước`);
      for (const child of block.body || []) validateBlockParams(child, errors);
    }
    if (block.type === "set_variable" && !String(params.name || "").trim()) errors.push(`${block.id}: thiếu tên biến`);
    if (block.type === "screenshot" && !String(params.save_as || "").trim()) errors.push(`${block.id}: thiếu save_as`);
  }

  function validateWorkflow(workflow) {
    const errors = [];
    if (!AcceptedSchemaVersions.has(String(workflow.schema_version))) errors.push(`schema_version phải là ${SchemaVersion}`);
    if (!workflow.name || typeof workflow.name !== "string") errors.push("Thiếu workflow.name");
    if (!Array.isArray(workflow.blocks)) errors.push("workflow.blocks phải là array");
    if (!Array.isArray(workflow.connections)) errors.push("workflow.connections phải là array");
    if (!Array.isArray(workflow.assets)) errors.push("workflow.assets phải là array");
    for (const asset of workflow.assets || []) {
      const path = String(asset?.path || "").trim();
      if (!path) errors.push("Có ảnh mẫu thiếu path");
      if (path.includes("..") || path.startsWith("/") || path.startsWith("\\")) errors.push(`Ảnh mẫu path không an toàn: ${path}`);
      if (asset?.data_base64 && !String(asset.sha256 || "").trim()) errors.push(`Ảnh mẫu thiếu sha256: ${path}`);
    }
    const ids = new Set();
    for (const block of workflow.blocks || []) {
      if (!block.id) errors.push("Có block thiếu id");
      if (ids.has(block.id)) errors.push(`Trùng block id: ${block.id}`);
      ids.add(block.id);
      if (!BlockTypeMap.has(block.type)) errors.push(`Unknown block type: ${block.type}`);
      if (!block.params || typeof block.params !== "object") errors.push(`${block.id}: thiếu params`);
      validateBlockParams(block, errors);
    }
    for (const connection of workflow.connections || []) {
      if (!ids.has(connection.from)) errors.push(`Connection from không tồn tại: ${connection.from}`);
      if (!ids.has(connection.to)) errors.push(`Connection to không tồn tại: ${connection.to}`);
    }
    if (hasNonLoopCycle(workflow)) errors.push("Workflow có cycle ngoài Loop");
    if (errors.length) {
      const error = new Error(errors.join("; "));
      error.validationErrors = errors;
      throw error;
    }
    return true;
  }

  function hasNonLoopCycle(workflow) {
    const graph = new Map();
    for (const block of workflow.blocks || []) graph.set(block.id, []);
    for (const connection of workflow.connections || []) {
      if (graph.has(connection.from)) graph.get(connection.from).push(connection.to);
    }
    const visiting = new Set();
    const visited = new Set();
    function visit(id) {
      if (visiting.has(id)) return true;
      if (visited.has(id)) return false;
      visiting.add(id);
      for (const next of graph.get(id) || []) {
        if (visit(next)) return true;
      }
      visiting.delete(id);
      visited.add(id);
      return false;
    }
    for (const id of graph.keys()) {
      if (visit(id)) return true;
    }
    return false;
  }

  function orderedBlocks(workflow) {
    const blocks = workflow.blocks || [];
    if (!blocks.length) return [];
    const byId = new Map(blocks.map((block) => [block.id, block]));
    const incoming = new Set((workflow.connections || []).map((connection) => connection.to));
    const start = blocks.find((block) => !incoming.has(block.id)) || blocks[0];
    const ordered = [];
    const seen = new Set();
    let current = start;
    while (current && !seen.has(current.id)) {
      ordered.push(current);
      seen.add(current.id);
      const nextConnection = (workflow.connections || []).find((connection) => connection.from === current.id && (!connection.port || connection.port === "next"));
      current = nextConnection ? byId.get(nextConnection.to) : null;
    }
    for (const block of blocks) {
      if (!seen.has(block.id)) ordered.push(block);
    }
    return ordered;
  }

  function loopRepeatRange(block, blockIndex, ordered = []) {
    if (!block || block.type !== "loop") return null;
    const params = block.params || {};
    const startStep = asPositiveInt(params.repeat_from_step, 0, 0, 10000);
    if (startStep <= 0) return null;
    const loopIndex = Math.max(0, Number(blockIndex) || 0);
    const rawEndStep = asPositiveInt(params.repeat_to_step, 0, 0, 10000);
    const endStep = rawEndStep > 0 ? Math.min(rawEndStep, loopIndex) : loopIndex;
    const startIndex = Math.max(0, Math.min(startStep - 1, endStep));
    const endIndex = Math.max(startIndex, endStep);
    if (endIndex <= startIndex) return null;
    const blocks = ordered.slice(startIndex, endIndex).filter((item) => item && item.id !== block.id);
    if (!blocks.length) return null;
    return {
      start_step: startIndex + 1,
      end_step: endIndex,
      start_index: startIndex,
      end_index: endIndex,
      blocks,
    };
  }

  function loopConsumedBlockIds(ordered = []) {
    const consumed = new Set();
    ordered.forEach((block, index) => {
      const range = loopRepeatRange(block, index, ordered);
      if (!range) return;
      for (const child of range.blocks) {
        if (child?.id) consumed.add(child.id);
      }
    });
    return consumed;
  }

  function swipePoints(params = {}) {
    const preset = String(params.preset || "up");
    const duration_ms = asPositiveInt(params.duration_ms, 300, 50, 5000);
    const steps = asPositiveInt(params.steps, 10, 2, 120);
    const hasExplicit = ["from_x", "from_y", "to_x", "to_y"].some((key) => params[key] !== undefined && params[key] !== "");
    if (preset === "custom" || hasExplicit) {
      return {
        from: { x: clamp01(params.from_x, 0.5), y: clamp01(params.from_y, 0.7) },
        to: { x: clamp01(params.to_x, 0.5), y: clamp01(params.to_y, 0.3) },
        duration_ms,
        steps,
      };
    }
    const presets = {
      up: { from: { x: 0.5, y: 0.7 }, to: { x: 0.5, y: 0.3 } },
      down: { from: { x: 0.5, y: 0.3 }, to: { x: 0.5, y: 0.7 } },
      left: { from: { x: 0.7, y: 0.5 }, to: { x: 0.3, y: 0.5 } },
      right: { from: { x: 0.3, y: 0.5 }, to: { x: 0.7, y: 0.5 } },
      bottom_up: { from: { x: 0.5, y: 0.99 }, to: { x: 0.5, y: 0.7 } },
    };
    const selected = presets[preset] || {
      from: { x: clamp01(params.from_x, 0.5), y: clamp01(params.from_y, 0.7) },
      to: { x: clamp01(params.to_x, 0.5), y: clamp01(params.to_y, 0.3) },
    };
    return { ...selected, duration_ms, steps };
  }

  function stableValue(value) {
    if (Array.isArray(value)) return value.map(stableValue);
    if (value && typeof value === "object") {
      return Object.keys(value).sort().reduce((out, key) => {
        if (["test_metadata", "authoring", "created_at", "updated_at"].includes(key)) return out;
        out[key] = stableValue(value[key]);
        return out;
      }, {});
    }
    return value;
  }

  function stableStringify(value) {
    return JSON.stringify(stableValue(value));
  }

  function workflowStableHash(workflow) {
    const normalized = normalizeWorkflow(workflow, { validate: false });
    const payload = stableStringify({
      schema_version: normalized.schema_version,
      variables: normalized.variables,
      assets: normalized.assets.map((asset) => ({
        path: asset.path,
        size: asset.size,
        sha256: asset.sha256,
      })),
      api_profile: normalized.api_profile,
      raw_lua: normalized.raw_lua,
      raw_lua_filename: normalized.raw_lua_filename,
      blocks: normalized.blocks,
      connections: normalized.connections,
    });
    let hash = 2166136261;
    for (let index = 0; index < payload.length; index += 1) {
      hash ^= payload.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `fnv1a-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  function commandFromBlock(block) {
    const params = block.params || {};
    if (block.type === "tap") {
      const command = { type: "tap_at_norm", phase: "tap_at_norm", x: clamp01(params.x), y: clamp01(params.y) };
      const passthroughKeys = [
        "reason",
        "element_id",
        "element_label",
        "element_value",
        "element_role",
        "element_source",
        "element_center_x",
        "element_center_y",
        "match_strategy",
        "path",
        "wda_key",
        "strict_element",
        "expected_app",
        "expected_screen",
      ];
      for (const key of passthroughKeys) {
        if (params[key] === undefined || params[key] === null || params[key] === "") continue;
        command[key] = params[key];
      }
      if (shouldRequireElementGuard(params)) {
        command.strict_element = true;
        if (!command.element_source && String(params.reason || "").trim().toLowerCase().startsWith("catalog:")) {
          command.element_source = "catalog";
        }
      }
      return command;
    }
    if (block.type === "long_press") return { type: "long_press_at_norm", phase: "long_press_at_norm", x: clamp01(params.x), y: clamp01(params.y), hold_ms: asPositiveInt(params.hold_ms, 800, 100, 10000) };
    if (block.type === "swipe") return { type: "swipe_line", phase: "swipe_line", ...swipePoints(params) };
    if (block.type === "hardware_home") return { type: "hardware_home", phase: "hardware_home", reason: params.reason || "workflow_home" };
    if (block.type === "open_app") return { type: "hardware_home", phase: "hardware_home", reason: params.bundle_id || params.url_scheme || "open_app_mvp_hardware_home" };
    return null;
  }

  function isScriptOnlyBlock(type) {
    return ScriptOnlyBlockTypes.has(String(type || ""));
  }

  global.HidWorkflowBlocks = {
    SchemaVersion,
    AcceptedSchemaVersions,
    BlockTypes,
    BlockTypeMap,
    createWorkflow,
    createBlock,
    normalizeWorkflow,
    validateWorkflow,
    orderedBlocks,
    loopRepeatRange,
    loopConsumedBlockIds,
    commandFromBlock,
    isScriptOnlyBlock,
    swipePoints,
    workflowStableHash,
    clamp01,
    asPositiveInt,
    uuid,
  };
})(window);
