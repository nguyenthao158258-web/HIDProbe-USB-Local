"use strict";

(function attachBulkActions(global) {
  async function runParallel(targets, action) {
    return Promise.allSettled(targets.map((target) => action(target)));
  }
  global.HidBulkActions = { runParallel };
})(window);
