"use strict";

(function attachTags(global) {
  const Colors = ["#3b82f6", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];
  function normalizeTagName(name) {
    return String(name || "").trim().replace(/\s+/g, " ");
  }
  function tagColor(name) {
    let hash = 0;
    for (const char of normalizeTagName(name).toLowerCase()) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
    return Colors[Math.abs(hash) % Colors.length];
  }
  function allTags(devices) {
    const tags = new Set();
    for (const device of devices) for (const tag of device.tags || []) tags.add(normalizeTagName(tag));
    return Array.from(tags).filter(Boolean).sort((a, b) => a.localeCompare(b, "vi"));
  }
  global.HidTags = { normalizeTagName, tagColor, allTags };
})(window);
