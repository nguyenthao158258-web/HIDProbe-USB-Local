"use strict";

(function attachWorkflowStorage(global) {
  const Keys = {
    workflows: "hidprobe_workflows_v1",
    history: "hidprobe_workflow_history_v1",
    aiSettings: "hidprobe_ai_settings_v1",
  };

  function readJson(key, fallback) {
    try {
      const parsed = JSON.parse(localStorage.getItem(key) || "null");
      return parsed == null ? fallback : parsed;
    } catch (_error) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function listWorkflows() {
    const list = readJson(Keys.workflows, []);
    return Array.isArray(list) ? list : [];
  }

  function saveWorkflow(workflow) {
    const normalized = global.HidWorkflowBlocks.normalizeWorkflow(workflow);
    const list = listWorkflows().filter((item) => item.id !== normalized.id);
    list.unshift(normalized);
    writeJson(Keys.workflows, list.slice(0, 200));
    return normalized;
  }

  function deleteWorkflow(workflowId) {
    writeJson(Keys.workflows, listWorkflows().filter((item) => item.id !== workflowId));
  }

  function getWorkflow(workflowId) {
    return listWorkflows().find((item) => item.id === workflowId) || null;
  }

  function listHistory() {
    const list = readJson(Keys.history, []);
    return Array.isArray(list) ? list : [];
  }

  function addHistory(entry) {
    const list = listHistory();
    list.unshift({
      id: entry.id || global.HidWorkflowBlocks.uuid(),
      workflow_id: entry.workflow_id || "",
      workflow_name: entry.workflow_name || "",
      started_at: entry.started_at || new Date().toISOString(),
      duration_ms: entry.duration_ms || 0,
      devices: entry.devices || [],
      result: entry.result || "unknown",
      log: entry.log || [],
    });
    writeJson(Keys.history, list.slice(0, 50));
  }

  function exportJson(filename, data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function encodeSecret(secret) {
    const text = String(secret || "");
    const salt = "hidprobe-ai-v1";
    let out = "";
    for (let i = 0; i < text.length; i += 1) {
      out += String.fromCharCode(text.charCodeAt(i) ^ salt.charCodeAt(i % salt.length));
    }
    return btoa(unescape(encodeURIComponent(out)));
  }

  function decodeSecret(encoded) {
    if (!encoded) return "";
    try {
      const raw = decodeURIComponent(escape(atob(String(encoded))));
      const salt = "hidprobe-ai-v1";
      let out = "";
      for (let i = 0; i < raw.length; i += 1) {
        out += String.fromCharCode(raw.charCodeAt(i) ^ salt.charCodeAt(i % salt.length));
      }
      return out;
    } catch (_error) {
      return "";
    }
  }

  function loadAiSettings() {
    const parsed = readJson(Keys.aiSettings, {});
    return {
      provider: parsed.provider || "local",
      model: parsed.model || "local-smart-script",
      apiKey: decodeSecret(parsed.apiKeyObfuscated || ""),
      temperature: Number.isFinite(Number(parsed.temperature)) ? Number(parsed.temperature) : 0.3,
      maxTokens: Number.isFinite(Number(parsed.maxTokens)) ? Number(parsed.maxTokens) : 4096,
      promptTemplate: parsed.promptTemplate || "",
      tokenUsage: Number(parsed.tokenUsage || 0) || 0,
    };
  }

  function saveAiSettings(settings) {
    writeJson(Keys.aiSettings, {
      provider: settings.provider || "local",
      model: settings.model || "local-smart-script",
      apiKeyObfuscated: encodeSecret(settings.apiKey || ""),
      temperature: Number(settings.temperature) || 0.3,
      maxTokens: Number(settings.maxTokens) || 4096,
      promptTemplate: settings.promptTemplate || "",
      tokenUsage: Number(settings.tokenUsage || 0) || 0,
    });
  }

  global.HidWorkflowStorage = {
    Keys,
    listWorkflows,
    saveWorkflow,
    deleteWorkflow,
    getWorkflow,
    listHistory,
    addHistory,
    exportJson,
    loadAiSettings,
    saveAiSettings,
    encodeSecret,
    decodeSecret,
  };
})(window);
